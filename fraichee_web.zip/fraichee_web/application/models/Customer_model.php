<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model{
	public function getSubscription(){
		return $this->db->get('subscription')->result_array();
	} /* getSubscription() ends here */

	public function getServiceType( $role = ''){
		if(!empty($role)){
			return $this->db->where(['panel' => $role ])->get('service_type')->result_array();	
		}
		else{
			return $this->db->get('service_type')->result_array();
		}
	} /* getServiceType() ends here */

	public function getServiceProduct($sid){
		return $this->db->where('service_id',$sid)->get('products')->result_array();
	} /* getServiceProduct() ends here */

	public function getChildProducts($pid){
		return $this->db->where('prod_id',$pid)->get('child_products')->result_array();
	} /* getChildProducts() ends here */

	public function getChildProductDetail($cp_id){
		return $this->db->where('cp_id',$cp_id)->get('child_products')->row();
	} /* getChildProductDetail() ends here */

	public function addCartDetails($data){
		return $this->db->insert('cart' , $data);
	} /* addCartDetails() ends here */

	public function cartDetails($uid,$panel){
		return $this->db->where(['user_id'=> $uid,'status' => '0','panel'=> $panel ] )->get('cart')->result_array();
	} /* cartDetails() ends here */

	public function cartDetail($uid, $cartid , $panel){
		return $this->db->where(['user_id'=> $uid, 'panel' => $panel, 'cart_id' => $cartid] )->get('cart')->row();
	} /* cartDetails() ends here */

	public function removeCart($cart_id, $uid, $panel){
		$deleted = $this->db->where(['cart_id' => $cart_id])->delete('cart'); 
		if( isset($deleted) ){
			return $this->cartDetails($uid,$panel);
		}
	}/* removeCart() ends here */

	public function addCartOrder($data){
		$this->db->insert('cart_order', $data);
		$insertId = $this->db->insert_id();
		if ($insertId) {
		$uid = $this->session->userdata('customer_id');
		$u_mail = $this->db->where('user_id',$uid)->get('users')->row();

	    $this->db->select('cart_order.*,users.address,contact,name,email');
	    $this->db->where('users.user_id',$uid);
	    $this->db->where('cart_order.order_id',$insertId);
	    $this->db->from('cart_order');
	    $this->db->join('users', 'users.user_id = cart_order.user_id'); 
	    $order_details = $this->db->get()->row();

		$data['order_details'] = $order_details;
		$to = $u_mail->email;
        $from = 'CustomerService@fraichee.com';
			   //Load email library 
        $this->load->library('email');
        $this->email->from($from, 'fraichee');
        $this->email->to($to);
        $this->email->subject('Fraichee Order confirmation');
         $msg = $this->load->view('html_template/confirm-order',$data,true);
        $this->email->message($msg);

	        //Send mail 
			if(!$this->email->send()){
				return $insertId;
			} 
			else{
				return $insertId;
			}
		}

		return  $insertId;
	} /*addCartOrder() ends here */

	/* to empty cart for subscribers cart */
	public function emptyCart($uid,$panel){
		return $this->db->where(['user_id'=> $uid,'panel' => $panel])->delete('cart');
		// return $this->db->set('status',1)->where(['user_id'=> $uid,'panel' => $panel])->update('cart');
	} /* emptyCart() ends  here */

	public function getOrderDetail($uid,$panel){
    $this->db->select('cart_order.*,users.address,contact');
    $this->db->where('users.user_id',$uid);
    $this->db->where('cart_order.type',$panel);
    $this->db->from('cart_order');
    $this->db->join('users', 'users.user_id = cart_order.user_id'); 
    $query = $this->db->get();
    return $query->result();
	}/* getOrderDetail() ends here */

	public function get_last_Order($uid,$last_order_id){
    $this->db->select('cart_order.*,users.address,contact,name,email');
    $this->db->where('users.user_id',$uid);
    $this->db->where('cart_order.order_id',$last_order_id);
    $this->db->from('cart_order');
    $this->db->join('users', 'users.user_id = cart_order.user_id'); 
    $query = $this->db->get();
    return $query->row();
	}/* getOrderDetail() ends here */

	public function checkCartExists($child, $user){
		return $this->db->where(['user_id' => $user, 'cp_id' => $child ])->get('cart')->row_array();
	} /* checkCartExists() ends here */

	public function getTotalCart($role,$user){
		return $this->db->where(['user_id' => $user, 'panel' => $role, 'status' => '0'])->get('cart')->result_array();
	}

	public function updateCart($userid, $cartid, $data, $panel){
		return $this->db->set($data)->where(['user_id' => $userid , 'cart_id' => $cartid, 'panel' => $panel ])->update('cart');
	} /* updateCart($userid, $cartid, $data)  ends here */

	public function user_profile()
	{
		$user_id = $this->session->userdata('customer_id');
		return $this->db->where('user_id',$user_id)->get('users')->row();
	}
}
?> 