<?php 
defined('BASEPATH') or die('you can not access it directly');
class Home_model extends CI_Model{
	public function getCategories(){
		return $this->db->get('categories')->result_array();
	} /* getCategories() ends here */
 
	public function getProducts(){
		// return $this->db->get('products')->result_array();
	    $this->db->select('products.*');
	    $this->db->from('products');
	    $this->db->where('service_type.name','Ironing Only');
	    $this->db->join('service_type', 'service_type.service_id = products.service_id'); 
	    return $this->db->get()->result_array();


	} /* getProducts() ends here */


	public function getChildProducts($prod_id){
		return $this->db->where('prod_id', $prod_id)->get('child_products')->result_array();
	} /* getChildProducts() ends here */

	public function getProduct($pid){
		return $this->db->where(['prod_id' => $pid])->get('products')->row_array();
	} /* getProduct() ends here */
}
?>