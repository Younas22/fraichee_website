<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category_model extends CI_Model{

	public function add_category( $record ){
		if(!empty($record)){
			// $cat_query = $this->db->insert('categories', $record);
			return $this->db->insert('service_type', $record);
		}

	} /* add_category() ends here */

	public function get_categories(){
		// return $this->db->get('categories')->result_array();
		return $this->db->get('service_type')->result_array();
	} /* get_categories() ends here */

	public function getCategory($sid){
		return $this->db->where(['service_id' => $sid])->get('service_type')->row();
	} /* getCategory() ends here */

	public function updateService($sid, $sname){
		return $this->db->set(['name' => $sname ])->where(['service_id' => $sid ])->update('service_type');
	} /* updateService() ends here */

	public function removeCategory($id){
		return $this->db->where(['service_id' => $id ])->delete('service_type');
	}/*removeCategory() ends here */
}

?>