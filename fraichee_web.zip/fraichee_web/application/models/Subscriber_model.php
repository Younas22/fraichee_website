<?php 
defined('BASEPATH') or die('You can not directly access this file.');

class Subscriber_model extends CI_Model{
	public function get_parent_products(){
		return $this->db->get('products')->result_array();
	}
	/*get_parent_products() ends here */

	public function get_child_products($parent_id){
		return $child_products = $this->db->where('prod_id',$parent_id)->get('child_products')->result_array();
	} 
	/* get_child_products() ends here */

	public function addOrder($record){
		return $this->db->insert('orders',$record);
	} /* addOrder() ends here */

	public function getBookerDetails(){
		return $this->db->where(['role' => 'subscriber' ])->get('users')->result_array();
	}/* getBookerDetails() ends here */

	public function getOrderDetail(){
		return $this->db->get('orders')->result_array();
	} /* getOrderDetail() ends here */
}
?>