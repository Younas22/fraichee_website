<?php  
defined('BASEPATH') or die('you can not access this file directly');

class Admin_model extends CI_Model{
	public function getOrderDetail(){
    $this->db->select('cart_order.*,users.address,contact,name,email');
    $this->db->from('cart_order');
    $this->db->join('users', 'users.user_id = cart_order.user_id'); 
    $query = $this->db->get();
    return $query->result();
	} /* getOrderDetail() ends here */

	public function getProducts(){
	    $this->db->select('products.*,service_type.name as service_name');
	    $this->db->from('products');
	    $this->db->join('service_type', 'service_type.service_id = products.service_id'); 
	    return $this->db->get()->result_array();
	}/* getProducts() ends here */

	public function getChildProducts(){
		// return $this->db->get('child_products')->result_array();

	    $this->db->select('child_products.*,products.name as product_name');
	    $this->db->from('child_products');
	    $this->db->join('products', 'products.prod_id = child_products.prod_id'); 
	    return $this->db->get()->result_array();


	}/* getChildProducts() ends here */

	public function getChildProduct($id){
		return $this->db->where(['cp_id' => $id ])->get('child_products')->row();
	} /* getChildProduct() ends here */

	public function updateChildProduct($id, $data){
		return $this->db->set($data)->where(['cp_id'=> $id])->update('child_products');
	} /* updateChildProduct() ends here */

	public function getServiceDetails(){
		return $this->db->select('service_id,name')->get('service_type')->result_array();
	} /* getServiceDetails() ends here */

	public function addProduct($data){
		return $this->db->insert('products',$data);
	}/* addProduct() ends here */

	public function deleteProduct($pid){
		return $this->db->where(['prod_id' => $pid ])->delete('products');
	} /* deleteProduct() ends here */

	public function deleteChildProduct($cpid){
		return $this->db->where(['cp_id' => $cpid])->delete('child_products');
	} /* deleteChildProduct() ends here */

	public function updateProduct($id, $data ){
		return $this->db->set($data)->where(['prod_id' => $id])->update('products');
	} /* updateProduct() ends here */

	public function getProduct($id){
		return $this->db->where(['prod_id' => $id ])->get('products')->row();
	}/* getProduct() ends here */

	public function addChildProduct($data){
		return $this->db->insert('child_products' , $data);
	}/* addChildProduct() ends here */

	public function saveSetting($data){
		$check  = $this->db->where(['sname' => 'logo'])->get('settings')->row();
		if($check){
			return $this->db->set(['sval' => $data['sval']])->where(['sname' => 'logo'])->update('settings');
		}
		else{
			return $this->db->insert('settings', $data);
		}
	}/* saveSetting() ends here */

	public function getUsersList(){
		return $this->db->get('users')->result_array();
	} /* getUsersList() ends here */

	public function userDelete($user_id){
		return $this->db->where(['user_id' => $user_id])->delete('users');
	} /* userDelete*/

	public function countOrders(){
		$orders = $this->db->get('cart_order')->result_array();
		return count($orders);
	} /* countOrders() ends here */

	public function countUsers(){
		$users = $this->db->get('users')->result_array();
		return count($users);
	} /* countUsers() ends here */

	public function partnerIcons($data){
		return $this->db->set(['sval' => $data])->where(['sid' => 2])->update('settings');
	} /* partnerIcons() ends here */

	public function get_subscription($panel)
	{
	    $this->db->select('cart_order.*,users.address,contact,name');
	    $this->db->where('cart_order.type',$panel);
	    $this->db->from('cart_order');
	    $this->db->join('users', 'users.user_id = cart_order.user_id'); 
	    $query = $this->db->get();
	    return $query->result();
	}
}
?>