<?php  
defined('BASEPATH') or die('you can not access this file directly');

class Login_model extends CI_Model{
	public function loginValidate($email, $pass ){
		if (base_url() == "http://localhost/fraichee_web/") {
		return $this->db->where(['email'=>$email,'password'=>$pass,'role'=>'admin'])->get('users')->row_array();
		}else{
		return $this->db->where(['email'=>$email,'password'=>$pass,'status'=>1,'role'=>'admin'])->get('users')->row_array();
		}
	} /* loginValidate() ends here */

	public function customerValidation($data){
		if (base_url() == "http://localhost/fraichee_web/") {
			return $this->db->where($data)->get('users')->row_array();
		}else{
			return $this->db->where($data)->where('status',1)->get('users')->row_array();
		}
		
	}
	/* customerValidation() ends here */

	public function addUser($data){
		$this->db->insert('users',$data);
		return $this->db->insert_id();
	}/* addUser ends here */

	public function verifyUser($id){
		return $this->db->set(['status' => 1])->where(['user_id' => $id ])->update('users');
	} /* verifyUser() ends here */


	public function reset_password($email)
	{
		return $this->db->where('email',$email)->get('users')->row();
	}


	public function change_password($auto_password,$email)
	{
		return $this->db->set(['password' => $auto_password])->where('email',$email)->update('users');
	}




} /* login_model ends here */