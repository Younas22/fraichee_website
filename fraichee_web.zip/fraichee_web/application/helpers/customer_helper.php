<?php 
defined('BASEPATH') or die('you can not access directly');

function getPrice($cp_id){
	$CI =& get_instance();
	return $CI->db->select('cp_price')->where('cp_id', $cp_id )->get('child_products')->row('cp_price');
} /* getPrice() ends here */

function getProducts($service_id){
	$CI =& get_instance();
	return $CI->db->where('service_id', $service_id )->get('products')->result_array();
} /* getProducts() ends here */

function getChildProducts($prod_id){ 
	$CI =& get_instance();
	return $CI->db->where('prod_id', $prod_id )->get('child_products')->result_array();
}/* getChildProducts() ends here */

function getChildProdName($cp_id){
	$CI =& get_instance();
	return $CI->db->where(['cp_id' => $cp_id ])->get('child_products')->row()->cp_name;
} /* getChildProdName() ends here */

function partnerIcons(){
	$CI =& get_instance();
	return $CI->db->where(['sid' => 2])->get('settings')->row();
}

function get_service_address(){
	$CI =& get_instance();
	return $CI->db->where(['id' => 1])->get('service_address')->row();
}

function getprodimage($prod_id,$cp_id){
	$CI =& get_instance();
	return $CI->db->where(['prod_id' => $prod_id])->get('products')->row();
}


function getprodname($cp_id){
	$CI =& get_instance();
	return $CI->db->where(['cp_id' => $cp_id])->get('child_products')->row();
}

function user_address(){
	$CI =& get_instance();
	$uid  = $CI->session->userdata('customer_id');
	return $CI->db->where(['user_id' => $uid])->get('users')->row();
}

function coupon_code(){
	$CI =& get_instance();
	$uid  = $CI->session->userdata('customer_id');
	$user_coupon = $CI->db->where(['user_id' => $uid,'coupon_status' => 1])->get('users')->row();
	if ($user_coupon) {
		return $user_coupon->coupon_val;
	}else{
		return 0;
	}

}

function coupon_code_text(){
	$CI =& get_instance();
	$user_coupon = $CI->db->where(['status' => 1])->get('coupon_code')->row();
	if ($user_coupon) {
		return $user_coupon->coupon_code;
	}else{
		return 0;
	}

}


function hide_class(){
	$CI =& get_instance();
	$user_coupon = $CI->db->where(['coupon_status' => 1])->get('users')->row();
	if ($user_coupon) {
		return $user_coupon->hide_class;
	}else{
		return 0;
	}

}

function check_first_user(){
	$CI =& get_instance();
	$uid  = $CI->session->userdata('customer_id');
	$result = $CI->db->where(['user_id' => $uid])->get('cart_order')->row();
	if ($result) {
		return 1;
	}else{
		return 0;
	}
}



function dd($value){
	echo "<pre>";
	print_r($value);
	exit();
}
?>