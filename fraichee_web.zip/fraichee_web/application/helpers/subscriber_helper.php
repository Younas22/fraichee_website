<?php 
defined('BASEPATH') or die('you can not access directly');

function userName( $para1 = '' ){
	$CI =& get_instance();
	return $CI->db->select('name')->where('user_id', $para1 )->get('users')->row('name');
} /* userName() ends here */

function catName($para1 = '' ){
	$CI =& get_instance();
	return $CI->db->select('cat_name')->where('cat_id', $para1 )->get('categories')->row('cat_name');
} /* catName() ends here */

function daysToString($para1 = ''){
	$delivery_days = $para1;
	return ucwords(implode(', ',unserialize($delivery_days)));
}/* daysToString() ends here */

function prodName($para1 = ''){
	$CI =& get_instance();
	return $CI->db->select('name')->where('prod_id', $para1)->get('products')->row('name');
}/* prodName() ends here */

function childProdToString($para1 = ''){
	$prod_ids     = unserialize($para1);
	$prod_name    = [];
	foreach($prod_ids as $key => $val ){
		$CI       =& get_instance();
		$cp_name = $CI->db->select('cp_name')->where('cp_id', $val )->get('child_products')->row('cp_name');
		$prod_name[] = $cp_name;
	}
	return ucwords(implode(', ',$prod_name));
}/* childProdToString() ends here */
?>