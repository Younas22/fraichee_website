<?php 
defined('BASEPATH') or die('you can not access directly');

function getServiceId($pp_id){
	$CI =& get_instance();
	return $CI->db->select('service_id')->where('prod_id', $pp_id )->get('products')->row('service_id');
} /* getPrice() ends here */

function get_service_address(){
	$CI =& get_instance();
	return $CI->db->where(['id' => 1])->get('service_address')->row();
}

function subscribed_product($pro_id){
	$CI =& get_instance();
	return $CI->db->where(['prod_id' => $pro_id])->get('products')->row();
}


function getprodimage($prod_id,$cp_id){
	$CI =& get_instance();
	return $CI->db->where(['prod_id' => $prod_id])->get('products')->row();
}


function dd($value){
	echo "<pre>";
	print_r($value);
	exit();
}
?>