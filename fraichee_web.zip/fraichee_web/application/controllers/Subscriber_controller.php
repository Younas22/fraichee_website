<?php  
defined('BASEPATH') or die('you can access this file directly');

class Subscriber_controller extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->model('subscriber_model');
		$this->load->model('category_model');
		$this->load->helper('subscriber');
	}

	public function index(){
		$categories          = $this->category_model->get_categories();
		$products 			 = $this->subscriber_model->get_parent_products();
		$data				 = [
			'breadcrumb'	 => 'Dashboard', 
			'page_name'		 => 'subscriber/dashboard',
			'role'			 => 'subscriber',
			'parent_products'=> $products,
			'categories'     => $categories,
 		];
		$this->load->view('admin/index' , $data );
	}
	/* index() ends here */

	public function ajax_child_products(){
		$parent_id      = $_POST['parent_id'];
		$child_products = $this->subscriber_model->get_child_products($parent_id);
		$div            = '';
		foreach($child_products as $prod ){ 
			$div       .= '<option value='.$prod['cp_id'].'>'.$prod['cp_name'].'</option>';
		}
		echo json_encode($div);
	} 
	/* ajax_child_products() ends here */

	// public function addOrder(){
	// 	$user_id    	  = 1;
	// 	$user_role  	  = 'subscriber';
	// 	$cat_id   		  = $this->input->post('category');
	// 	$weekdays   	  = json_encode($this->input->post('perweek_delivery'));
	// 	$parent_prod_id   = $this->input->post('parent_product');
	// 	$child_prod_id    = json_encode($this->input->post('child_product'));
		
	// 	$data       = [
	// 		'user_id'        => $user_id,
	// 		'user_role'      => $user_role,
	// 		'cat_id' 		 => $cat_id,
	// 		'parent_prod_id' => $parent_prod_id,
	// 		'child_prod_id'  => $child_prod_id,
	// 		'delivery_days'  => $weekdays,
	// 		'status'  		 => 1
	// 	];
	// 	$record_added    = $this->subscriber_model->addOrder($data);
	// 	if( $record_added ){
	// 		echo 'reocrd inserted';
	// 		redirect('subscriber');
	// 	}
	// } /* add_order ends here */

	public function orders( $link = '' ){
		if( $link == 'newOrder' ){
			$categories          = $this->category_model->get_categories();
			$products 			 = $this->subscriber_model->get_parent_products();
			$data				 = [
				'breadcrumb'	 => 'Dashboard', 
				'page_name'		 => 'subscriber/newOrder_page',
				'role'			 => 'subscriber',
				'parent_products'=> $products,
				'categories'     => $categories,
	 		];
		}
		else if( $link == 'addOrder'){
			$user_id    	  = 1;
			$user_role  	  = 'subscriber';
			$cat_id   		  = $this->input->post('category');
			$weekdays   	  = serialize($this->input->post('perweek_delivery'));
			$parent_prod_id   = $this->input->post('parent_product');
			// $child_prod_id    = json_encode($this->input->post('child_product'));
			$child_prod_id    = serialize($this->input->post('child_product'));
			$dataToAdd        = [
				'user_id'        => $user_id,
				'user_role'      => $user_role,
				'cat_id' 		 => $cat_id,
				'parent_prod_id' => $parent_prod_id,
				'child_prod_id'  => $child_prod_id,
				'delivery_days'  => $weekdays,
				'status'  		 => 1
			];
			$record_added    = $this->subscriber_model->addOrder($dataToAdd);
			if( $record_added ){
				echo 'reocrd inserted';
				redirect('subscriber');
			}
		}
		else{
			$order_details       = $this->subscriber_model->getOrderDetail();
			$data				 = [
				'breadcrumb'	 => 'Order Detail', 
				'page_name'		 => 'subscriber/orderdetail_page',
				'role'			 => 'subscriber',
				'order_details'  => $order_details
	 		];
		}
 		$this->load->view('admin/index', $data );
	}/* orders() ends here */
}
?>