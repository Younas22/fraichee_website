<?php  

defined('BASEPATH') or die('you can not access it directly');

class Login_controller extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('login_model' , 'login');
		// $this->load->model('customer_model' , 'customer');
	} /* coonstruct() ends here */

	public function index($para1 = ''){
		if($para1 == 'customer'){
			if(!($this->session->userdata('customer_id'))){
				$data = [
					'title'     => 'Laundary Panel',
					'panel'     => 'laundary',
					'page_name' => 'login_page',
				];
				$this->load->view('customer/index',$data);
			}
			else{
				redirect('customer');
			}
		}
		else if( $para1 == 'register' ){
			$data = [
				'title'     => 'Signup',
				'panel'     => 'laundary',
				'page_name' => 'signup_page',
			];
			$this->load->view('customer/index',$data);
		}
		else if($para1 == 'admin'){
			if(!($this->session->userdata('admin_id'))){
				$data = [
					'breadcrumb'=> 'Login', 
					'page_name' => 'login'];
				// print_r($data);exit;
				$this->load->view('admin/index', $data);
			}
			else{
				redirect('admin');
			}
			
		}
		else if( $para1 == 'register' ){
			
		}
	} /* index() ends here */

	public function loginAuth($para1 = ''){
		if( $para1 == 'admin' ){
			$email = $this->input->post('email');
			$pass  = $this->input->post('password');
			$loginValidate = $this->login->loginValidate($email, $pass);
			
			if($loginValidate){
				$data = [
				        'admin_id' => $loginValidate['user_id'],
				];
				$setsession = $this->session->set_userdata($data);
				if( $setsession ){
					redirect('admin');
				}
				else{
					redirect('login/admin');
				}
			}
			else{
				redirect('login/admin');
			}
		}
		else if( $para1 == 'customer' ){
			$data   = [
				'email'    => $this->input->post('cemail'),
				'password' => $this->input->post('cpassword'),
				'role'     => 'customer',
			];


			$result = $this->login->customerValidation($data);
			
			// echo "<pre>";
			// print_r($result);
			// exit();

			if(!empty($result)){
				$data = [
				    'customer_id' => $result['user_id'],
				];
				$setsession = $this->session->set_userdata($data);
				if( $setsession ){
					redirect('customer');
				}
				else{
					redirect('login/customer');
				}
			}else{
				redirect('login/customer');
			}
		}
	} /* loginAuth() ends here */

	public function logout($para1 = '' ){
		if($para1 == 'admin' ){
			$user   = $this->session->unset_userdata('admin_id');
			redirect('login/admin','refresh');
		}

	}/* logout() ends here */

	public function signup(){

        $this->form_validation->set_message('is_unique', 'Email already exists.');
		$this->form_validation->set_rules('cemail', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('cpassword', 'Password', 'required|min_length[4]');
    	if ($this->form_validation->run() == FALSE) {
			$data = [
				'title'     => 'Signup',
				'panel'     => 'laundary',
				'page_name' => 'signup_page'
			];
			$this->load->view('customer/index',$data);
		}else{

		// print_r($_POST);exit;
		$fname = $this->input->post('fname');
		$lname = $this->input->post('lname');
		$name  = $fname.' '.$lname;
		$email = $this->input->post('cemail');
		$pass  = $this->input->post('cpassword');
		$address  = $this->input->post('address');
		$phone_number  = $this->input->post('phone_number');

		$data  = [
			'name'     => $name,
			'email'    => $email,
			'password' => $pass,
			'address' => $address,
			'contact' => $phone_number,
			'role'     => 'customer',
			'status'   => NULL
		];
		$lastUserId = $this->login->addUser($data);
		if($lastUserId){
			$emailCheck = $this->sentVerificationEmail($lastUserId, $data);
			if(isset($emailCheck)){
				redirect('account-verification');
			}
		}
}


	}/* register() ends here */

	public function sentVerificationEmail($lastUserId, $data){
		$to = $data['email'];
		$url     = base_url().'customer/verfication/'.$lastUserId;
        $from = 'CustomerService@fraichee.com';  // Mail Created  from your Server
	    
	   //Load email library 
        $this->load->library('email');
		$data['url'] = $url;
        $this->email->from($from, 'fraichee');
        $this->email->to($to);
        $this->email->subject('Fraichee Verfication');
         $msg = $this->load->view('html_template/confirm-email',$data,true);
        $this->email->message($msg);

        //Send mail 
		if($this->email->send()){
			return true;
		} 
		else{
			redirect('account-verification');
		}
	}/* sentVerificationEmail() ends here */

	public function verfication($id){
		$checkVerify = $this->login->verifyUser($id);
		if( $checkVerify == true ){
			redirect('Login_controller/user_account_created');
			// redirect('login/customer');
		}
	}

	public function forgot_pass()
	{


		$data=array();
		if($this->session->userdata('success_msg')){
			$data['success_msg']=$this->session->userdata('success_msg');
			$this->session->unset_userdata('success_msg');
		}
		if($this->session->userdata('error_msg')){
			$data['error_msg']=$this->session->userdata['error_msg'];
			$this->session->unset_userdata('error_msg');
		}


		$this->load->view('customer/pages/forgot_password', $data);
	}

	public function reset_password()
	{


		$data=array();
		if($this->session->userdata('success_msg')){
			$data['success_msg']=$this->session->userdata('success_msg');
			$this->session->unset_userdata('success_msg');
		}
		if($this->session->userdata('error_msg')){
			$data['error_msg']=$this->session->userdata['error_msg'];
			$this->session->unset_userdata('error_msg');
		}

		if ($this->input->post('cemail')) {
				$email = $this->input->post('cemail');
				$reset_password = $this->login->reset_password($email);
			    //var_dump($log);exit;
				if($reset_password){
				$auto_password = $this->randomPassword();
				$changed = $this->login->change_password($auto_password,$email);


		$to = $email;
        $from = 'CustomerService@fraichee.com';  // Mail Created  from your Server
	    
	   //Load email library 
        $this->load->library('email');
        $data['password'] = $auto_password;
        $this->email->from($from, 'fraichee');
        $this->email->to($to);
        $this->email->subject('Password Updated');

         $msg = $this->load->view('html_template/password-changed',$data,true);
        $this->email->message($msg);

        //Send mail 
		if($this->email->send()){
			$data['success_msg']='password updated / Please check your Email! thank you';
		} 
		else{
			$data['error_msg']='error somthing wrong!';
		}

		}}
		

		$this->load->view('customer/pages/forgot_password', $data);

	}


	/*auto password chenrater*/
	function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
	/*end auto password chenrater*/

	public function location()
	{

		if(!empty($_POST["keyword"])) {
			$keyword = preg_replace("/\s+/", "", $_POST["keyword"]);
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.ideal-postcodes.co.uk/v1/postcodes/'.$keyword.'?api_key=ak_kslpaxvlq0GX5VjGGmTIdEMOiRv9f',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		));

		$response = curl_exec($curl);
		curl_close($curl);
		$address_data = json_decode($response);
		if ($address_data->message == 'Success') {
		foreach($address_data->result as $key) {
				echo "<option class='form-control' value='".$key->line_1.', '.$key->line_2.', '.$key->district.', '.$key->postcode."'>".$key->line_1.', '.$key->line_2.', '.$key->district.', '.$key->postcode."</option>";
				// echo "<hr>";
		}
		}else{
			echo "<option class='form-control'>Address Not Found!</option>";
		}


	}
		}

/* verfication() ends here */

		
	
	public function user_verification()
	{
		$this->load->view('customer/pages/verification');
	}

		public function user_account_created()
	{
		$this->load->view('customer/pages/account_created_msg');
	}



public function mail_testing(){
                    
                    
                    ini_set('display_errors',1 );
                    error_reporting(E_ALL);
                    
                    
                    $from = 'info@fraichee.com';
                    $to = 'phpfiverrpk@gmail.com';
                    $msg = 'hello sir';
                    $sub = 'this is test mail';
                    $header = 'from' . $from;
                    
                    if(mail($to, $sub, $msg, $header)){
                        echo "sent";
                    }else{
                        echo "not sent";
                    }
    
		}

}
?>