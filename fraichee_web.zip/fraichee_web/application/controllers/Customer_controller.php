<?php  
defined('BASEPATH') or exit('No direct script access allowed');

class Customer_controller extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('Customer_model' , 'customer');
		$this->load->helper('customer_helper');
	} /* construct() ends here */
 
	public function index( $page = '', $para2 = '' ){
		// echo $page; exit;
		if(!$this->session->userdata('customer_id')){
			redirect('login/customer');
		}
		$uid  = $this->session->userdata('customer_id');
		if( $page == 'laundary' ){
			if( $para2 == 'profile' ){
				// echo "<pre>";
				// print_r($this->customer->user_profile());
				// exit;
				$total_cart     = $this->customer->getTotalCart($role='laundary',$uid);
				$total_carts    = count($total_cart);

				$data = [
					'title'     => 'Laundary Panel',
					'panel'     => 'laundary',
					'page_name' => 'profile_page',
					'total_carts'   => $total_carts,
					'user_profile'   => $this->customer->user_profile()
				];
			} 
			else if( $para2 == 'order_history'){
				$order_details  = $this->customer->getOrderDetail($uid,$panel = 'laundary');
				$services_type  = $this->customer->getServiceType($role='laundary');
				$total_cart     = $this->customer->getTotalCart($role='laundary',$uid);
				$total_carts    = count($total_cart);
				// dd($order_details);
				$data = [
					'title'     => 'Laundary Panel',
					'panel'     => 'laundary',
					'page_name' => 'orderhistory_page',
					'services_type' => $services_type,
					'total_carts'   => $total_carts,
					'order_details' => $order_details
				];
			}
			else{
				$services_type  = $this->customer->getServiceType($role='laundary');
				$total_cart     = $this->customer->getTotalCart($role='laundary',$uid);
				$total_carts    = count($total_cart);
				$data = [
					'title'     => 'Laundary Panel',
					'panel'     => 'laundary',
					'page_name' => 'laundary_page',
					'services_type' => $services_type,
					'total_carts'   => $total_carts
				];	
				// $service_type   = $this->customer->getServiceType($role = 'laundary');
				// $data = [
				// 	'title'     => 'Laundary Panel',
				// 	'panel'     => 'laundary',
				// 	'page_name' => 'laundary_page',
				// 	'service_type' => $service_type,
				// ];
			}
		}
		else if( $page == 'subscribe' ){
			if($para2 == 'order_history' ){
				$order_details  = $this->customer->getOrderDetail($uid,$panel = 'subscribe');
				$services_type  = $this->customer->getServiceType($role='subscribe');
				$total_cart     = $this->customer->getTotalCart($role='subscribe',$uid);
				$total_carts    = count($total_cart);

				$data = [
					'title'     => 'Subscribe Panel',
					'panel'     => 'subscribe',
					'page_name' => 'orderhistory_page',
					'services_type' => $services_type,
					'total_carts'   => $total_carts,
					'order_details' => $order_details
				];
			} /* subscribe/order_history ends here */
			else{
				$services_type  = $this->customer->getServiceType($role='subscribe');
				$total_cart     = $this->customer->getTotalCart($role='subscribe',$uid);
				$total_carts    = count($total_cart);
				$data = [
					'title'     => 'Subscription Panel',
					'panel'     => 'subscribe',
					'page_name' => 'subscribe_page',
					'services_type' => $services_type,
					'total_carts'   => $total_carts
				];
			}
		}
		else if( $page == 'subscribe_cart' ){
			$panel          = 'subscribe';
            $cartdetails    = $this->customer->cartDetails($uid,$panel);
            if(empty($cartdetails)){
            	/* go and shop */
            	redirect('customer/subscribe');
            }
			$total_cart     = $this->customer->getTotalCart($role='subscribe',$uid);
			$total_carts    = count($total_cart);
			$data = [
				'title'     => 'Cart List',
				'panel'     => 'subscribe',
				'page_name' => 'subscribe_cart_list_page',
				'total_carts'   => $total_carts,
				'cartdetails'   => $cartdetails
  			];
		}
		else if( $page == 'laundary_cart' ){
			$panel          = 'laundary';
            $cartdetails    = $this->customer->cartDetails($uid,$panel);
            // echo "<pre>";
            // print_r($cartdetails);
            // exit;
            if(empty($cartdetails)){
            	/* go and shop */
            	redirect('customer/laundary');
            }
			$total_cart     = $this->customer->getTotalCart($role='laundary',$uid);
			$total_carts    = count($total_cart);
			$data = [
				'title'     => 'Cart List',
				'panel'     => 'laundary', 
				'page_name' => 'laundary_cart_list_page',
				'total_carts'   => $total_carts,
				'cartdetails'   => $cartdetails
  			];
		}
		else if( $page == 'placeorder' ){


			if ($this->input->post('delivery_options')) {
				$uid            = $this->input->post('uid');
				$panel          = $this->input->post('panel_type');
				$delivery_dates = $this->input->post('delivery_dates');
				$note_box = $this->input->post('note_box');
				$other_address = $this->input->post('other_address');
				$delivery_cost = $this->input->post('delivery_cost');
				$totalwith_coupon = $this->input->post('totalwith_coupon');
				$delivery_options = $this->input->post('delivery_options');
				$first_day = $this->input->post('1st_day');
				$second_day = $this->input->post('2nd_day');
			}else{
				$uid            = $this->input->post('uid');
				$panel          = $this->input->post('panel_type');
				$delivery_dates = $this->input->post('delivery_dates');
				$pickup_date = $this->input->post('pickup_dates');
				$note_box = $this->input->post('note_box');
				$other_address = $this->input->post('other_address');
				$delivery_cost = $this->input->post('delivery_cost');
				$totalwith_coupon = $this->input->post('totalwith_coupon');
			}





			// $stripeToken    = $this->input->post('stripeToken');

            $carts          = $this->customer->cartDetails($uid,$panel);

            if(empty($carts) ){
            	redirect('customer/'.$panel);
            }
            static $total   = 0;
			$cart_data      = [];
			foreach($carts as $key => $cart){
				if ($delivery_dates) {
					$delivery_dates = $delivery_dates;
				}else{
					$delivery_dates = $delivery_dates;
				}
				$cart_id    = $cart['cart_id'];
				$cart_days  = $delivery_dates;
				
				$cart['delivery_days'] = $cart_days;
				$cart_data[]= $cart;
				$total      = $total + $delivery_cost + $cart['total_price'] - $totalwith_coupon;
			}
			
			require_once APPPATH."third_party/stripe/init.php";
						//set api key
			$stripe = array(
         "secret_key"      => "sk_test_zCTAEgeEGOYkb2qwBaDAJPmO00WW21fCqc",
		"publishable_key" => "pk_test_KIhUx4DZXHOnK6tUOxtdEMTD00phOqJ9gN"
			);

	// $stripe = array(
         // "secret_key"      => "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",
		// "publishable_key" => "pk_live_51InL3sCk9TUwz5fu4PWforwvJqWNsR8XQe5BABE8XnYPz2YI4oHWUPQX0E7SaPRGVDZe61vXgJbg9T6gQQN8nbSe00GFWzYFGi"
			// );

 
	        \Stripe\Stripe::setApiKey($stripe['secret_key']);
	        
	        \Stripe\Charge::create ([
	            "amount"      => intval($total)*100,
	            "currency"    => "gbp",
	            // "source"      => $this->input->post('stripeToken'),
	            "source"      => 'tok_visa',
	            "description" => "Payment Recived by Laundary Section" 
	        ]);


	        $invoice_no = $this->invoice_id();
	        $invoice_id = "F{$invoice_no}";



			if ($this->input->post('delivery_options')) {
				$sub_data = [
				'user_id'      => $uid,
				'invoice_id'      => $invoice_id,
				'cart_details' => json_encode($cart_data),
				'total_amount' => $total,
				'type'		   => $panel,
				'delivery_days'=> $delivery_dates,
				'note_box'		=> $note_box,
				'other_address'	=> $other_address,
				'delivery_options' => $delivery_options,
				'first_day'		   => $first_day,
				'second_day'		   => $second_day,
				'status'       => 'pending'
			];

			$cart_query    = $this->customer->addCartOrder($sub_data);
			$this->db->set(array('coupon_status'=>0))->where('user_id',$uid)->update('users');
					// dd($cart_query);

/*//////////////////////*/	
if($cart_query){

$deleted   = $this->customer->emptyCart($uid,'subscribe');
if( $deleted ){
 redirect('success_msg/'.$invoice_id); 
} 
}
else{ redirect('customer/subscribe_cart'); }
/*//////////////////////*/	

			}else{


			$data  = [
				'user_id'      => $uid,
				'invoice_id'      => $invoice_id,
				'delivery_days'=> $delivery_dates,
				'cart_details' => json_encode($cart_data),
				'total_amount' => $total,
				'type'		   => $panel,
				'date'		   => $pickup_date,
				'note_box'		   => $note_box,
				'other_address'		   => $other_address,
				'status'       => 'pending'
			];
			$cart_querylaundaryid    = $this->customer->addCartOrder($data);
			$this->db->set(array('coupon_status'=>0))->where('user_id',$uid)->update('users');
				// $this->order_details_mail($cart_querylaundaryid);

								

/*//////////////////////*/	
if($cart_querylaundaryid){
$deleted   = $this->customer->emptyCart($uid,$panel);
if( $deleted ){ redirect('success_msg/'.$invoice_id); } }
else{ redirect('customer/'.$panel); }
/*//////////////////////*/	


			}
			

		}
		else{
			$get_subscription = $this->customer->getSubscription();
			$data = [
				'title'     => 'Subscription Panel',
				'panel'     => 'customer',
				'page_name' => 'subscription_page'
			];
		}
		$this->load->view('customer/index', $data);
	} /* index() ends here*/

	public function customerLogout(){
		$customer_session_removed = $this->session->unset_userdata('customer_id');
		if( $customer_session_removed == NULL ){
			redirect('login/customer',true);
		}
	} /* customerLogout() ends here */

	public function customerAjax( $para1 = '' ){
		$uid     = $this->session->userdata('customer_id');
		// if($para1 == 'service_type' ){
		// 	$sid = $this->input->post('sid');
		// 	$serviceprod = $this->customer->getServiceProduct($sid);
		// 	$div = '';
		// 	$div .='<h4>Product Category</h4>';
		// 	foreach($serviceprod as $sprod ){
	 //            $div.='<button class="btn btn-info btn-lg product_category_btn" data-prodcatid="'.$sprod['prod_id'].'">'.$sprod['name'].'</button>';
		// 	}
		// 	echo json_encode($div);
		// }
		// else if( $para1 == 'product_category' ){
		// 	$pid        = $this->input->post('pc_id');
		// 	$child_prod = $this->customer->getChildProducts($pid);
		// 	$div        = '';
		// 	foreach($child_prod as $cprod ){
		// 		$div .= '<div class="col-md-3 CartProducts">
		//           <div class="addCartProducts">
		//             <div class="card border-0">
		//               <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">';
		//               $div.='<div class="card-body px-0 CartProductsBody">
		//                 <div class="card-title d-flex flex-row">';
		//                   $div.='<div style="flex:1;">'.$cprod['cp_name'].'</div>
		//                   <div class="prodPrice">'.$cprod['cp_price'].'</div>
		//                 </div>';
		//                 $div.='<p class="card-text">'.$cprod['cp_desc'].'</p>
		//                 <a href="javascript:void(0);" class="btn btn-primary addCartBtn" data-cartprodid="'.$cprod['cp_id'].'">Add To Cart</a>
		//               </div>
		//             </div>
		//           </div>
		//         </div>';
		// 	}
		// 	echo json_encode($div);
		// }
		if( $para1 == 'addProdIntoCart' ){
			// $cp_id        = $this->input->post('cp_id');
			// $cproducts    = $this->customer->getChildProductDetail($cp_id);
			// $price        = $cproducts->cp_price;
			// $prod_id      = $cproducts->prod_id;
			// $service_id   = $cproducts->service_id;
			// $qty          = 1;
			// $data         = [
			// 	'user_id' => $uid,
			// 	'service_id' => $service_id,
			// 	'prod_id' => $prod_id,
			// 	'cp_id'   => $cp_id,
			// 	'cart_qty'=> $qty,
			// 	'price'   => $price,
			// 	'total_price' => $price * $qty,
			// 	'date'    => date('Y-m-d H:i:s'),
			// 	'panel'   => 'laundary',
			// 	'status'  => '0'
			// ];
			// $cartdetails = $this->customer->addCartDetails($data);
			// if( $cartdetails ){
			// 	return true;
			// }
			// else{
			// 	return false;
			// }

			$cp_id        = $this->input->post('cp_id');
			$check_cart   = $this->customer->checkCartExists($cp_id, $uid);
			if(!empty($check_cart)){
				echo 'false';exit;
			}
						
			$cproducts    = $this->customer->getChildProductDetail($cp_id);
			$price        = $cproducts->cp_price;
			$prod_id      = $cproducts->prod_id;
			$service_id   = $cproducts->service_id;
			$qty          = 1;
			$data  = [
				'user_id' => $uid,
				'service_id' => $service_id,
				'prod_id' => $prod_id,
				'cp_id'   => $cp_id,
				'cart_qty'=> $qty,
				'price'   => $price,
				'total_price' => $price * $qty,
				'date'    => date('Y-m-d H:i:s'),
				'panel'   => 'laundary',
				'status'  => '0'
			];
			$cartdetails = $this->customer->addCartDetails($data);
			if( $cartdetails ){
				echo 'true';
			}
			else{
				echo 'false';
			}
			exit;
		}
		else if( $para1 == 'cartdetaillist' ){
			$panel      = 'laundary';
            $cartdetail = $this->customer->cartDetails($uid,$panel);
            // $this->cartListHtml($cartdetail,$panel);
		}
		else if($para1 == 'updateLaundaryQty' ){
			// echo 'this function is used to update qty';
			$userid    = $this->input->post('userid');
			$cartid    = $this->input->post('cartid');
			$panel     = $this->input->post('panel');
			$qty       = $this->input->post('qty');
			$cartdata  = $this->customer->cartDetail($userid, $cartid , $panel);
			// print_r($cartdata);
			$total     = $qty * $cartdata->price;
			$data      = [
				'cart_qty'   => $qty,
				'total_price'=> $total
			];
			$updated   = $this->customer->updateCart($userid, $cartid, $data, $panel = 'laundary' );
			if($updated){
				echo 'true';
			}
			exit;
		}
		// elseif( $para1 == 'removecart' ){
		// 	// $uid     = 1; 
		// 	$cart_id = $this->input->post('cartid');
		// 	$cart_details = $this->customer->removeCart($cart_id, $uid );
		// 	$this->cartListHtml($cart_details);
		// }
		else if( $para1 == 'checkout'){
			// $uid   = 1;
			$carts = $this->customer->cartDetails($uid,$panel='laundary');
			static $total = 0;
			$cart_data = [];
			foreach($carts as $cart){
				$cart_data[] = $cart;
				$total = $total + $cart['total_price'];
			}
			$data  = [
				'cart_details' => json_encode($cart_data),
				'total_amount' => $total,
				'type'		   => 'laundary',
				'date'		   => date('Y-m-d H:i:s'),
				'status'       => 'pending'
			];
			$cart_query  = $this->customer->addCartOrder($data);
			if($cart_query){
				$deleted = $this->customer->emptyCart($uid,$panel='laundary');
				if( $deleted ){
					return true;
				}

			}
			else{
				return false;
			}
			
		}
		exit;
	} /* customerAjax() ends here */

	// public function cartListHtml( $cart_detail, $panel ){
	// 	if( $panel == 'laundary'){
	// 		$div   = '';
	// 		static $total = 0;
	// 		foreach($cart_detail as $key => $cd ){
	// 			$div.='<tr data-cartid="'.$cd['cart_id'].'">
	// 			<th scope="row">'.($key+1).'</th>
	// 			<td>image</td>
	// 			<td>
	// 			  <input type="number" name="cartprod_qnty" min="1"  value="'.$cd['cart_qty'].'"style="width:100px;">
	// 			</td>
	// 			<td>'.getPrice($cd['cp_id']).'</td>
	// 			<td>
	// 				<a href="javascript:void(0);" class="removeCart" data-removecartid="'.$cd['cart_id'].'">
	// 					<i class="fa fa-times"></i>
	// 				</a>
	// 			</td>
	// 			</tr>';
	// 			$total = $total + $cd['total_price'];
	// 		}
	// 		$div.='<tr class="cart_total">
	// 			<td>Total Amount :</td><td>'.$total.'</td></tr>';
	// 	}
	// 	else if($panel == 'subscribe'){
	// 		$div   = '';
	// 		static $total = 0;
	// 		foreach($cart_detail as $key => $cd ){
	// 			$delivery_days = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
	// 			$div.='<tr data-cartid="'.$cd['cart_id'].'">
	// 			<th scope="row">'.($key+1).'</th>
	// 			<td>image</td>
	// 			<td>
	// 			  <input type="number" name="cartprod_qnty" min="1"  value="'.$cd['cart_qty'].'"style="width:100px;" class="form-control">
	// 			</td>
	// 			<td>'.getPrice($cd['cp_id']).'</td>
	// 			<td>	
	// 				<select class="form-control delivery_days" name="delivery_days[]" multiple="true" style="width:200px;">';
	// 				foreach($delivery_days as $day ){
	// 					$div.='<option value="'.$day.'">'.ucfirst($day).'</option>';
	// 				}
	// 				$div.='</select>
	// 			</td>
	// 			<td>
	// 				<a href="javascript:void(0);" class="removeCart" data-removecartid="'.$cd['cart_id'].'">
	// 					<i class="fa fa-times"></i>
	// 				</a>
	// 			</td>
	// 			</tr>';
	// 			$total = $total + $cd['total_price'];
	// 		}
	// 		$div.='<tr class="cart_total">
	// 			<td>Total Amount :</td><td>'.$total.'</td></tr>';
	// 	}
	// 	echo json_encode($div);
	// } /* cartListHtml() ends here */

	public function subscribeAjax( $para1 = '' ){
		$uid = $this->session->userdata('customer_id');
		// if($para1 == 'service_type' ){
		// 	$sid = $this->input->post('sid');
		// 	$serviceprod = $this->customer->getServiceProduct($sid);
		// 	$div = '';
		// 	$div .='<h4>Product Category</h4>';
		// 	foreach($serviceprod as $sprod ){
	 //            $div.='<button class="btn btn-info btn-lg product_category_btn" data-prodcatid="'.$sprod['prod_id'].'">'.$sprod['name'].'</button>';
		// 	}
		// 	echo json_encode($div);
		// }
		// else if( $para1 == 'product_category' ){
		// 	$pid        = $this->input->post('pc_id');
		// 	$child_prod = $this->customer->getChildProducts($pid);
		// 	$div        = '';
		// 	foreach($child_prod as $cprod ){
		// 		$div .= '<div class="col-md-3 CartProducts">
		//           <div class="addCartProducts">
		//             <div class="card border-0">
		//               <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">';
		        
		//               $div.='<div class="card-body px-0 CartProductsBody">
		//                 <div class="card-title d-flex flex-row">';
		//                   $div.='<div style="flex:1;">'.$cprod['cp_name'].'</div>
		//                   <div class="prodPrice">'.$cprod['cp_price'].'</div>
		//                 </div>';
		//                 $div.='<p class="card-text">'.$cprod['cp_desc'].'</p>
		//                 <a href="javascript:void(0);" class="btn btn-primary addCartBtn" data-cartprodid="'.$cprod['cp_id'].'">Add To Cart</a>
		//               </div>
		//             </div>
		//           </div>
		//         </div>';
		// 	}
		// 	echo json_encode($div);
		// }
		if( $para1 == 'addProdIntoCart' ){
			$cp_id        = $this->input->post('cp_id');
			$check_cart   = $this->customer->checkCartExists($cp_id, $uid);
			// $cproducts    = $this->customer->getChildProductDetail($cp_id);
			if(!empty($check_cart)){
				echo 'false';
				exit;
			}
						
			$cproducts    = $this->customer->getChildProductDetail($cp_id);
			$price        = $cproducts->cp_price;
			$prod_id      = $cproducts->prod_id;
			$service_id   = $cproducts->service_id;
			$qty          = 1;
			$data  = [
				'user_id' => $uid,
				'service_id' => $service_id,
				'prod_id' => $prod_id,
				'cp_id'   => $cp_id,
				'cart_qty'=> $qty,
				'price'   => $price,
				'total_price' => $price * $qty,
				'date'    => date('Y-m-d H:i:s'),
				'panel'   => 'subscribe',
				'status'  => '0'
			];
			$cartdetails = $this->customer->addCartDetails($data);
			if( $cartdetails ){
				echo 'true';
			}
			else{
				echo 'false';
			}
			exit;
		}
		else if( $para1 == 'updateSubscribeQty' ){
			$qty     = $this->input->post('qty');
			$cartid  = $this->input->post('cartid');
			$panel   = $this->input->post('panel');
			$userid  = $this->input->post('userid');

			$cartdata  = $this->customer->cartDetail($userid, $cartid , $panel);
			$total     = $qty * $cartdata->price;
			$data      = [
				'cart_qty'   => $qty,
				'total_price'=> $total
			];
			$updated   = $this->customer->updateCart($userid, $cartid, $data, $panel );
			if($updated){
				echo 'true';
			}
			exit;
		}
		else if( $para1 == 'cartdetaillist' ){
			// $uid = 1;
			// $panel = 'subscribe';
   //          $cartdetail = $this->customer->cartDetails($uid,$panel);
   //          $this->cartListHtml($cartdetail,$panel);
		}
		else if( $para1 == 'checkout'){
			// $uid   = 1;
			$days  = $this->input->post('days');
			$days  = json_encode($days);
			$carts = $this->customer->cartDetails($uid,$panel='subscribe');
			static $total = 0;
			$cart_data = [];
			foreach($carts as $cart){
				$cart_data[] = $cart;
				$total = $total + $cart['total_price'];
			}
			$data  = [
				'delivery_days'=> $days,
				'cart_details' => json_encode($cart_data),
				'total_amount' => $total,
				'type'		   => 'subscribe',
				'date'		   => date('Y-m-d H:i:s'),
				'status'       => 'pending'
			];
			$cart_query  = $this->customer->addCartOrder($data);
			if($cart_query){
				$deleted = $this->customer->emptyCart($uid,$panel='subscribe');
				if( $deleted ){
					return true;
				}

			}
			else{
				return false;
			}
			
		}
	}
	/* subscribeAjax() ends here */

	public function update_customer_profile()
	{
		 $password = $this->input->post('password');
		 $contact = $this->input->post('contact');
		 $address = $this->input->post('address');
		 $user_id = $this->session->userdata('customer_id');
		 $this->db->where('user_id',$user_id)->update('users',array('password' =>$password,'address' =>$address,'contact' =>$contact));
		 redirect ('customer/laundary/profile');
	}

	/*remove cart*/
public function remove_cart($cart_id,$panel)
{
	$uid  = $this->session->userdata('customer_id');
	$cart_details = $this->customer->removeCart($cart_id, $uid,$panel);
	if ($panel == 'laundary') {
		redirect(base_url('customer/laundary_cart'));
	}else{
		redirect(base_url('customer/subscribe_cart'));
	}
}

	/*remove cart*/
public function subscription_details($user_id)
{
		$subscription_details = $this->db->where(['user_id'=> $user_id, 'type' => 'subscribe'])->get('cart_order')->result();
		$data = [
			'subscription_details'     => $subscription_details,
			'title'     => 'Subscription Details',
			'panel'     => 'Subscription',
			'page_name' => 'subscription_details'
		];
		
		$this->load->view('customer/index', $data);
}


	/*remove cart*/
public function subscription_view($order_id)
{
		$subscription_row = $this->db->where(['order_id'=> $order_id, 'type' => 'subscribe'])->get('cart_order')->row();
		$data = [
			'subscription_row'     => $subscription_row,
			'title'     => 'Subscription View',
			'panel'     => 'Subscription',
			'page_name' => 'subscription_view'
		];
		
		$this->load->view('customer/index', $data);
}


	/*remove cart*/
public function subscription_remove($subscribe_id)
{
		$subscription_remove = $this->db->where('order_id',$subscribe_id)->delete('cart_order');
		$uid  = $this->session->userdata('customer_id');
		if ($subscription_remove) {
			$this->session->set_flashdata('msg', 'Order Deleted Successfully!');
		redirect(base_url('subscription-details/').$uid);
		}

}


	/*cancelled subscription*/
public function subscription_cancel($subscribe_id)
{

			$uid  = $this->session->userdata('customer_id');
            $this->db->set(array('status'=>'cancelled'));
            $this->db->where('order_id',$subscribe_id);
            $update = $this->db->update('cart_order');
            if($update)
            {redirect(base_url('subscription-details/').$uid);}
            else
            { return false;}




}



	public function send_mail()
	{
        $from = 'hm.younas22@gmail.com';  // Mail Created  from your Server
        $to = 'phpfiverrpk@gmail.com'; // Receiver Email Address
	    
	   //Load email library 
        $this->load->library('email');

        $this->email->from($from, 'fraichee');
        $this->email->to($to);
        $this->email->subject('Email Test');
        $this->email->message('<html>
		<head>
		<title>Verfication</title>
		</head>
		<body>
			<p>Your verfication link is www.tecyoun.com</p>
		</body>
		</html>');

        //Send mail 
        if ($this->email->send())
            echo "sent";
        else
            echo "not sent";
	
	}



	public function order_details_mail($last_order_id)
	{
		$uid = $this->session->userdata('customer_id');
		$u_mail = $this->db->where('user_id',$uid)->get('users')->row();
		$order_details  = $this->customer->get_last_Order($uid,$last_order_id);
		$data['order_details'] = $order_details;

		$to = $u_mail->email;
        $from = 'customerservice@fraichee.com';
			   //Load email library 
        $this->load->library('email');
        $this->email->from($from, 'fraichee');
        $this->email->to($to);
        $this->email->subject('Fraichee Order confirmation');
         $msg = $this->load->view('html_template/confirm-order',$data,true);
        $this->email->message($msg);

        //Send mail 
		if($this->email->send()){
			return true;
		} 
		else{
			redirect('login/customer');
		}
	}

	public function success_msg($invoice_id)
	{
		$data['invoice_id'] = $invoice_id;
		$this->load->view('customer/pages/order_success', $data);
	}


	public function coupon_code()
	{
			$uid  = $this->session->userdata('customer_id');
			$coupon_code_val = $this->input->post('coupon_code');
			$admin_coupon_code = $this->db->get('coupon_code')->row();
			if ($coupon_code_val == $admin_coupon_code->coupon_code) {
	            $this->db->set(array(
	            	'coupon_code'=>$admin_coupon_code->coupon_code,
	            	'coupon_val'=>$admin_coupon_code->val,
	            	'coupon_status'=>1,
	            ));
	            $this->db->where('user_id',$uid);
	            $this->db->update('users');
	            echo "1";
			}else{
				echo "0";
			}


	}


function invoice_id() {
    $alphabet = '1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 4; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
}
?>