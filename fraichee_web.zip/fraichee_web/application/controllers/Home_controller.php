<?php 

defined('BASEPATH') or die('You can not directly access this file.');

class Home_controller extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('home_model');
		$this->load->helper('customer_helper'); 
	} /* construct() ends here */ 

	public function index(){
		$products    = $this->home_model->getProducts();
		$categories  = $this->home_model->getCategories();
		$data        = [
			'title'      => 'Home Page',
			'page_name'  => 'main',
			'categories' => $categories,
			'products'	 => $products,
		];

		$this->load->view('frontend/index', $data);
	} /* index() ends here */

	public function page( $page = '' ){
		$categories  = $this->home_model->getCategories();
		if( $page == 'homelinen' ){
			$data        = [
				'title'      => ucwords($page).' Page',
				'page_name'  => $page.'_page',
				'categories' => $categories,
			];
			$this->load->view('frontend/index',$data);
		}
		else if( $page == 'homepremium' ){
			$data        = [
				'title'      => ucwords($page).' Page',
				'page_name'  => $page.'_page',
				'categories' => $categories,
			];
			$this->load->view('frontend/index',$data);	
		}
		else if( $page == 'commercial' ){
			$data        = [
				'title'      => ucwords($page).' Page',
				'page_name'  => $page.'_page',
				'categories' => $categories,
			];
			$this->load->view('frontend/index',$data);	
		}
	} /* page() ends here */

	public function getChildProductDetails(){
		$prod_id = $this->input->post('prod_id');
		$cprod   = $this->home_model->getChildProducts($prod_id);
		$prod    = $this->home_model->getProduct($prod_id);
		$image   = $prod['image'];
		$img     = '<img src="assets/uploads/products/'.$image.'" class="img img-responsive" style="height:86px; width:144px;">';
		$div     = '';
		foreach($cprod as $prod):
			$div .= '<div class="col-md-6">'.
              '<div class="priceList  border-bottom border-primary  mb-3 pb-2">'.
                '<span class="text-left">'.ucwords($prod['cp_name']).'</span>'.
                '<span class="float-right font-weight-bold">£ '.$prod['cp_price'].'</span>'.
              '</div>'.
            '</div>';
		endforeach;
		$return  = [
			'image' => $img,
			'pricelist' => $div
		];
		echo json_encode($return);
		exit;
	} /* getChildProductDetails() */


	public function subscribe_mail()
	{
		$subscribe_mail = $this->input->post('subscribe_mail');
		$subscribe_mail = $this->db->insert('subscribers',array('sub_email'=>$subscribe_mail));
		if ($subscribe_mail) {
			echo json_encode($subscribe_mail);
		}
	}

	public function linen_subscription()
	{
		$categories  = $this->home_model->getCategories();
			$data        = [
					'title'      => 'linen subscription Page',
					'page_name'  => 'linen_subscription',
					'categories' => $categories,
				];
		 $this->load->view('frontend/index',$data);
	}

		public function forms_contact()
	{
		$forms_contact  = $this->input->post();
		$add_forms_contact = $this->db->insert('forms_contact',$forms_contact);
		if ($add_forms_contact) {
			$from = $this->input->post('email');
			$to = 'CustomerService@fraichee.com';

			$name = $this->input->post('name');
			$subject = $this->input->post('subject');
			$message = $this->input->post('message');

        $this->load->library('email');
        $this->email->from($from, $name);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);

        //Send mail 
		if($this->email->send()){
			redirect('message');
		} 
		else{
			redirect('message');
		}





		}
	}


	public function message()
	{
		$this->load->view('customer/pages/message');
	}
 

	public function mail_temp()
	{
		$data['url'] = base_url('11');
		$data['password'] = '1fd1';
		// $this->load->view('html_template/1',$data);

		// $panel = 'laundary';

		$uid = $this->session->userdata('customer_id');
    $this->db->select('cart_order.*,users.address,contact,name,email,contact');
    $this->db->where('users.user_id',41);
    $this->db->where('cart_order.order_id',95);
    $this->db->from('cart_order');
    $this->db->join('users', 'users.user_id = cart_order.user_id'); 
    $query = $this->db->get()->row();

    // echo "<pre>";
    // print_r($query);
    // exit;
    $data['order_details'] = $query;
		$this->load->view('html_template/7_',$data);

	}


	public function privacy_policy()
	{
		// $this->load->view('frontend/includes/privacy_policy');

			$products    = $this->home_model->getProducts();
			$categories  = $this->home_model->getCategories();
				$data        = [
			'title'      => 'privacy policy',
			'page_name'  => 'privacy_policy',
			'categories' => $categories,
			'products'	 => $products,
		];

		$this->load->view('frontend/index', $data);

	}

	public function terms_and_condition()
	{
			$products    = $this->home_model->getProducts();
			$categories  = $this->home_model->getCategories();
				$data        = [
			'title'      => 'terms and condition',
			'page_name'  => 'terms_and_condition',
			'categories' => $categories,
			'products'	 => $products
					];

		$this->load->view('frontend/index', $data);
	}
}
