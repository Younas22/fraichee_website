<?php  

defined('BASEPATH') or die('You can not directly access this file.');

class Admin_controller extends CI_Controller{
	private $admin_data;
	public function __construct(){ 
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('admin');
		$this->load->model('category_model', 'category');
		$this->load->model('admin_model','admin');
		$this->load->model('subscriber_model', 'booker');
		$this->admin_data  = $this->db->where(['user_id'=>$this->session->userdata('admin_id')])->get('users')->row();
	}
	/* constructor ends here */

	public function index( $role = '' ){
		if( !($this->session->userdata('admin_id'))){
			redirect('login/admin');
		}
		$orders    = $this->admin->countOrders();
		$users     = $this->admin->countUsers();

		$data				    = [
			'breadcrumb'	    => 'Dashboard', 
			'page_name'		    => 'admin/dashboard',
			'role'			    => 'admin',
			'admin_data'        => $this->admin_data,
			'total_order'       => $orders,
			'total_user'        => $users,
		];	
		$this->load->view('admin/index', $data );
	}
	/* index function ends here */

	public function products( $para1 = '' , $para2 = '' ){

		if( !($this->session->userdata('admin_id'))){
			redirect('login/admin');
		}
		if( $para1 == 'childproducts' ){
			$products           = $this->admin->getProducts();
			$prod_options       = [];
			foreach($products as $prod ){
				$id 			= $prod['prod_id'];
				$name 			= $prod['name'];
				$prod_options[$id] = $name;
			}
			$childproducts      = $this->admin->getChildProducts();
			$data				= [
				'role'			=> 'admin',
				'breadcrumb'	=> 'Child Products', 
				'page_name'		=> 'admin/child_products',
				'child_prod'    => $childproducts,
				'pprod_options' => $prod_options,
				'admin_data'        => $this->admin_data
			];	
		}
		else if( $para1 == 'childdel'){
			$deleted = $this->admin->deleteChildProduct($para2);
			if($deleted){
				redirect('products/childproducts');
			}
		}
		else if( $para1 == 'childedit'){
			$products           = $this->admin->getProducts();
			$cproduct           = $this->admin->getChildProduct($para2);
			$data				= [
				'role'			  => 'admin',
				'breadcrumb'	  => 'Edit Child Product', 
				'page_name'		  => 'admin/edit_childproduct',
				'product'         => $products,
				'child_prod'      => $cproduct,
				'admin_data'      => $this->admin_data
			];
		}
		else if($para1 == 'cprod_update'){
			$id      = $this->input->post('cpid');
			$pid     = $this->input->post('pid');
			$name    = $this->input->post('cp_name');
			$price   = $this->input->post('cp_price');
			$desc    = $this->input->post('cp_desc');
			$data    = [
				'prod_id'  => $pid,
				'cp_name'  => $name,
				'cp_price' => $price,
				'cp_desc'  => $desc,
			];
			$update  = $this->admin->updateChildProduct($id , $data );
			if($update){
				redirect('products/childproducts');
			}
		}
		else if($para1 == 'addproduct'){
			$pname    = $this->input->post('prod_name');
			$sid      = $this->input->post('service_type');
			$name     = '';
			if(!empty($_FILES['prod_image']['name'])){ 
				$name = $_FILES['prod_image']['name'];
				$path = 'assets/uploads/products/'.$name;
				$tmp_name = $_FILES['prod_image']['tmp_name'];
				$format   = explode('.',$name);
				$ext  = $format[1];
				if(in_array($ext, ['jpg','jpeg','png'])){
					if(move_uploaded_file($tmp_name, $path)){
						$data     = [
							'service_id' => $sid,
							'name'       => $pname,
							'image'      => $name,
							'date'    	 => date('Y-m-d H:i:s'),
						];
						$prodAdded = $this->admin->addProduct($data);
						if($prodAdded){
							redirect('products','refresh');
						}
					}
				}
				else{
					redirect('products','refresh');
				}
			}
		}
		else if($para1 == 'addchildproduct' ){
			$pp_id    = $this->input->post('parent_prod');
			$cp_name  = $this->input->post('child_prod_name');
			$cp_price = $this->input->post('cp_price');
			$cp_desc  = $this->input->post('cp_desc');
			$name     = '';
			if(!empty($_FILES['cp_image']['name'])){ 
				$name = $_FILES['cp_image']['name'];
				$path = 'assets/uploads/products/'.$name;
				$tmp_name = $_FILES['cp_image']['tmp_name'];
				$format   = explode('.',$name);
				$ext  = $format[1];
				if(in_array($ext, ['jpg','jpeg','png'])){
					if(move_uploaded_file($tmp_name, $path)){
						$service_id = getServiceId($pp_id);
						$data     = [
							'service_id' => $service_id,
							'prod_id'  => $pp_id,
							'cp_name'  => $cp_name,
							'cp_price' => $cp_price,
							'cp_desc'  => $cp_desc,
							'cp_image' => $name,
							'status'   => 'active',
						];
						$added    = $this->admin->addChildProduct($data);
						if( $added ){
							redirect('products/childproducts','refresh');
						}			
					}
				}else{
					redirect('products/childproducts','refresh');
				}
			}
			
		}
		else if( $para1 == 'edit' ){
			$product            = $this->admin->getProduct($para2);
			$services           = $this->admin->getServiceDetails();
			$data				= [
				'role'			  => 'admin',
				'breadcrumb'	  => 'Edit Product', 
				'page_name'		  => 'admin/edit_product',
				'product'         => $product,
				'services'        => $services,
				'admin_data'      => $this->admin_data
			];
		}
		else if($para1 == 'update'){
			$id      = $this->input->post('pid');
			$name    = $this->input->post('pname');
			$service = $this->input->post('stype');
			$data    = [
				'service_id' => $service,
				'name'       => $name,
			];
			$update  = $this->admin->updateProduct($id , $data );
			if($update){
				redirect('products');
			}
		}

		else if ($para1 == 'delete'){
			$deleted = $this->admin->deleteProduct($para2);
			if($deleted){
				redirect('products');
			}
		}
		else{
			$parent_products    = $this->admin->getProducts();
			$prod_category      = $this->admin->getServiceDetails();
			$data				= [
				'role'			  => 'admin',
				'breadcrumb'	  => 'Products', 
				'page_name'		  => 'admin/parent_products',
				'parent_prod'     => $parent_products,
				'prod_category'   => $prod_category,
				'admin_data'        => $this->admin_data
			];
		}
		$this->load->view('admin/index', $data );
	} /* products() ends here */

	public function categories( $para = '' , $para2 = '' ){
		if( !($this->session->userdata('admin_id'))){
			redirect('login/admin');
		}
		$serviceDetail      = $this->category->get_categories();
		$service_added      = $this->session->flashdata('data_name');
		if( $para == 'add_category' ){
			$cat_name       = $this->input->post('category_name');
			$panel_name     = $this->input->post('panel_name');
			$data           = [
				'name'      => strtolower($cat_name),
				'panel'     => $panel_name,
			];
			$category       = $this->category->add_category($data);
			if( $category ){
				$this->session->set_flashdata('data_name', 'data_value');
				redirect('categories', 'refresh');
			}
		}
		else if( $para == 'edit' ){
			$edit_id        = $para2;
			$getdata        = $this->category->getCategory($edit_id);
			$data           = [
				'role'      => 'admin',
				'breadcrumb'=> 'Edit Categories',
				'page_name' => 'admin/edit_categories',
				'admin_data'=> $this->admin_data,
				'category'	=> $getdata			
			];
		}
		else if( $para == 'update' ){
			$sid   = $this->input->post('sid');
			$sname = $this->input->post('sname');
			$update= $this->category->updateService($sid, $sname);
			if($update){
				redirect('categories');
			}
		}

		else if( $para == 'drop'){
			$deleted = $this->category->removeCategory($para2);
			if($deleted){
				redirect('categories');
			}
		}
		else{
			$data				= [
				'role'			=> 'admin',
				'breadcrumb'	=> 'Categories', 
				'page_name'		=> 'admin/categories_page',
				'cat_added_not' => $service_added,
				'cat_detail'    => $serviceDetail,
				'admin_data'    => $this->admin_data
			];	
		}
		$this->load->view('admin/index', $data );
	} /* categories() ends here */

	public function orders(){
		if( !($this->session->userdata('admin_id'))){
			redirect('login/admin');
		}
		$order_details      = $this->admin->getOrderDetail();
		// echo '<pre>';
		// print_r($order_details);exit;
		// echo '</pre>';
		$data				= [
			'role'			=> 'admin',
			'breadcrumb'	=> 'Orders', 
			'page_name'		=> 'admin/orderdetail_page',
			'order_details' => $order_details,
			'admin_data'    => $this->admin_data
		];
		$this->load->view('admin/index', $data );
	} /* orders() ends here */

	public function users( $para1 = '' , $para2 = ''){


		if( !($this->session->userdata('admin_id'))){
			redirect('login/admin');
		}

		if( $para1 == 'edit' ){
			echo 'edit user';exit;
		}
		else if( $para1 == 'drop' ){
			$user_id        = $para2;
			$user_deleted   = $this->admin->userDelete($user_id);
			if($user_deleted){
				redirect('admin/users');
			}
		}
		$users_list = $this->admin->getUsersList();

		// dd($users_list);

		$data				= [
			'role'			=> 'admin',
			'breadcrumb'	=> 'Users', 
			'page_name'		=> 'admin/bookerdetail_page',
			'users_list'    => $users_list,
			'admin_data'    => $this->admin_data
		];
		$this->load->view('admin/index', $data );
	} /* subscriber() ends here */

	public function setting($para1 = ''){

		if( !($this->session->userdata('admin_id'))){
			redirect('login/admin');
		}
		if($para1 == 'add'){
			$filename = $_FILES['logo']['name'];
			$tmpname  = $_FILES['logo']['tmp_name'];
			$type     = explode('.',$filename);
			$ext      = $type[1];
			$path     = 'assets/uploads/'.$filename;
			if(in_array($ext,['jpg','jpeg','png'])){
				$data = [
					'sname' => 'logo',
					'sval'  => $filename
				];
				$setting = $this->admin->saveSetting($data);
				if( isset($setting) && (move_uploaded_file($tmpname, $path)) ){
					redirect('setting');
				}
			}
		}
		else if($para1 == 'partners' ){
			// print_r($_FILES['partner']['name']);exit;
			$files = array_filter($_FILES['partner']['name']); //Use something similar before processing files.
			// Count the number of uploaded files in array
			$total_count = count($_FILES['partner']['name']);
			// Loop through every file
			for( $i=0 ; $i < $total_count ; $i++ ) {
			   //The temp file path is obtained
			   $tmpFilePath = $_FILES['partner']['tmp_name'][$i];
			   //A file path needs to be present
			   if ($tmpFilePath != ""){
			      //Setup our new file path
			      $newFilePath = 'assets/uploads/partner_icons/' . $_FILES['partner']['name'][$i];
			      //File is uploaded to temp dir
			      if(move_uploaded_file($tmpFilePath, $newFilePath)) {
			      	$file_name = json_encode($_FILES['partner']['name']);
			        $this->admin->partnerIcons($file_name);
			      }
			   }
			}
			redirect('setting');
			
		}
		else{
			$booker_details     = $this->booker->getBookerDetails();
			$data				= [
				'role'			=> 'admin',
				'breadcrumb'	=> 'Setting', 
				'page_name'		=> 'admin/setting_page',
				// 'booker_details'=> $booker_details
				'admin_data'        => $this->admin_data
			];
		}
		$this->load->view('admin/index', $data );
	} /* setting() ends here */

	public function servis_area()
	{
			$data = [
				'role'			=> 'admin',
				'breadcrumb'	=> 'servis area', 
				'page_name'		=> 'admin/servis_area',
				'admin_data'        => $this->admin_data
			];
		$this->load->view('admin/index', $data );
	}


		public function add_location()
	{

		if(!empty($_POST["keyword"])) {
		$curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.ideal-postcodes.co.uk/v1/autocomplete/addresses?api_key=iddqd&query='.$_POST["keyword"],
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		));

		$response = curl_exec($curl);
		curl_close($curl);
		$address_data = json_decode($response);

		if(!empty($address_data)) {
		echo '<ul class="list-unstyled">';
		foreach($address_data->result->hits as $key) {
			if ($key) {
				echo "<li>".$key->suggestion."</li>";
				echo "<hr>";
			}
		
		}
		echo "</ul>";
		} }
		}



	public function add_address()
	{
		$data=['address'=>$this->input->post('address')];
		$address = $this->db->where('id',1)->update('service_address',$data);
		redirect ('admin/servis-area');
	}



	public function add_coupen_code()
	{
		$data=[
			'coupon_code'=>$this->input->post('coupon_code'),
			'val'=>$this->input->post('coupon_val')
		];
		$address = $this->db->where('id',1)->update('coupon_code',$data);
		redirect ('admin/add-coupen');
	}


		public function add_coupen()
	{
			$data = [
				'role'			=> 'admin',
				'breadcrumb'	=> 'coupen code', 
				'page_name'		=> 'admin/coupen_code',
				'admin_data'        => $this->admin_data,
				'coupon'        => $this->db->get('coupon_code')->row()
			];
		$this->load->view('admin/index', $data);
	}



	public function subscription()
	{
		$data = [
			'role' =>'admin',
			'breadcrumb' =>'subscription', 
			'page_name' =>'admin/subscription',
			'admin_data'=> $this->admin_data,
			'subscription'=> $this->admin->get_subscription($panel='subscribe')
		];
		$this->load->view('admin/index', $data);
	}



	public function order_status()
	{
		$order_id = $this->input->post('order_id');
		$email = $this->input->post('email_val');
		$data=['status'=>$this->input->post('status_val')];
		$cart_order_status = $this->db->where('order_id',$order_id)->update('cart_order',$data);
		if ($cart_order_status) {
        $from = 'hm.younas22@gmail.com';  // Mail Created  from your Server
        $to = $email; // Receiver Email Address
	    
	   //Load email library 
        $this->load->library('email');

        $this->email->from($from, 'fraichee');
        $this->email->to($to);
        $this->email->subject('Order Details');
        $this->email->message('<html>
		<head>
		<title>Order Details</title>
		</head>
		<body>
			<p>Your order has been '.$this->input->post('status_val').'. if you have any question please contact us!</p>
		</body>
		</html>');

        //Send mail 
        if ($this->email->send()){
            echo "sent";
        }
        else{
            echo "not sent";
        }
		}

	}
}

?>