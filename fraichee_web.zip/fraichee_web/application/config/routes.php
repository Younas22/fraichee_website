	<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller']  = 'home_controller';

/* login controller started here */
$route['login']               = 'login_controller';
$route['login/(:any)']        = 'login_controller/index/$1';
$route['login/auth/(:any)']   = 'login_controller/loginAuth/$1';
$route['logout/(:any)']       = 'login_controller/logout/$1';
$route['signup']              = 'login_controller/signup';
$route['location']              = 'login_controller/location';
$route['forgot-password']              = 'login_controller/forgot_pass';
$route['reset-password']              = 'login_controller/reset_password';
$route['customer/verfication/(:any)']= 'login_controller/verfication/$1';
$route['account-verification']    = 'login_controller/user_verification';
/* login controller routes ends here */

/* admin controller routes */
$route['admin']				  = 'admin_controller';
// $route['admin/products']      = 'admin_controller/products';
$route['products']            = 'admin_controller/products';
// $route['admin/childproducts'] = 'admin_controller/products/childproducts';
$route['products/(:any)']     = 'admin_controller/products/$1';
$route['products/(:any)/(:any)']     = 'admin_controller/products/$1/$2';
$route['admin/servis-area']     = 'admin_controller/servis_area';
$route['admin/add-coupen']     = 'admin_controller/add_coupen';
$route['admin/update-coupen-code']     = 'admin_controller/add_coupen_code';
$route['add-location']     = 'admin_controller/add_location';
$route['admin/subscription']     = 'admin_controller/subscription';
$route['admin/order_status']     = 'admin_controller/order_status';

$route['admin/orders']		  = 'admin_controller/orders';
$route['admin/(:any)']	      = 'admin_controller/$1';
$route['admin/(:any)/(:any)/(:any)'] = 'admin_controller/$1/$2/$3';
/* categories routes */
$route['categories']		  = 'admin_controller/categories';
$route['categories/(:any)']	  = 'admin_controller/categories/$1';
$route['categories/(:any)/(:any)']	  = 'admin_controller/categories/$1/$2';
$route['setting']             = 'admin_controller/setting';
$route['setting/(:any)']      = 'admin_controller/setting/$1';
$route['add-address']              = 'admin_controller/add_address';
// $route['subscriber']		  = 'admin_controller/index/subscriber';
/* admin controller ends here */


$route['subscriber']		  = 'subscriber_controller';
// $route['subscriber/(:any)']   = 'subscriber_controller/$1';
// $route['subscriber/(:any)/(:any)']   = 'subscriber_controller/$1/$2';
$route['subscriber/orders']   = 'subscriber_controller/orders';
$route['subscriber/newOrder'] = 'subscriber_controller/orders/newOrder';
$route['subscriber/addOrder'] = 'subscriber_controller/orders/addOrder';
/* ends here */

/* customer controller starts here */
$route['customer']		      = 'customer_controller';
$route['customer/logout']     = 'customer_controller/customerLogout';
$route['customer/(:any)']     = 'customer_controller/index/$1';
$route['customer/remove-cart/(:any)/(:any)']     = 'customer_controller/remove_cart/$1/$2';
$route['customer/(:any)/(:any)']   = 'customer_controller/index/$1/$2';
$route['customer_ajax/(:any)']     = 'customer_controller/customerAjax/$1';
$route['subscribe_ajax/(:any)']    = 'customer_controller/subscribeAjax/$1';
$route['update_user_profile']    = 'customer_controller/update_customer_profile';
$route['subscription-details/(:any)']    = 'customer_controller/subscription_details/$1';
$route['subscription-view/(:any)']    = 'customer_controller/subscription_view/$1';
$route['subscription-remove/(:any)']    = 'customer_controller/subscription_remove/$1';
$route['subscription-cancel/(:any)']    = 'customer_controller/subscription_cancel/$1';
$route['success_msg/(:any)']    = 'customer_controller/success_msg/$1';
$route['coupon_code']    = 'customer_controller/coupon_code'; 

$route['send_mail']    = 'customer_controller/send_mail';
/* fraichee frontend */
$route['page/(:any)']         = 'home_controller/page/$1';
$route['subscribe_mail']         = 'home_controller/subscribe_mail';
$route['linen-subscription']         = 'home_controller/linen_subscription';
$route['privacy-policy']         = 'home_controller/privacy_policy';
$route['terms-and-condition']         = 'home_controller/terms_and_condition';
$route['forms_contact']         = 'home_controller/forms_contact';
$route['message']         = 'home_controller/message';
$route['mail_temp']         = 'home_controller/mail_temp';
/* frontend routes ends here */

$route['404_override']        = '';
$route['translate_uri_dashes'] = FALSE;
