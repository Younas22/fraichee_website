<?php defined('BASEPATH') OR exit('No direct script access allowed');


        $config = array();
        $config['useragent']           = "CodeIgniter";
        $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
        $config['protocol']            = "smtp";
        $config['smtp_host']           = "localhost";
        $config['smtp_port']           = "25";
        $config['mailtype'] = 'html';
        $config['charset']  = 'utf-8';
        $config['priority']  = '1';
        $config['newline']  = "\r\n";
        $config['wordwrap'] = TRUE;
        