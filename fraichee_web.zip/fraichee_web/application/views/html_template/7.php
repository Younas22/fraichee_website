<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Order Confirmation</title>
		<!-- Favicon -->
		<link rel="icon" href="./images/favicon.png" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" href="<?=base_url('assets/bootstrap/csss/bootstrap.min.css')?>">

	<script src="<?=base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
	<script src="<?=base_url('assets/bootstrap/csss/jquery-3.5.1.slim.min.js')?>"></script>

		<!-- Invoice styling -->
		<style>
			body {
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-ser<?=base_url('assets/bootstrap/js/bootstrap.min.js')?>if;
				/*text-align: center;*/
				color: #777;
			}
			body h1 {
				font-weight: 300;
				margin-bottom: 0px;
				padding-bottom: 0px;
				color: #000;
			}
			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style: italic;
				color: #555;
			}
			body a {
				color: #06f;
			}
			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}
			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
				border-collapse: collapse;
			}
			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}
			.invoice-box table tr td:nth-child(2) {
				text-align: right;
			}
			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}
			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}
			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}
			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}
			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}
			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}
			.invoice-box table tr.item.last td {
				border-bottom: none;
			}
			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}
			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}
				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}
		</style>
	</head>
	<body>
		<div class="invoice-box"><h4>Order confirmation email #<?=$order_details->invoice_id?></h4>
			<img src="<?=base_url('assets/uploads/2222_10x.png')?>" alt="Company logo" style="width: 100%; height: 250px;" />
			<div class="row mt-3">
				<div class="col-lg-6">
					<h5 style="color: black;">Thank you for your order</h5>
					<p>Your order number is <b><?= $order_details->invoice_id; ?></b>. Your order will be picked up on selected date and will be delivered back on <?php echo "Due: <b>". date('M d, Y', strtotime($order_details->delivery_days)) ."</b>" ?></p>
				</div>
				<div class="col-lg-6">
					<h5 style="color: black;">Pick Ups and all delivery</h5>
					<p>Please note all pickups and deliveries are done from 18:00 to 23:00</p>
				</div>
			</div>
			<table class="d-none">
				<tr class="top">
					<td colspan="2">
						<table>
							<tr>
								<td class="title">
									<img src="<?=base_url('assets/uploads/2222_10x.png')?>" alt="Company logo" style="width: 100%; max-width: 300px" />
								</td>
								<td>
									Invoice #: <?=$order_details->order_id?><br />
									Created: <?php echo date('M d, Y', strtotime($order_details->date)) ?><br />

									<?php
									if (empty($order_details->delivery_options)) {
										echo "Due: ". date('M d, Y', strtotime($order_details->delivery_days));
									}
									?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr class="information">
					<td colspan="2">
						<table>
							<tr>
								<td>
									<?= $order_details->address ?><br/>
									<!-- 12345 Sunny Road<br/> -->
									
									<?php
									if (!empty($order_details->other_address)) {
										echo '<p style="color:red">Other Address:'.$order_details->other_address.'</p>';
									}else{
										echo '<p style="color:red">Other Address: Nothing New Address</p>';
									}
									?>
								</td>
								<td>
									<?= $order_details->name ?><br />
									<?= $order_details->email ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<style>
			.table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
			}
			.td, .th {
			border: 1px solid #dddddd;
			text-align: left !important;
			padding: 8px;
			}
			.tr:nth-child(even) {
			background-color: #dddddd;
			}
			</style>

<?php if ($order_details->type == 'subscribe') {?>
			<h2>Here is your order summary</h2>
			<hr>
			<?php echo 
			$order_details->first_day. " ".
			$order_details->second_day. " ".
			$order_details->therd_day. " ".
			$order_details->fourth_day;
			 ?>
			<table class="table">
				<tr class="tr">
					<th class="th">Item</th>
					<th class="th">Qty</th>
					<th class="th">Price</th>
				</tr>
				<?php  $count = 1;
				$cartdata = json_decode($order_details->cart_details);
				$new_cart = [];
				foreach($cartdata as $cdk => $cdval ){
				$new_cart[$cdk] = [
				'prod_id' => $cdval->prod_id,
				'cp_id'   => $cdval->cp_id,
				'cart_qty'=> $cdval->cart_qty,
				'price'   => $cdval->price,
				'delivery_days' => $cdval->delivery_days
				];
				}
				foreach($new_cart as $nkey => $nval):
				$prod_id  = $nval['prod_id'];
				$cp_id    = $nval['cp_id'];
				$cart_qty = $nval['cart_qty'];
				$per_price= $nval['price'];
				$ddays    = $nval['delivery_days'];
				$prod_img = getprodimage($prod_id,$cp_id);
				$getprodname = getprodname($cp_id);
				?>
				<tr class="tr">
					<td class="td"><?=$getprodname->cp_name?></td>
					<td class="td"><?=$cart_qty?></td>
					<td class="td">£<?=$per_price?></td>
				</tr>
				<?php endforeach; ?>
			</table>
<?php }else{ ?>
				<h4 class="text-center">Here is your order summary</h4>
			<table class="table">
				<tr class="tr">
					<th class="th">Item</th>
					<th class="th">Order No</th>
					<th class="th">Qty</th>
					<th class="th">Price</th>
				</tr>
				<?php  $count = 1;
				$cartdata = json_decode($order_details->cart_details);
				$new_cart = [];
				foreach($cartdata as $cdk => $cdval ){
				$new_cart[$cdk] = [
				'prod_id' => $cdval->prod_id,
				'cp_id'   => $cdval->cp_id,
				'cart_qty'=> $cdval->cart_qty,
				'price'   => $cdval->price,
				'delivery_days' => $cdval->delivery_days
				];
				}

				$count = 1;
				foreach($new_cart as $nkey => $nval):
				$prod_id  = $nval['prod_id'];
				$cp_id    = $nval['cp_id'];
				$cart_qty = $nval['cart_qty'];
				$per_price= $nval['price'];
				$ddays    = $nval['delivery_days'];
				$prod_img = getprodimage($prod_id,$cp_id);
				$getprodname = getprodname($cp_id);
				?>
				<tr class="tr">
					<td class="td"><?=$getprodname->cp_name?></td>
					<td class="td"><?=$count?></td>
					<td class="td"><?=$cart_qty?></td>
					<td class="td">£<?=$per_price?></td>
				</tr>
				<?php $count++; endforeach; ?>
			</table>
<?php } ?>


			<h2 style="float:right;">Total: £<?= $order_details->total_amount ?></h2>
			<br>
			<br>
			<hr>
			<h4 class="text-center text-dark">Your Order is to be picked up and delivered to</h4>
			<h6 class="text-center"><?=$order_details->name?></h6>
			<?php if ($order_details->address == 'Address Not Found!' or empty($order_details->address)) { ?>
			<h6 class="text-center"><?=$order_details->other_address?></h6>
			<?php }else{ ?>
			<h6 class="text-center"><?=$order_details->address?></h6>
			<?php } ?>

			<h6 class="text-center"><?=$order_details->contact?></h6>
			<br>
			<br>
			<br>
			<h4 class="text-center">Got Questions</h4>
			<p>Call us +447960381323 between 9am - 18pm. Or email us at <a href="customerservice@fraichee.com">customerservice@fraichee.com</a></p>
		</div>
	</body>
</html>