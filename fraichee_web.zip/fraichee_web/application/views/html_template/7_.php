<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Order Confirmation</title>
		<!-- Favicon -->
		<link rel="icon" href="./images/favicon.png" type="image/x-icon" />

		<!-- Invoice styling -->
		<style>
			body {
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				/*text-align: center;*/
				color: #777;
			}
			body h1 {
				font-weight: 300;
				margin-bottom: 0px;
				padding-bottom: 0px;
				color: #000;
			}
			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style: italic;
				color: #555;
			}
			body a {
				color: #06f;
			}
			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}
			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
				border-collapse: collapse;
			}
			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}
			.invoice-box table tr td:nth-child(2) {
				text-align: right;
			}
			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}
			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}
			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}
			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}
			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}
			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}
			.invoice-box table tr.item.last td {
				border-bottom: none;
			}
			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}
			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}
				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}


			@media (min-width: 992px){
			.col-lg-6 {
			    -ms-flex: 0 0 50%;
			    flex: 0 0 50%;
			    max-width: 50%;
				}
			}

			/*table*/
			.table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
			}
			.td, .th {
			border: 1px solid #dddddd;
			text-align: left !important;
			padding: 8px;
			}
			.tr:nth-child(even) {
			background-color: #dddddd;
			}

/*////////////////////////////////////////////////////////*/


			h4 {
			    font-size: 1.5rem;
			}

			h5 {
			    font-size: 1.25rem;
			}
			h6 {
			    font-size: 1rem;
			}

			h4, h5 {
			    display: block;
			    margin-block-start: 1.33em;
			    margin-block-end: 1.33em;
			    margin-inline-start: 0px;
			    margin-inline-end: 0px;
			    margin-top: 0;
			    margin-bottom: .5rem;
			    font-weight: 500;
			    line-height: 1.2;
			}

			h6 {
		    display: block;
		    margin-block-start: 2.33em;
		    margin-block-end: 2.33em;
		    margin-inline-start: 0px;
		    margin-inline-end: 0px;
		    font-weight: bold;
		    margin-bottom: .5rem;
		    font-weight: 500;
		    line-height: 1.2;
		    margin-top: 0;
		}

			.mt-3, .my-3 {
			    margin-top: 1rem!important;
			}

			p {
			    margin-top: 0;
			    margin-bottom: 1rem;
			}

			p {
			    display: block;
			    margin-block-start: 1em;
			    margin-block-end: 1em;
			    margin-inline-start: 0px;
			    margin-inline-end: 0px;
			}



			.row {
			    display: -ms-flexbox;
			    display: flex;
			    -ms-flex-wrap: wrap;
			    flex-wrap: wrap;
			    margin-right: -15px;
			    margin-left: -15px;
			}


.col, .col-1, .col-10, .col-11, .col-12, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-auto, .col-lg, .col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-auto, .col-md, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-auto, .col-sm, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-auto, .col-xl, .col-xl-1, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-auto {
position: relative;
width: 100%;
padding-right: 15px;
padding-left: 15px;
}

div {
    display: block;
}

*, ::after, ::before {
    box-sizing: border-box;
}

.text-center {
    text-align: center!important;
}


hr {
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 0;
    border-top: 1px solid rgba(0,0,0,.1);
}

hr {
    box-sizing: content-box;
    height: 0;
    overflow: visible;
}
		</style>
	</head>
	<body>
		<div class="invoice-box"><h4>Order confirmation email #<?=$order_details->invoice_id?></h4>
			<img src="<?=base_url('assets/uploads/2222_10x.png')?>" alt="Company logo" style="width: 100%; height: 250px;" />
			<div class="row mt-3">
				<div class="col-lg-6">
					<h5 style="color: black;">Thank you for your order</h5>
					<p>Your order number is <b><?= $order_details->invoice_id; ?></b>. Your order will be picked up on selected date and will be delivered back on <?php echo "Due: <b>". date('M d, Y', strtotime($order_details->delivery_days)) ."</b>" ?></p>
				</div>
				<div class="col-lg-6">
					<h5 style="color: black;">Pick Ups and all delivery</h5>
					<p>Please note all pickups and deliveries are done from 18:00 to 23:00</p>
				</div>
			</div>


<?php if ($order_details->type == 'subscribe') {?>
			<h2>Here is your order summary</h2>
			<hr>
			<?php echo 
			$order_details->first_day. " ".
			$order_details->second_day. " ".
			$order_details->therd_day. " ".
			$order_details->fourth_day;
			 ?>
			<table class="table">
				<tr class="tr">
					<th class="th">Item</th>
					<th class="th">Qty</th>
					<th class="th">Price</th>
				</tr>
				<?php  $count = 1;
				$cartdata = json_decode($order_details->cart_details);
				$new_cart = [];
				foreach($cartdata as $cdk => $cdval ){
				$new_cart[$cdk] = [
				'prod_id' => $cdval->prod_id,
				'cp_id'   => $cdval->cp_id,
				'cart_qty'=> $cdval->cart_qty,
				'price'   => $cdval->price,
				'delivery_days' => $cdval->delivery_days
				];
				}
				foreach($new_cart as $nkey => $nval):
				$prod_id  = $nval['prod_id'];
				$cp_id    = $nval['cp_id'];
				$cart_qty = $nval['cart_qty'];
				$per_price= $nval['price'];
				$ddays    = $nval['delivery_days'];
				$prod_img = getprodimage($prod_id,$cp_id);
				$getprodname = getprodname($cp_id);
				?>
				<tr class="tr">
					<td class="td"><?=$getprodname->cp_name?></td>
					<td class="td"><?=$cart_qty?></td>
					<td class="td">£<?=$per_price?></td>
				</tr>
				<?php endforeach; ?>
			</table>
<?php }else{ ?>
				<h4 class="text-center">Here is your order summary</h4>
			<table class="table">
				<tr class="tr">
					<th class="th">Item</th>
					<th class="th">Order No</th>
					<th class="th">Qty</th>
					<th class="th">Price</th>
				</tr>
				<?php  $count = 1;
				$cartdata = json_decode($order_details->cart_details);
				$new_cart = [];
				foreach($cartdata as $cdk => $cdval ){
				$new_cart[$cdk] = [
				'prod_id' => $cdval->prod_id,
				'cp_id'   => $cdval->cp_id,
				'cart_qty'=> $cdval->cart_qty,
				'price'   => $cdval->price,
				'delivery_days' => $cdval->delivery_days
				];
				}

				$count = 1;
				foreach($new_cart as $nkey => $nval):
				$prod_id  = $nval['prod_id'];
				$cp_id    = $nval['cp_id'];
				$cart_qty = $nval['cart_qty'];
				$per_price= $nval['price'];
				$ddays    = $nval['delivery_days'];
				$prod_img = getprodimage($prod_id,$cp_id);
				$getprodname = getprodname($cp_id);
				?>
				<tr class="tr">
					<td class="td"><?=$getprodname->cp_name?></td>
					<td class="td"><?=$count?></td>
					<td class="td"><?=$cart_qty?></td>
					<td class="td">£<?=$per_price?></td>
				</tr>
				<?php $count++; endforeach; ?>
			</table>
<?php } ?>


			<h2 style="float:right;">Total: £<?= $order_details->total_amount ?></h2>
			<br>
			<br>
			<hr>
			<h4 class="text-center text-dark">Your Order is to be picked up and delivered to</h4>
			<h6 class="text-center"><?=$order_details->name?></h6>
			<?php if ($order_details->address == 'Address Not Found!' or empty($order_details->address)) { ?>
			<h6 class="text-center"><?=$order_details->other_address?></h6>
			<?php }else{ ?>
			<h6 class="text-center"><?=$order_details->address?></h6>
			<?php } ?>

			<h6 class="text-center"><?=$order_details->contact?></h6>
			<br>
			<br>
			<br>
			<h4 class="text-center">Got Questions</h4>
			<p>Call us +447960381323 between 9am - 18pm. Or email us at <a href="customerservice@fraichee.com">customerservice@fraichee.com</a></p>
		</div>
	</body>
</html>