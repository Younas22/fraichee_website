<?php  
$logo     = $this->db->where(['sname' => 'logo' ])->get('settings')->row()->sval;
$this->load->view('frontend/includes/head',['logo'=>$logo]);
$this->load->view('frontend/includes/header',['logo'=>$logo]); 
$this->load->view('frontend/includes/hero_section'); 
$this->load->view('frontend/includes/'.$page_name); 
$this->load->view('frontend/includes/footer');
$this->load->view('frontend/includes/bottom');  
?>