<!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
<div class="footer-subfooter">

      <center class="mb-2">
        <a href="<?=base_url()?>" title="home page" aria-current="page">
        <img class="footer-subfooterLogo" id="footer-subfooterLogo" src="<?=base_url('assets/uploads/2222_10x.png');?>" alt="O'Reilly home" width="150" height="50">
      </a>
      </center>

          <div class="col-lg-12 text-lg-center text-center mt-1">
            Fraichee LTD. Place of registration: England and Wales. 
            Registered number: 12965743
          <div class="copyright">
            &copy; Copyright <strong>Fraichee</strong>. All Rights Reserved
          </div>
          <div class="credits">
            Designed by <a href="https://www.tecyoun.com/">TECYOUN</a>
          </div>
        </div>
    </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url() ?>assets/frontend/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/aos/aos.js"></script>
  <!-- Template Main JS File -->
  <script src="<?php echo base_url() ?>assets/frontend/js/main.js"></script>


  <script>
    
    $(function(){

      $('#newsletter').click(function(){
        let subscribe_mail = $('#subscribe_mail').val();
        //alert(subscribe_mail);

    $.ajax({
     url:'<?=base_url('subscribe_mail')?>',
     method: 'post',
     data: {subscribe_mail: subscribe_mail},
     dataType: 'json',
     success: function(response){
        if (response) {
          $("#mail_msg").append("<div class='alert alert-success' id='message' role='alert'>Thank you for joining our Newsletter</div>");
          $('#mail_msg').delay(5000).fadeOut('slow');
        }else{
          alert('Something is wrong!');
        }

 
     }
   });

      });

    });


  </script>
</body>

</html>