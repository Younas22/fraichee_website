<main id="main">

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients clients">
      <div class="container">

        <div class="row">
          <?php $partners = json_decode(partnerIcons()->sval); 
          if(!empty($partners)){
          foreach($partners as $partner){
          ?>
          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/uploads/partner_icons/<?php echo $partner;?>" class="img-fluid" alt="" data-aos="zoom-in">
          </div>
          <?php } }?>
          <!-- <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-1.png" class="img-fluid" alt="" data-aos="zoom-in">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-2.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="100">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-3.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="200">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-4.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="300">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-5.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="400">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-6.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="500">
          </div> -->

        </div>

      </div>
    </section><!-- End Clients Section -->

    <!-- =========== Details Section =========== -->
    <section class="<?php echo $page_name; ?>-details">
      <div class="container">

        <div class="section-title pt-4" data-aos="fade-up">
          <h2>Commercial laundary Services from Fraichee</h2>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <div class="col-md-12">
            <p>Our team has knowledge and experience to help your business succeed by utilising the skills and experience we have gained through working in the laundary services business, we provide a wide raneg of customized Linen and Laundary services that are suitable for companies of all sizes and all kinds.</p>

            <p>We aim in building a long-term relationship with all our clients and help smoothen the functionality of their business. We provide a wide range of services for business including linedn hire, laundry services and dry cleaning services. We provide services to a wide range of businesses.</p>
          </div>
        </div>

        <div class="section-title pt-4" data-aos="fade-up">
          <h2>Hotel</h2>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <div class="col-md-6 order-1 p-0">
            <img src="<?php echo base_url(); ?>assets/frontend/img/commercial/commercial1.png" class="img img-thumbnail border-0">
          </div>
          <div class="col-md-6 order-2 p-0">
            <p>
              <ul>
               <li>We offer linen on hire basis and laundry service for any size hotels</li>
                <li>Our services can be on demand</li>
                <li>No minimum order</li>
                <li>Our services are responsive to a change in demand</li>
                <li>Quality products</li>
                <li>We offer variety of linen products upto 2000 thread count</li>
                <li>Anywhere in the UK</li>
              </ul>
            </p>
          </div>
        </div>

        <div class="section-title pt-4" data-aos="fade-up">
          <h2>Restaurant</h2>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
          
          <div class="col-md-6 order-sm-2 order-2 order-md-1 order-lg-1 p-0">
            <p>
              <ul>
                <li>We offer linen on hire basis and laundry service</li>
                <li>Variety of Restaurant Linen available</li>
                <li>Our services can be offered as a subscription or on demand</li>
                <li>No minimum order</li>
                <li>Our services are responisve to chnage in demand</li>
              </ul>
            </p>
          </div>
          <div class="col-md-6 order-sm-1 order-1 order-md-2 order-lg-2 p-0">
            <img src="<?php echo base_url(); ?>assets/frontend/img/commercial/commercial2.jpg" class="img img-thumbnail border-0">
          </div>
        </div>

        <div class="section-title pt-4" data-aos="fade-up">
          <h2>Airline</h2>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <div class="col-md-6 order-1 p-0">
            <img src="<?php echo base_url(); ?>assets/frontend/img/commercial/commercial3.jpg" class="img img-thumbnail border-0">
          </div>
          <div class="col-md-6 order-2 p-0">
            <p>
              <ul>
                <li>Your Needs can be filled depending on you request</li>
                <li>Our services can be offered on demand</li>
                <li>Quality products and services</li>
                <li>Responsive to a change in demand</li>
                <li>Fast delivery, free pick up and delivery on a daily basis</li>
              </ul>
            </p>
          </div>
        </div>

        <div class="section-title pt-4" data-aos="fade-up">
          <h2>Airbnb</h2>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
          
          <div class="col-md-6 order-sm-2 order-2 order-md-1 order-lg-1 p-0">
            <p>
              <ul>
                <li>We offer linen on hire basis and laundry service</li>
                <li>We have a variety of high quality linen</li>
                <li>Our services can be provided on subscription or on demand</li>
                <li>Our services are responsive to a change in demand</li>
                <li>Fast delivery, free pick up and delivery on a daily basis</li>
              </ul>
            </p>
          </div>
          <div class="col-md-6 order-sm-1 order-1 order-md-2 order-lg-2 p-0">
            <img src="<?php echo base_url(); ?>assets/frontend/img/commercial/commercial4.jpg" class="img img-thumbnail border-0">
          </div>
        </div>

        <div class="section-title pt-4" data-aos="fade-up">
          <h2>Hospital</h2>
        </div>
        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <div class="col-md-6 order-1 p-0">
            <img src="<?php echo base_url(); ?>assets/frontend/img/commercial/commercial5.jpg" class="img img-thumbnail border-0">
          </div>
          <div class="col-md-6 order-2 p-0">
            <p>
              <ul>
                <li>We  provide linen on hire basis or laundary service for any size hospitals</li>
                <li>Our serivices can be provided on subscription or on demand </li>
                <li>We offer quality products and services</li>
                <li>Fast delivery, free pick up and delivery on a daily basis</li>
                <li>No minimum order</li>
                <li>Variety of linen products upto 2000 thread count</li>
                <li>Any where in the UK</li>
              </ul>
            </p>
          </div>
        </div>

      </div>
    </section>
    <!-- end here -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Get a Quote</h2>
          <h6>Send us your requirements and one of our experienced team member will get back to you with a quote.</h6>
        </div>

        <div class="row">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="contact-about">
              <h3>Fraichee</h3>
              <p>At Fraîchee we believe that laundry services are a necessity which should be affordable and reliable to all, which is why we aim at maintaining top quality services at optimised prices. Fraîchee is here to serve everyone that is within our reach with passion and drive.Your comfort is our priority.</p>
              <div class="social-links">
                <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
                <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
                <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
                <a href="#" class="linkedin"><i class="icofont-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="info">
              <div>
                <i class="ri-map-pin-line"></i>
                <p>Fraichee LTD Kemp House, 160 City Road London EC1V 2NX</p>
              </div>

              <div>
                <i class="ri-mail-send-line"></i>
                <p>customerservice@fraichee.com</p>
              </div>

              <div>
                <i class="ri-phone-line"></i>
                <p>+44 74 04141235</p>
              </div>

            </div>
          </div>

          <div class="col-lg-5 col-md-12" data-aos="fade-up" data-aos-delay="300">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Get a Quote</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->