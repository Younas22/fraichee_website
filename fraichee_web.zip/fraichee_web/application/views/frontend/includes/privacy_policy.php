 <style>


.bg-no-overlay {

background: url("<?=base_url('assets/frontend/img/security.jpg')?>");
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    color: #fff;
    height: 300px;
    padding-top: 50px;
}

.ol { counter-reset: item }
.li{ display: block }
.li:before { content: counters(item, ".") " "; counter-increment: item }

 </style>

<div class=" bg-no-overlay">
    <div class="text-center" style="margin-top:100px;">

		<h1 class="mt-5"> Privacy Policy</h1>
	</div>
</div>
 
		<div id="how-it-works" style="margin-top:100px;">
			<div class="content-wrap">
			<div class="container">

				<div class="row">
					<div class="col-sm-12 col-md-12">
						
						<h5 class="text-center">Type of website: Ecommerce</h5>
						<h5 class="text-center">Effective date: 22nd day of August, 2021</h5>
<p class="text-justify">www.fraichee.com (the "Site") is owned and operated by Fraichee LTD. Fraichee LTD is the data controller and can be contacted at:</p>

<h6>customerservice@fraichee.com</h6>
<h6>07960 381323</h6>
<h6>Fraichee LTD Kemp House, 160 City Road London EC1V 2NX</h6>
<br><br>
	<ol>
		<li class="text-justify"><b>Purpose</b>
			<p>The purpose of this privacy policy (this "Privacy Policy") is to inform users of our Site of the
following: </p>
			<ol>
				<li class="text-justify">The personal data we will collect</li>
				<li class="text-justify">Use of collected data</li>
				<li class="text-justify">Who has access to the data collected</li>
				<li class="text-justify">The rights of Site users</li>
				<li class="text-justify">The Site's cookie policy</li>

			</ol>
			<p>This Privacy Policy applies in addition to the terms and conditions of our Site.</p>
		</li>



		<br><br><li class="text-justify"><b>GDPR</b>
			<p>For users in the European Union, we adhere to the Regulation (EU) 2016/679 of the European
Parliament and of the Council of 27 April 2016, known as the General Data Protection Regulation
(the "GDPR"). For users in the United Kingdom, we adhere to the GDPR as enshrined in the Data
Protection Act 2018.<br><br>
We have not appointed a Data Protection Officer as we do not fall within the categories of
controllers and processors required to appoint a Data Protection Officer under Article 37 of the
GDPR. </p>
		</li>



		<br><br><li class="text-justify"><b>Consent</b>
			<p>By using our Site users agree that they consent to:</p>
			<ol>
				<li class="text-justify">The conditions set out in this Privacy Policy.
When the legal basis for us processing your personal data is that you have provided your consent to
that processing, you may withdraw your consent at any time. If you withdraw your consent, it will
not make processing which we completed before you withdrew your consent unlawful.
You can withdraw your consent by: Emailing customerservice@fraichee.com.
</li>

			</ol>
		</li>



<br><br><li class="text-justify"><b>Legal Basis for Processing</b>
	<p>We collect and process personal data about users in the EU only when we have a legal basis for
	doing so under Article 6 of the GDPR. </p><br>
	<p>We rely on the following legal bases to collect and process the personal data of users in the EU:
	</p>
	<ol>
		<li class="text-justify">Users have provided their consent to the processing of their data for one or more specific
			purposes
		</li>
		<li class="text-justify">Processing of user personal data is necessary to a task carried out in the public interest or in
			the exercise of our official authority.
		</li>
	</ol>
</li>


<br><br><li class="text-justify"><b>Personal Data We Collect</b>
	<p>We only collect data that helps us achieve the purpose set out in this Privacy Policy. We will not
collect any additional data beyond the data listed below without notifying you first.</p><br>
	<p style="-webkit-text-decoration-line: underline; /* Safari */
   text-decoration-line: underline">Data Collected in a Non-Automatic Way</p>
	<p>We may also collect the following data when you perform certain functions on our Site:</p>
	<ol>
		<li class="text-justify">First and last name</li>
		<li class="text-justify">Email address</li>
		<li class="text-justify">Phone number</li>
		<li class="text-justify">Address</li>
		<li class="text-justify">Payment information</li>
	</ol>
			<p>This data may be collected using the following methods:</p>
		<ol><li>Creating an account</li></ol>
</li>




<br><br><li class="text-justify"><b>How We Use Personal Data</b>
	<p>Data collected on our Site will only be used for the purposes specified in this Privacy Policy or
Website Privacy Policy Page 2 of 5
indicated on the relevant pages of our Site. We will not use your data beyond what we disclose in
this Privacy Policy.</p><br>
	<p>The data we collect when the user performs certain functions may be used for the following
purposes:</p>
	<ol>
		<li class="text-justify">Delivery</li>
		<li class="text-justify">Communication</li>
	</ol>
</li>



<br><br><li class="text-justify"><b>Who We Share Personal Data With</b>
	<p style="   -webkit-text-decoration-line: underline; /* Safari */
   text-decoration-line: underline">Employees</p>
	<p>We may disclose user data to any member of our organisation who reasonably needs access to user
data to achieve the purposes set out in this Privacy Policy.</p>

<p style="   -webkit-text-decoration-line: underline; /* Safari */
   text-decoration-line: underline">Other Disclosures</p>
<p>We will not sell or share your data with other third parties, except in the following cases:</p>
	<ol>
		<li class="text-justify">If the law requires it</li>
		<li class="text-justify">If it is required for any legal proceeding</li>
		<li class="text-justify">To prove or protect our legal rights</li>
		<li class="text-justify">To buyers or potential buyers of this company in the event that we seek to sell the company</li>
	</ol>
	<p>If you follow hyperlinks from our Site to another Site, please note that we are not responsible for
and have no control over their privacy policies and practices.</p>
</li>




<br><br><li class="text-justify"><b>How Long We Store Personal Data</b>
	<p>User data will be stored until the purpose the data was collected for has been achieved.</p>

<p>You will be notified if your data is kept for longer than this period.
</p>
</li>




<br><br><li class="text-justify"><b>How We Protect Your Personal Data</b>
	<p>In order to protect your security, we use the strongest available browser encryption and store all of
our data on servers in secure facilities. All data is only accessible to our employees. Our employees
are bound by strict confidentiality agreements and a breach of this agreement would result in the
employee's termination</p>

<p>While we take all reasonable precautions to ensure that user data is secure and that users are
protected, there always remains the risk of harm. The Internet as a whole can be insecure at times and therefore we are unable to guarantee the security of user data beyond what is reasonably
practical.</p>
</li>



<br><br><li class="text-justify"><b>Your Rights as a User</b>
	<p>Under the GDPR, you have the following rights:</p>
	<ol>
		<li class="text-justify">Right to be informed</li>
		<li class="text-justify">Right of access</li>
		<li class="text-justify">Right to rectification</li>
		<li class="text-justify">Right to erasure</li>
		<li class="text-justify">Right to restrict processing</li>
		<li class="text-justify">Right to data portability</li>
		<li class="text-justify">Right to object</li>
	</ol>
</li>




<br><br><li class="text-justify"><b>Children</b>
	<p>The minimum age to use our website is 18 years of age. We do not knowingly collect or use
personal data from children under 16 years of age. If we learn that we have collected personal data
from a child under 16 years of age, the personal data will be deleted as soon as possible. If a child
under 16 years of age has provided us with personal data their parent or guardian may contact our
privacy officer.</p>
</li>




<br><br><li class="text-justify"><b>How to Access, Modify, Delete, or Challenge the Data Collected</b>
	<p>If you would like to know if we have collected your personal data, how we have used your personal
data, if we have disclosed your personal data and to who we disclosed your personal data, if you
would like your data to be deleted or modified in any way, or if you would like to exercise any of
your other rights under the GDPR, please contact our privacy officer here:</p>

<br>
<p>Reagan Tumushabe</p>
<p>Tumushabereagan@gmail.com</p>
<p>07540 061409</p>
<p>154 brierley, CR0 9DS</p>
</li>





<br><br><li class="text-justify"><b>Cookie Policy</b>
	<p>A cookie is a small file, stored on a user's hard drive by a website. Its purpose is to collect data
relating to the user's browsing habits. You can choose to be notified each time a cookie is
transmitted. You can also choose to disable cookies entirely in your internet browser, but this may
decrease the quality of your user experience.

We use the following types of cookies on our Site:</p>
	<ol>
		<li class="text-justify" style="   -webkit-text-decoration-line: underline; /* Safari */
   text-decoration-line: underline"><b>Functional cookies</b></li>
		<p>Functional cookies are used to remember the selections you make on our Site so that your
selections are saved for your next visits;</p>
		<li class="text-justify" style="   -webkit-text-decoration-line: underline; /* Safari */
   text-decoration-line: underline"><b>Analytical cookies</b></li>
		<p>Analytical cookies allow us to improve the design and functionality of our Site by collecting
data on how you access our Site, for example data on the content you access, how long you
stay on our Site, etc.</p>
	</ol>
</li>





<br><br><li class="text-justify"><b>Modifications</b>
	<p>This Privacy Policy may be amended from time to time in order to maintain compliance with the
law and to reflect any changes to our data collection process. When we amend this Privacy Policy
we will update the "Effective Date" at the top of this Privacy Policy. We recommend that our users
periodically review our Privacy Policy to ensure that they are notified of any updates. If necessary,
we may notify users by email of changes to this Privacy Policy.</p>
</li>



<br><br><li class="text-justify"><b>Complaints</b>
	<p>If you have any complaints about how we process your personal data, please contact us through the
contact methods listed in the Contact Information section so that we can, where possible, resolve the
issue. If you feel we have not addressed your concern in a satisfactory manner you may contact a
supervisory authority. You also have the right to directly make a complaint to a supervisory
authority. You can lodge a complaint with a supervisory authority by contacting the Information
Commissioner's Office in the UK, Data Protection Commission in Ireland.</p>
</li>



<br><br><li class="text-justify"><b>Contact Information
</b>
	<p>If you have any questions, concerns or complaints, you can contact our privacy officer, Reagan
Tumushabe, at:</p>
<br>
<p>Reagan Tumushabe</p>
<p>Tumushabereagan@gmail.com</p>
<p>07540 061409</p>
<p>154 brierley, CR0 9DS</p>
</li>




	</ol>








					</div>
				</div>

				
			</div>
		</div>
	</div>



