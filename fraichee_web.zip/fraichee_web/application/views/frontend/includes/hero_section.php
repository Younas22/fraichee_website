<!-- ======= Hero Section ======= -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>

<style type="text/css">


  section.homelinen{
    position: relative;
    width: 100%;
    height:100vh;
    background: #3586ff;
    overflow: hidden;
  }
  section.homelinen .wave{
    position: absolute;
    bottom: 0;
    left:0;
    width:100%;
    height:100px;
    background:url(../assets/frontend/img/wave.png);
    background-size:1000px 100px;
  }
  section.homelinen .wave.wave1{
    animation: animate 30s linear infinite;
    z-index: 1000;
    opacity: 1;
    animation-delay: 0s;
    bottom:0;
  }
  section.homelinen .wave.wave2{
    animation: animate2 15s linear infinite;
    z-index: 999;
    opacity: 0.5;
    animation-delay: -5s;
    bottom:10px;
  }
  section.homelinen .wave.wave3{
    animation: animate 30s linear infinite;
    z-index: 998;
    opacity: 0.2;
    animation-delay: -2s;
    bottom:15px;
  }
  section.homelinen .wave.wave4{
    animation: animate2 5s linear infinite;
    z-index: 997;
    opacity: 0.7;
    animation-delay: -5s;
    bottom:20px;
  }
  @keyframes animate{
    0%
    {
      background-position-x:0;
    }
    100%
    {
      background-position-x:1000px;
    }
  }
  @keyframes animate2{
    0%
    {
      background-position-x:0;
    }
    100%
    {
      background-position-x:-1000px;
    }



</style>
  <?php if( $page_name == 'main' ){?>
  <section id="hero" class="d-flex align-items-center">
    <div class="container">
      <div class="row">
      <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
        <h1 data-aos="fade-up" class="aos-init aos-animate mt-5">Laundry made simple</h1>

        <!-- <h1 class="ml2">Sunny mornings</h1> -->

<!--    <ul style="font-size: 2rem;" class="typing-slider">
              
            <li>We <span class="0ml2">pick up your laundry</span></li>
            <li>We <span class="0ml3">clean it</span></li>
            <li>We <span class="0ml4">deliver it back</span></li>
            <li>We <span class="0ml5">make Laundry simple</span></li>
            
        </ul>  -->


<!-- <div class="typing-slider">
  <p>Text slider with</p>
  <p>typing animation effect</p>
  <p>in pure CSS.</p>
</div> -->
<!-- <span style="font-size:50px">We</span> -->
<!-- <div class="typing-slider">
  <p>We pick up your laundry</p>
  <p>We clean it</p>
  <p>We deliver it back</p>
  <p>We make Laundry simple</p>
</div> -->

<ul style="font-size: 3rem;">We <span style="font-size: 2rem;" class="ityped"></span></ul>



<script src="https://unpkg.com/ityped@0.0.10"></script>
<script>
 window.ityped.init(document.querySelector('.ityped'),{
                strings: [
                'pick up your laundry',
                'clean it',
                'deliver it back',
                'make Laundry simple'],
                loop: true
            })
</script>







          <div data-aos="fade-up" data-aos-delay="800">
            <a href="<?=base_url('customer')?>" class="btn-get-started scrollto">Order Now</a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left" data-aos-delay="200">
          <img src="<?php echo base_url() ?>assets/frontend/img/hero-img.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->
  <?php }
  else if( $page_name == 'homelinen_page' || $page_name == 'homepremium_page' || $page_name == 'commercial_page' ){ ?>
    <section class="homelinen">
      <div class="container">
        <div class="row pt-md-5">
          <div class="col-md-6 order-2 order-lg-1 flex-column justify-content-center text-white">
            <h1 data-aos="fade-up">Welcome To Fraichee's Commercial Services</h1>
            <h2 data-aos="fade-up" data-aos-delay="400">Linen & Laundary services for business. Flexible and customisable to the Suitability of your business's environment and demand.</h2>
            <!-- <div data-aos="fade-up" data-aos-delay="800">
              <a href="#about" class="btn-get-started scrollto bg-white p-2" style="border-radius:5px;">Get Started</a>
            </div> -->
          </div>
          <div class="col-md-6 order-1 order-lg-2 d-none d-xs-none d-sm-none d-md-block hero-img pt-5" data-aos="fade-left" data-aos-delay="200">
            <img src="<?php echo base_url() ?>assets/frontend/img/commercial/commercial_slider.gif" class="img-fluid" alt="" style="position: relative;top:-50px;">
          </div>
        </div>
        
      </div>


      <div class="wave wave1"></div>
      <div class="wave wave2"></div>
      <div class="wave wave3"></div>
      <div class="wave wave4"></div>
    </section>
  <?php } ?>
