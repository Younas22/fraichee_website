<style type="text/css">
  .panel-group{
    padding-top: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid lightgray;
    cursor: pointer;
  }


  #customersCats{
     margin-top:1.2rem;
     height: 80px;
  }

  .nav-link.active, .nav-link:focus,  .nav-link:hover {
      background-color: transparent;
      border-color: transparent;
      border-bottom: 3px solid #1aafff;
  }
  a.nav-link{
    color:#333;
  }
</style>
<main id="main">

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients clients">
      <div class="container">

        <div class="row">
          <?php $partners = json_decode(partnerIcons()->sval); 
          if(!empty($partners)){
          foreach($partners as $partner){
          ?>
          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/uploads/partner_icons/<?php echo $partner;?>" class="img-fluid" alt="" data-aos="zoom-in">
          </div>
          <?php } }?>
          <!-- <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-2.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="100">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-3.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="200">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-4.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="300">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-5.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="400">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="<?php echo base_url() ?>assets/frontend/img/clients/client-6.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="500">
          </div> -->

        </div>

      </div>
    </section><!-- End Clients Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>About Us</h2>
        </div>

        <div class="row content">
        <div class="col-lg-6" data-aos="fade-up" data-aos-delay="150" style="text-align: justify;">
          <div class="image" data-aos="fade-right" data-aos-delay="150">
            <img src="<?php echo base_url() ?>assets/frontend/img/frontend_1.png" alt="" class="img-fluid">
          </div>
        </div>

          <div class="col-lg-6 mt-5" data-aos="fade-up" data-aos-delay="150" style="text-align: justify;">
            <p>
              Hi! Yes it is pronounced “freche”, a growing company of Freshness. We Aspire to take over your household chores delivering nothing but top quality Linen and laundry services to our customers. 
            </p>
            <p>
              At Fraîchee we believe that laundry services are a necessity which should be affordable and reliable to all, which is why we aim at maintaining top quality services at optimised prices. Fraîchee is here to serve everyone that is within our reach with passion and drive.<strong>Your comfort is our priority.</strong>
            </p>
            <p>
              This is a great space to write a long text about your company and your services.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->


    <!-- ======= We at Fraichee Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>We at Fraichee</h2>
        </div>

        <div class="row content">
        <div class="col-lg-6" data-aos="fade-up" data-aos-delay="150" style="text-align: justify;">
          <div class="image" data-aos="fade-right" data-aos-delay="150">
            <img src="<?php echo base_url() ?>assets/uploads/wearefrichee.png" alt="" class="img-fluid">
          </div>
        </div>

    <div class="col-lg-6 mt-5" data-aos="fade-up" data-aos-delay="150" style="text-align: justify;">


        <ul style="font-size: 20px;">
            
            <li><i class="icofont-check-circled text-dark"></i>We don’t reinvent Laundry</li>
            
            <li><i class="icofont-check-circled text-dark"></i>We simply pick up your Laundry</li>
            
            <li><i class="icofont-check-circled text-dark"></i>We clean it  to your needs.</li>
            
            <li><i class="icofont-check-circled text-dark"></i>We deliver it back in 24 hours</li>
            
            <li><i class="icofont-check-circled text-dark"></i>We make Laundry  simple</li>
        </ul>


          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Counts Section ======= -->
<!--     <section id="counts" class="counts">
      <div class="container">

        <div class="row">
          <div class="image" data-aos="fade-right" data-aos-delay="150">
            <img src="<?php echo base_url() ?>assets/frontend/img/frontend_1.png" alt="" class="img-fluid">
          </div>
        </div>

      </div>
    </section> -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Services</h2>
          <!-- <p>Magnam dolores commodi suscipit eius consequatur ex aliquid fug</p> -->
        </div>

        <div class="row">

          <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="card mb-4 box-shadow">
              <img class="card-img-top" src="<?=base_url('assets/frontend/img/01.jpeg')?>" alt="Card image cap">
              <div class="card-body icon-box">
                <h1 class="card-title pricing-card-title" style="font-size:25px;">Laundry and Dry cleaning services </h1>
                <ul class="list-group mt-3 mb-4">
                  <li> These services can be accessed through our website.</li>
                  <li>Simply log on and choose the services your require.</li>
                  <li>We offer same day pick up.</li>
                  <li>You laundry items will be cleaned accordingly and delivered to you within 24 hours.</li>
                </ul>
              </div>
            </div>
          </div>



            <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="card mb-4 box-shadow">
              <img class="card-img-top" src="<?=base_url('assets/frontend/img/02.jpeg')?>" alt="Card image cap">
              <div class="card-body icon-box">
                <h1 class="card-title pricing-card-title" style="font-size:25px;">Linen on Subscription</h1>
                <ul class="list-group mt-3 mb-4">
                  <li>Pick the type of Linen you require from a variety listed on our website.</li>
                  <li>Choose when you would like us to deliver and how often  in a week.</li>
                  <li>Review and confirm your order, you will receive an email after confirmation.</li>
                  <li>On a chosen day, our drive will deliver your chosen fresh Linen and pick up the used one.</li>
                  </ul>
              </div>
            </div>
          </div>



            <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="card mb-4 box-shadow">
              <img class="card-img-top" src="<?=base_url('assets/frontend/img/03.jpeg')?>" alt="Card image cap">
              <div class="card-body icon-box">
                <h1 class="card-title pricing-card-title" style="font-size:25px;">Linen hire</h1>
                <ul class="list-group mt-3 mb-4">
                  <li>We offer variety of different types of Linen on hire basis .</li>
                  <li>These services are suitable for Airbnb, hotel, restaurants, parties and many more.</li>
                  <li>Linen hire services are avilable on demand with no Minimum order.</li>
                  <li>To get a quote on our linen hire services, Use the contact us page to send us your requirement.</li>
                </ul>
              </div>
            </div>
          </div>

          <!-- <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
              <div class="icon"><i class="bx bx-world"></i></div>
              <h4 class="title"><a href="">Nemo Enim</a></h4>
              <p class="description">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis</p>
            </div>
          </div> -->

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Price Details</h2>
        </div>
        
        <div class="row mb-4">
          <div class="col-md-2" id="priceListImg">
            <img src="https://uploads-ssl.webflow.com/5dcadcbd9a526c0e1a357680/5defd54f0244b41412f47bbc_Vest.svg" class="img img-responsive">
          </div>

          <div class="col-md-10" id="priceList">
            <?php foreach( $products as $prod ): ?>
              <a href="javascript:void(0)" data-prod_id = "<?php echo $prod['prod_id']; ?>" class="badge badge-pill py-3 px-4 mb-3 mr-3 cbadge"><?php echo $prod['name']; ?></a>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="row pricingArea"></div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- =====Portfolio section ====  -->
    <!-- <section id="portfolio" class="portfolio">
      <div class="container">
        <div class="section-title" data-aos="fade-up">
          <h2>Portfolio</h2>
        </div>

        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100" style="border-bottom:none;">

          <div class="col-sm-12">
            <ul class="nav justify-content-center" role="tablist" id="customersCats" >
              <li class="nav-item">
                <a class="nav-link active show" href="#allSection" id="all" data-toggle="tab" role="tab" aria-controls="featuredSection" aria-selected="true">All</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#commercialSection" id="commercial" data-toggle="tab" role="tab" aria-controls="educationSection" aria-selected="false">Commercial</a>
              </li>
            </ul>
          </div>


          <div class="col-sm-12">
            <div class="tab-content" id="catsContent">

              <div class="tab-pane fade show active" id="allSection" role="tabpanel" aria-labelledby="all">
                <div class="row">
                  <div class="col-sm-6 col-md-4">
                    <a href="javascript:void(0);">
                      <img src="<?php echo base_url(); ?>assets/uploads/portfolio/port1.jpeg" alt="Portfolio Item" class="img-fluid"/ style="height: 250px;width:100%;padding-bottom: 5px;">
                    </a>
                  </div>
                  <div class="col-sm-6 col-md-4">
                    <a href="javascript:void(0);">
                      <img src="<?php echo base_url(); ?>assets/uploads/portfolio/port2.jpeg" alt="Portfolio Item" class="img-fluid" / style="height: 250px;width:100%;padding-bottom: 5px;">
                    </a>
                  </div>
                  <div class="col-sm-6 col-md-4">
                    <a href="javascript:void(0);">
                      <img src="<?php echo base_url(); ?>assets/uploads/portfolio/port3.jpeg" alt="Portfolio Item" class="img-fluid"/ style="height: 250px;width:100%;padding-bottom: 5px;">
                    </a>
                  </div>
                </div>
              </div>

              <div class="tab-pane fade show active" id="commercialSection" role="tabpanel" aria-labelledby="commercial">
                <div class="row">
                  <div class="col-sm-6 col-md-4">
                    <a href="javascript:void(0);">
                      <img src="<?php echo base_url(); ?>assets/uploads/portfolio/port1.jpeg" alt="Portfolio Item" class="img-fluid"/ style="height: 250px;width:100%;padding-bottom: 5px;">
                    </a>
                  </div>
                  <div class="col-sm-6 col-md-4">
                    <a href="javascript:void(0);">
                      <img src="<?php echo base_url(); ?>assets/uploads/portfolio/port2.jpeg" alt="Portfolio Item" class="img-fluid" / style="height: 250px;width:100%;padding-bottom: 5px;">
                    </a>
                  </div>
                  <div class="col-sm-6 col-md-4">
                    <a href="javascript:void(0);">
                      <img src="<?php echo base_url(); ?>assets/uploads/portfolio/port3.jpeg" alt="Portfolio Item" class="img-fluid"/ style="height: 250px;width:100%;padding-bottom: 5px;">
                    </a>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div> 
      </div>
    </section> -->
    <!-- ends here -->

    <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Frequently Asked Questions</h2>
        </div>

        <!-- my faq -->
        <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100" style="border-bottom:none;">
          <div class="col-md-12 px-0">
            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question0">
                    <i class="ri-question-line"></i>
                    <h5>What services are offered by Fraichee?</h5>
                  </div>
                  <div id="question0" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            <ul class="list-group">
                              <li class="list-group-item">We offer Laundry services, Linen subscription services and Linen hire services. All our services can be simply accessed through our website or by contacting us. 
 </li>
                            </ul>
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->

            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question1">
                    <i class="ri-question-line"></i>
                    <h5>What areas do you operate in?</h5>
                  </div>
                  <div id="question1" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            London, we currently operate in London only but we will be expanding quickly, if we are not in your area yet, simple leave your email address and we will let you know once we have arrived. 
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->

            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question2">
                    <i class="ri-question-line"></i>
                    <h5>What types of clothes do you clean?</h5>
                  </div>
                  <div id="question2" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            We clean all types of clothes.  Our staff are trained in dealing with any type of clothes/ materials, any cloth that is handed over to us, we guarantee it is in safe hands.
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->

            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question3">
                    <i class="ri-question-line"></i>
                    <h5>What is the Delivery time?</h5>
                  </div>
                  <div id="question3" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            We aim to make all our deliveries within 24 hours. Counting from when the driver picks up your laundry.
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->

            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question4">
                    <i class="ri-question-line"></i>
                    <h5>How do we ensure our customer’s clothes are not damaged?</h5>
                  </div>
                  <div id="question4" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            Our staff are trained to handle any cloth material with complete care from pick up to drop off but if any damages do occur, they will be covered by our insurance. Report an errors or damages as soon as you realise them. Follow terms and condition of guidance.  
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->

            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question5">
                    <i class="ri-question-line"></i>
                    <h5>How does our linen subscription service work?</h5>
                  </div>
                  <div id="question5" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            <ul class="list-group">
                              <li class="list-group-item">Choose what Linen you require from a variety listed on our website</li>
                              <li class="list-group-item">Choose how often you want it delivered</li>
                              <li class="list-group-item">Choose when to deliver your first order </li>
                              <li class="list-group-item">Driver will drop off fresh Linen and pick up the used ones following the chosen delievery frequency  </li>
                            </ul>
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->

            <!-- panel group start -->
            <div class="panel-group" id="faqAccordion">
              <div class="panel panel-info">
                  <div class="panel-heading" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question5">
                    <i class="ri-question-line"></i>
                    <h5>Can I use my own linen for the linen subscription?</h5>
                  </div>
                  <div id="question5" class="panel-collapse collapse" style="height: 0px;">
                      <div class="panel-body">
                          <h5><span class="label label-primary">Answer</span></h5>

                          <p>
                            No. Linen subscription services are provided on hire basis however you can use our Laundry services for your linen.
                          </p>
                      </div>
                  </div>
              </div>
            </div>
            <!-- panel group ends here -->
          </div>
          
        </div>
        <!-- my faq ends here -->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>What services are provided by Fraichee?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              <ul class="list-group">
                <li>We offer Laundry services, Linen subscription services and Linen hire services. All our services can be simply accessed through our website or by contacting us. 
 </li>
              </ul>
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>What areas do you operate in?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              London, we currently operate in London only but we will be expanding quick, if we are not in your area yet, simple leave your email address and we will let you know once we have arrived 
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>What types of clothes do you clean?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              Any: Our staff have experience in the Laundry industry and have seen it all, any type or material of clothes that is handed to us, we guarantee its in safe hands 
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>What is the Delivery time?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              We aim to make all our deliveries within 24 hours. Counting from when the driver picks up your laundry.
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="500">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>How do we ensure our customer’s clothes are not damaged?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              Our staff are trained to handle any cloth material with complete care from pick up to drop but if any damages do occur, they will be covered by our insurance. Report an error as soon as you realise your cloth is damaged. Follow terms and condition of guidance  
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="500">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>How does our Home linen subscription service work?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              <ul class="list-group">
                <li>Choose what Linen you require from a variety listed on our website</li>
                <li>Choose how often </li>
                <li>Choose when to deliver </li>
                <li>Driver will drop off fresh Linen and pick up the used one</li>
              </ul>
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

        <!-- <div class="row faq-item d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="500">
          <div class="col-lg-5">
            <i class="ri-question-line"></i>
            <h4>Can I use my own linen for the Home linen subscription?</h4>
          </div>
          <div class="col-lg-7">
            <p>
              No. Home Linen subscription services are provided on hire basis however you can use our Laundry services for your linen.
            </p>
          </div>
        </div> --><!-- End F.A.Q Item-->

      </div>
    </section><!-- End F.A.Q Section -->
<style>
  
@import url('https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800');

h1{
  text-align: center;
  font-size: 36px;
}
h3{
  text-align: center;
  font-size: 30px;
  padding: 20px;
  font-weight: 400;
  letter-spacing: 1px;

}
.subscribe{
    
    padding: 12px 20px;
    margin: 9px 0;
    box-sizing: border-box;
    border-radius: 10px;
    outline: none;
    width: 40%;
    height:20%;
    boredr:1px solid #7c7b7b;
}
input[type=text]:hover {
  border:1px solid #000;
  transition: 6s;
}
::placeholder { 
    color: #000;
    opacity: 1;
    font-weight: 400;
    font-size: 20px;
    /*text-align: center;*/


}
button{
  height: 50px;
  padding: 0;
  margin: 0;
  
}
.btn{
  border-radius: 30px;
  width: 14%;
  margin-left: 5px;
  font-size: 20px;

}
footer{
  background: #000;
  text-align: center;
  padding: 10px;

}
footer p{
  color: #fff;
  padding: 10px;
  margin: 0;
  font-weight: 700;
  font-size: 20px;
}
@media(max-width: 992px){
  .btn{
    width: 20%
  }
  input[type=text]{
    width: 50%;
  }
}
@media(max-width: 768px){
  .btn{
    width: 40%
  }
  input[type=text]{
    width: 90%;
  }
}
@media(max-width: 440px){
  .btn{
    width: 50%;
    font-size: 18px;
  }
  input[type=text]{
    width: 100%;
  }
  h3{
    font-size: 22px;
  }
}
@media(max-width: 373px){
  h3{
    font-size: 20px;
    font-weight: 600;
  }
  h1{
    font-size: 28px;
    font-weight: 400;
  }


}
</style>
    <section class="bg-light text-center p-5 mt-4">
    <div class="container p-3">
        <div class="section-title" data-aos="fade-up">
          <h2>Keep updated</h2>
        </div>
         <!-- action="base_url('subscribe_mail')" method="Post" -->
      <form>
        <input type="text" class="subscribe" id="subscribe_mail" name="subscribe_mail" placeholder="Enter Your Email Address">
        <button type="button" class="btn btn-primary" id="newsletter" style="background:#73c3e4 !important;">Subscribe</button>
      </form>
    </div>

    <div id="mail_msg">
      
    </div>
  </section>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Contact Us</h2>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="contact-about">
              <h4>Fraichee</h4>
              <p>At Fraîchee we believe that laundry services are a necessity which should be affordable and reliable to all, which is why we aim at maintaining top quality services at optimised prices. Fraîchee is here to serve everyone that is within our reach with passion and drive.Your comfort is our priority.</p>
              <div class="social-links">
                <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
                <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
                <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
                <a href="#" class="linkedin"><i class="icofont-linkedin"></i></a>
                <a href="#" class="stripe"><i class="icofont-stripe"></i></a>
              </div>
            </div>
          </div>
          <style>
            li{
              margin-bottom: 10px;
            }
             a{
              color: #888;
            }
          </style>
          <div class="col-lg-2 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="contact-about">
              <h4>Services</h4>
              <ul class="list-unstyled">
                <li>
                  <a href="#services">Laundry</a>
                </li>
                <li>
                  <a href="#services">Dry Cleaning</a>
                </li>
                <li>
                  <a href="<?=base_url('linen-subscription')?>">Linen Subscription</a>
                </li>
                <li>
                  <a href="<?=base_url('page/commercial')?>">Linen Hire</a>
                  </li>
                    <li>
                  <a href="<?=base_url('privacy-policy')?>">Privacy Policy</a>
                  </li>
                    <li>
                  <a href="<?=base_url('terms-and-condition')?>">Terms And Condition</a>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="info">
              <div>
                <i class="ri-map-pin-line"></i>
                <p>Fraichee LTD Kemp House, 160 City Road London EC1V 2NX</p>
              </div>

              <div>
                <i class="ri-mail-send-line"></i>
                <p>customerservice@fraichee.com</p>
              </div>

              <div>
                <i class="ri-phone-line"></i>
                <p>+44 74 04141235</p>
              </div>

            </div>
          </div>

          <div class="col-lg-4 col-md-12" >
            <form action="<?=base_url('forms_contact')?>" method="post">
              <div class="form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" required="" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject"/>
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message" required></textarea>
                <div class="validate"></div>
              </div>
              <!-- <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div> -->
              <div class="text-center"><button type="submit" style="
background: #3498db;
color: #fff;
border-radius: 50px;
/*margin: 0 0 0 30px;*/
padding: 10px 25px;
    ">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->