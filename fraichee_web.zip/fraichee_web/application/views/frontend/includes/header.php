<!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo mr-auto">
        <!-- <h1 class="text-light"><a href="<?php echo base_url(); ?>"><span>Fraichee</span></a></h1> -->
        <a href="<?php echo base_url(); ?>">
          <img src="<?php echo base_url(); ?>assets/uploads/<?php echo $logo;?>" alt="Image not found." class="img img-thumbnail">
        </a>
      </div>

    
      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active">
              <a href="#services">Laundry Services</a>
          </li>
          <li class="active">
              <a href="<?= base_url('linen-subscription'); ?>">Linen Subscription</a>
          </li>
          <li class="active">
              <a href="<?php echo site_url('page/commercial'); ?>">Commercial linen</a>
            </li>
          <li class="active">
              <a href="#about">About Us</a>
          </li>

          <li class="active">
              <a href="#contact">Contact Us</a>
          </li>

<!--           <li class="active">
              <a href="#portfolio">Portfolio</a>
          </li> -->
          
          <li class="active">
              <a href="#faq">FAQ</a>
          </li>


          <?php foreach($categories as $cat ){ 
            $controller_link = str_replace(' ','',$cat['cat_name']);
            ?>
            <li class="active">
              <a href="<?php echo site_url('page/'.$controller_link); ?>"><?php echo ucwords($cat['cat_name']); ?></a>
            </li>
          <?php } ?>

          <li class="get-started"><a href="<?php echo site_url('customer'); ?>">Order Now</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header