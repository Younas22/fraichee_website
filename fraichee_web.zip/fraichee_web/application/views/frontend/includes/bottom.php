
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('.cbadge').on('click', function(){
			prod_id = jQuery(this).data('prod_id');
			jQuery('.cbadge').removeClass('cbadge_selected');	
			if(jQuery(this).data('clicked', true)){
				console.log('clcicked');
				jQuery(this).addClass('cbadge_selected');
			}
			jQuery.ajax({
				method: 'post',
				url:'<?php echo base_url();?>home_controller/getChildProductDetails',
				data:{prod_id:prod_id},
				success:function(data){
					prod_obj = JSON.parse(data);
					console.log(prod_obj);
					console.log(prod_obj['data']);
					jQuery('#priceListImg').html(prod_obj['image']);
					jQuery('.pricingArea').html(prod_obj['pricelist']);
				}
			});
		});
	});



	// Wrap every letter in a span
var textWrapper = document.querySelector('.ml2');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml2 .letter',
    scale: [4,1],
    opacity: [0,1],
    translateZ: 0,
    easing: "easeOutExpo",
    duration: 950,
    delay: (el, i) => 70*i
  }).add({
    targets: '.ml2',
    opacity: 0,
    duration: 1000,
    easing: "easeOutExpo",
    delay: 2000
  });


	// Wrap every letter in a span
var textWrapper = document.querySelector('.ml3');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml3 .letter',
    scale: [4,1],
    opacity: [0,1],
    translateZ: 0,
    easing: "easeOutExpo",
    duration: 950,
    delay: (el, i) => 70*i
  }).add({
    targets: '.ml3',
    opacity: 0,
    duration: 2000,
    easing: "easeOutExpo",
    delay: 3000
  });


	// Wrap every letter in a span
var textWrapper = document.querySelector('.ml4');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml4 .letter',
    scale: [4,1],
    opacity: [0,1],
    translateZ: 0,
    easing: "easeOutExpo",
    duration: 950,
    delay: (el, i) => 70*i
  }).add({
    targets: '.ml4',
    opacity: 0,
    duration: 3000,
    easing: "easeOutExpo",
    delay: 4000
  });



	// Wrap every letter in a span
var textWrapper = document.querySelector('.ml5');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml5 .letter',
    scale: [4,1],
    opacity: [0,1],
    translateZ: 0,
    easing: "easeOutExpo",
    duration: 950,
    delay: (el, i) => 70*i
  }).add({
    targets: '.ml5',
    opacity: 0,
    duration: 4000,
    easing: "easeOutExpo",
    delay: 5000
  });






</script>