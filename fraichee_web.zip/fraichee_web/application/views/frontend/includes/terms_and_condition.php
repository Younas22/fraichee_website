<style>
.bg-no-overlay {
background: url("<?=base_url('assets/frontend/img/terms.jpg')?>");
background-repeat: no-repeat;
background-size: cover;
background-position: center center;
color: #fff;
height: 300px;
padding-top: 50px;
}
.ol { counter-reset: item }
.li{ display: block }
.li:before { content: counters(item, ".") " "; counter-increment: item }
</style>
<div class=" bg-no-overlay">
<div class="text-center" style="margin-top:100px;">
<h1 class="mt-5">Terms & Conditions</h1>
</div>
</div>
<div id="how-it-works" style="margin-top:100px;">
<div class="content-wrap">
<div class="container">
<h2 class="section-heading center no-after mb-5">
Terms & Conditions
</h2>
<div class="row">
<div class="col-sm-12 col-md-12">
	<ol class="ol">
		<li class="li text-justify"><b>The contracted terms and conditions</b>
			<ol class="ol">
				<li class="li text-justify">These terms and conditions apply to any orders received through our website, phone call,
					email or any other media. You will be unable to place an order unless you have agreed with our
				terms and conditions.</li>
				<li class="li text-justify">Please ensure that you read and understand the terms and conditions before you place an
					order with us. These terms and conditions may change from time to time and the current
				available version of the terms and conditions will apply at the time Your order was placed.</li>
			</ol>
		</li><br><br>
		<li class="li text-justify"><b>Placing an Order</b>
			<ol class="ol">
				<li class="li text-justify">We can accept orders through our website, phone call and email, please ensure that you
					submit the correct details of your order as we are not liable to you for any errors or omissions
					you make. If you think you made a mistake with your order, please contact us as soon as
				possible. All changes we make to your order will be confirmed by email. </li>
				<li class="li text-justify">To confirm your order has been placed, we will send a confirmation email to your provided
					email address which will include your order number, a summary of what you have ordered along
				with your delivery information.</li>
				<li class="li text-justify">Your order will be assigned an order number which will be sent to you in the order
				confirmation email, quote this order number in all correspondence with us. </li>
				<li class="li text-justify">if we are unable to fulfill your order for any reason, we will update you by email or text
				message</li>
				<li class="li text-justify">Our collections and returns windows run between 7pm to 11pm every day, you will lose the
					right to reschedule or cancel your order at 5 pm of the collection date.
				</li>
			</ol>
		</li><br><br>
		<li class="li text-justify"><b>To make changes to your order</b>
			<ol class="ol">
				<li class="li text-justify"> If you wish to make changes to your order, you may do so before the collection time. You
				may do so by contacting our customer service at customerservice@fraichee.com.</li>
				<li class="li text-justify">You may reschedule your collection or return window as long as your original agreed pickup window is within the next two hours within the time of contacting our customer service.
					Fraichee reserves the right to apply additional fees of rescheduling and the rescheduling is
				subject to availability. </li>
			</ol>
		</li>
		<br><br>
		<li class="li text-justify"><b>Cancelling your order </b>
			<ol class="ol">
				<li class="li text-justify"> You can cancel your order at any time before the collection day by contacting our customer
				service. </li>
				<li class="li text-justify">You may cancel your order after collection if we are affected by an event outside our control
				by contacting our customer service. </li>
				<li class="li text-justify">You will lose your rights to order cancellation under consumer contracts regulation and any
				similar regulations after your order has been collected from you. </li>
			</ol>
		</li>
		<br><br>
		<li class="li text-justify"><b>Our Rights to cancel order </b>
			<ol class="ol">
				<li class="li text-justify">We may cancel your order due to different reasons and circumstances such as events
					outside our control if the items for collection have not been made available, if the item collected
					does not correspond with the order or the item is damaged; the item has no information about
					the cleaning instructions etc.
				</li>
				<li class="li text-justify">If we do cancel your order, you will be contacted by phone or email </li>
				<li class="li text-justify">If we cancel your order and have already started to work on it, you will not be charged for
					the service and you will not be required to make any payments to us if we have already picked
				up the item, we will arrange a delivery at a reasonable time.</li>
			</ol>
		</li>




		<br><br>
		<li class="li text-justify"><b>Collection and redeliver  </b>
			<ol class="ol">
				<li class="li text-justify">We aim to deliver at your chosen timeslot. We will contact you to make arrangements for a
					re-delivery at your convenient availability should you miss your original delivery slot. A £25 fee
					will be charged for each attempt we make at delivering your order if you miss your first delivery
					slot.
				</li>
				<li class="li text-justify">Should a customer fail to accept or arrange a redelivery of an item for over 90 days after
				their original delivery date, the item will be disposed of.</li>
				<li class="li text-justify">We aim to collect and deliver your items at the specified time slot but we cannot guarantee
					delivery or pick up at the chosen timeslot where delays are inevitable, we will communicate to
					you by phone or email. We are not liable for all consequential losses which a customer may
				incur as a result of delay in deliveries </li>
				<li class="li text-justify">Customers will have to acknowledge pick and delivery through the provided resources </li>
				<li class="li text-justify">Customers may request (in writing to us) for us to pick up or deliver their order in an agreed
					location or third party without providing an acknowledgement of pick up or drop off from the
					customer. In this case, the customers bear the risk or consequential loss which may occur,
				Fraichee LTD shall not be liable for any loss or damage of items that may occur. </li>
			</ol>
		</li>



		<br><br>
		<li class="li text-justify"><b>Standards of our service</b>
			<ol class="ol">
				<li class="li text-justify">Our services are provided with reasonable care and skill in accordance with good industry
standards. 
				</li>
				<li class="li text-justify">If you fail to provide accurate information in your order, we are not responsible for any
delays or nonperformance of our service that may occur. This information includes your
address. </li>
				<li class="li text-justify">We are not liable for any passed on to us which have an increased risk of damaged,
including items with no labels indication cleaning instructions, items with special requirements
for cleaning, items that bear an extraneous hazardous material such as pins, jewellery, coins etc
At our discretion and your consent we may agree to provide the service at your risk in respect of
the identified items. 
</li>
				<li class="li text-justify">For all the items passed on to us, please ensure that they are checked thoroughly for any
hazardous items such as coins, pens, keys etc. Fraichee will not be held responsible for any
damaged or lost items as a result of the cleaning process. </li>
				<li class="li text-justify">We separate all the clothes into lights and darks before wash, although utmost care is taken
in doing so we take no responsibility if there is any bleeding or colour transfer during the
cleaning process </li>
			</ol>
		</li>

				
		<br><br>
		<li class="li text-justify"><b>Problem with service</b>
			<ol class="ol">
				<li class="li text-justify"> If a customer has a problem with our services, they are free to raise a complaint by
contacting us at <a href="customerservice@fraichee.com">customerservice@fraichee.com</a>.</li>
				<li class="li text-justify">Complaints on a service or an order should be notified to us immediately through
appropriate channels</li>

			</ol>
		</li>

				
		<br><br>
		<li class="li text-justify"><b>Price and payment terms</b>
			<ol class="ol">
				<li class="li text-justify">The cost of our service is set out in our price details section on our website (fraichee.com),
this will be the price that is in force at the time of you placing your order however these prices
may change from time to time. </li>
				<li class="li text-justify">All our prices include taxes but our prices may change to accommodate the changes in the
rate of tax</li>

			</ol>
		</li>

				
		<br><br>
		<li class="li text-justify"><b>Our Liability to you </b>
			<ol class="ol">
				<li class="li text-justify">In the event that an item is lost or damaged, fraichee LTD will compensate the customer
following the standard industry guidelines. Our total liability to you in respect of each item is
limited to the 12 times the price of the original service charge, but not more than £50.00 per
item. A proof of purchase must be provided, showing the value of the item and the purchase
date. </li>
				<li class="li text-justify">We will compensate customers for loss or damage that is due to our Negligence however
we will not compensate more than £50 per item. 
</li>
				<li class="li text-justify">Fraichee will not be liable for any loss of profit if you are a reseller using our service,
business disruption or loss of opportunity for the commercial customers. </li>
				<li class="li text-justify">Fraichee is not liable for any loss, damage, colour loss, shrinkage or other damage that is
due to 1.) customer failing to notify us of special cleaning requirements. 2). Item lacking the
label of cleaning instructions. 3).items has an existing damage at the time of collection </li>

			</ol>
		</li>

				
		<br><br>
		<li class="li text-justify"><b>Events outside our control</b>
			<ol class="ol">
				<li class="li text-justify">We are not responsible or liable for any delay or failure in performance of any of our
obligations that are due to an event beyond/ or outside our control. </li>
				<li class="li text-justify">Events outside of our control means any act or event beyond our control including but not
limited to strikes, lock-outs, civil commotion, riot, invasion, terrorist attack, war (weather
declared or not), fire, explosion, storm, floods, earthquake, epidemic or natural disaster,
subsidence, failure of public or private telecommunication networks or impossibility of the use of
railways shipping, aircraft, motor transport or other means of public or private transport.</li>
				<li class="li text-justify"> If the event outside our control affects our obligated services in any way, (1.) You will be
notified as soon as possible. (2.) our obligated services will be extended for the duration of the
event outside our control. If the event outside our control affects our delivery of products to you,
a new redelivery will be arranged after the event is over.
If the order is cancelled, we will return your item(s) at no cost to you</li>

			</ol>
		</li>

				
		<br><br>
		<li class="li text-justify"><b>How to contact us</b>
			<ol class="ol">
				<li class="li text-justify"> Fraichee LTD is registered in England and wales. Registration number is 12965743 at
office Fraichee LTD Kemp House, 160 City Road London. EC1V 2NX. 
</li>
				<li class="li text-justify">You can contact us if you have any questions or any complaints by directly emailing us at
<a href="customerservice@fraichee.com">customerservice@fraichee.com</a> or by writing to us at the address provided above. </li>

			</ol>
		</li>










	</ol>
</div>
</div>


</div>
</div>

</div>