<?php  
$this->load->view('admin/includes/head');
if( $page_name == 'login' ){
	$this->load->view('admin/'.$page_name);	
}
else{
  $this->load->view('admin/includes/header');
  $this->load->view('admin/includes/aside');
  $this->load->view('admin/pages/'.$page_name);
  $this->load->view('admin/includes/footer');
  $this->load->view('admin/includes/bottom');
}
$this->load->view('admin/includes/bottom_script');
?>