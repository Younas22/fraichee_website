<script>
    jQuery(document).ready( function () {
        console.log('hello this is admin of raichee');
        jQuery('#table_id').DataTable();
        jQuery('.orderTable').DataTable();
    } );

    /* FRAICHEE SUBSCRIBER PANEL JS */
    jQuery(document).ready(function(){
        
        jQuery('.sub_plan').on('click', function(){
            sub_plan = jQuery(this).val();
            console.log('subscription plan => '+sub_plan);
        });

        jQuery('select').selectpicker();
        jQuery('select[name="parent_product"]').on('change', function(){
            parent_id = jQuery(this).val();
            baseurl   = jQuery(this).data('baseurl');
            // console.log("<?php echo base_url() ?>admin_controller/ajax_child_products");
            jQuery.ajax({
                method: "POST",
                url:"<?php echo base_url() ?>subscriber_controller/ajax_child_products",
                data: {parent_id: parent_id},
                success: function(res){
                    options = jQuery.parseJSON(res);
                    // console.log(options);
                    jQuery('select[name="child_product[]"]').attr('multiple','multiple');
                    jQuery('select[name="child_product[]"]').html(options);
                    jQuery('select').selectpicker('refresh');
                }
            }); 

        });
    });
    /* FRAICHEE SUBSCRIBER PANEL JS ENDS HERE */
</script>

  </body>
</html>
