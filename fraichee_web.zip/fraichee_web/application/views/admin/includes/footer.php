<footer class="main-footer">
  <strong>Developed By: <a href="https://fiverr.com/deftmasters">Bakhtawar Shah</a>.</strong> 
</footer>


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div><!-- ./wrapper -->

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>




<script>
$(document).ready(function(){

  // Set option selected onchange
  $('#order_status').change(function(){
    var order_status = $(this).val();

    var values_arr = order_status.split(',');
    let order_id = values_arr[0];
    let status_val = values_arr[1];
    let email_val = values_arr[2];
    let url = "<?=base_url('admin/order_status')?>";


    $.ajax({  
     url: url,  
     method:"POST",  
     data:{order_id:order_id,status_val:status_val,email_val:email_val},  
     success:function(data)  
     {  
      alert('order status updated');
      location.reload();

     },
        error: function(){
          alert("somthing wrong!");
          location.reload();

        }
    });

  });
});
</script>