<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="panel panel-default">
      <div class="panel-heading">
        Orders
        <!-- <button class="btn btn-info pull-right" style="margin-top: -7px;" data-toggle="modal" data-target="#addCategory">Add Category</button> -->
      </div>
      <div class="panel-body">
        
        <table class="display orderTable">
          <thead>
              <tr style="text-align: right;">
                  <th>Serial No.</th>
                  <th>Delivery Date</th>
                  <th>Contact</th>
                  <th>Client Name</th>
                  <th>Address</th>
                  <th>Cart Details</th>
                  <th>Quantity</th>
                  <th>Total Amount</th>
                  <th>Pick up Date</th>
                  <th>Status</th>
                  <!-- <th>Modify</th> -->
              </tr>
          </thead>
          <tbody>
          	<?php 

            // dd($order_details);
            // exit();


            $count = 1;
          		foreach($order_details as $key): 
                // dd($order);
                $delivery_days  = $key->delivery_days;
                $cartdetails    = $key->cart_details;
                $total_amount   = $key->total_amount;
                $type           = $key->type;
                $date           = $key->date;
          			$status         = $key->status;
                $name         = $key->name;
                $address         = $key->address;
                $contact         = $key->contact;



                $cartdata = json_decode($key->cart_details);
                $new_cart = [];
                foreach($cartdata as $cdk => $cdval ){
                    $new_cart[$cdk] = [
                        'prod_id' => $cdval->prod_id,
                        'cp_id'   => $cdval->cp_id,
                        'cart_qty'=> $cdval->cart_qty,
                        'price'   => $cdval->price,
                        'delivery_days' => $cdval->delivery_days
                    ];} ?>
<tr>
  <td><?= $count; ?></td>
  <td><?= $delivery_days; ?></td>
  <td><?= $contact?></td>
  <td><?= $name?></td>
  <td><?= $address?></td>
  <?php
  foreach($new_cart as $nkey => $nval):
  $prod_id  = $nval['prod_id'];
  $cp_id    = $nval['cp_id'];
  $cart_qty = $nval['cart_qty'];
  $per_price= $nval['price'];
  $ddays    = $nval['delivery_days'];
  $prod_img = getprodimage($prod_id,$cp_id);
  echo '<td style="text-align:center;"><b>'.$prod_img->name.'</b><hr><img src="'.base_url().'assets/uploads/products/'.$prod_img->image.'" alt="Image not found." style="height:50px; width:100px;"/></td>';

   echo '<td style="text-align:center;"><b>'.$cart_qty.'</b></td>';
  endforeach;
  ?>
  
  <td><?= $total_amount; ?></td>
  <td><?= $date; ?></td>
  <td><select class="c-select" id="order_status">
    <option value="<?=$key->order_id.','.$status?>"><?=$status?></option>
    <?php
     $status; 
     $options_arr = ['pending','approved','cancelled'];
     foreach ($options_arr as $status_opt => $val):
      if ($val != $status) { ?>
      <option value="<?=$key->order_id.','.$val.','.$key->email?>"><?=$val?></option>
    <?php } endforeach; ?>
    </select>
  </td>
<!--   <td style="display: none !importent;">
    <a href="<?=base_url('categories/edit/').$key->order_id ?>"><i class='fa fa-pencil-square-o' style='font-size:20px;'></i></a>
    <a href="<?=base_url('categories/drop/').$key->order_id ?>"><i class="fa fa-trash-o" style="font-size:20px; color:red;"></i></a>
  </td> -->
</tr>
          	<?php $count++; endforeach; ?>
              
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper