<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    <!-- Add category Modal -->
    <!-- <div class="modal fade" id="addCategory" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Category Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php echo form_open('categories/add_category', ['style' => '' ]); ?>
            <div class="form-group-row">
              <?php echo form_label('Category Name', 'category_name' , [ 'class' => 'col-form-label' ]); ?>
                <?php
                $prod_input = [
                  'type'     => 'text', 
                  'name'     => 'category_name',
                  'id'       => 'category_name',
                  'placeholder' => 'Enter Category Name Here..',
                  'value'    => '',
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
            </div>
            
          </div>

          <div class="modal-footer">
            <?php 
              $add_child_product_submit    = [
                'name'        => 'add_category',
                'content'     => 'Add Category',
                'class'       => 'btn btn-success',
                'type'        => 'submit',
              ];
              $child_product_close_button = [
                'name'        => 'close',
                'content'     => 'Close',
                'class'       => 'btn btn-danger',
                'type'        => 'button',
                'data-dismiss'=> 'modal',
              ];
              echo form_button($add_child_product_submit);
              echo form_button($child_product_close_button);
              echo form_close();
            ?>
          </div>
        </div>
      </div>
    </div> -->
    <!-- product list start     -->
    <div class="panel panel-default">
      <div class="panel-heading">
        Orders
        <!-- <button class="btn btn-info pull-right" style="margin-top: -7px;" data-toggle="modal" data-target="#addCategory">Add Category</button> -->
      </div>
      <div class="panel-body">
        
        <table class="display orderTable">
          <thead>
              <tr>
                  <th>Serial No.</th>
                  <th>Delivery Dates</th>
                  <th>Collection </th>
                  <th>Products subscribed </th>
                  <th>Total Amount</th>
                  <th>Status</th>
              </tr>
          </thead>
          <tbody>
          	<?php  $count = 1; foreach($subscription as $key):  ?>
          		<tr>
                  <td><?php echo $count; ?></td>
            <td><?php echo $key->delivery_days; ?></td>
                  <td><?php echo $key->date; ?></td>
                  <td><?php echo subscribed_product(json_decode(json_decode($key->cart_details)[0]->prod_id))->name;  ?></td>
                  <td><?php echo $key->total_amount; ?></td>
                  <td><?php echo $key->status; ?></td>
              </tr>
          	<?php  $count++; endforeach; ?>
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper