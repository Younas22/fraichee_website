<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    <!-- Add Product Modal -->
    <div class="modal fade" id="addProduct" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Product Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php echo form_open_multipart('products/addproduct', ['style' => 'padding-bottom: 30px' ]); ?>
            <div class="form-group">
              <?php echo form_label('Product Name', 'prod_name' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php
                $prod_input = [
                  'type'     => 'text', 
                  'name'     => 'prod_name',
                  'id'       => 'prod_name',
                  'placeholder' => 'Enter Product Name Here..',
                  'value'    => '',
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
              <!-- </div> -->
            </div> 

            <div class="form-group">
              <?php echo form_label('Category', 'service_type' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php
                $options  = [];
                foreach($prod_category as $cat){
                  $sid    = $cat['service_id'];
                  $sname  = $cat['name'];
                  $options[$sid] = $sname;
                }
                echo form_dropdown('service_type',$options,'',['class' => 'form-control']);
                ?>
              <!-- </div> -->
            </div>

            <div class="form-group">
              <?php echo form_label('Product Image', 'prod_image' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php
                $prod_input = [
                  'type'     => 'file', 
                  'name'     => 'prod_image',
                  'id'       => 'prod_image',
                  'class'    => 'form-control'
                ];
                echo form_upload($prod_input);
                ?>
              <!-- </div> -->
            </div>
            
            
          </div>

          <div class="modal-footer">
            <?php 
              $add_product_submit    = [
                'name'        => 'add_prod',
                'content'       => 'Add Product',
                'class'       => 'btn btn-success',
                'type'        => 'submit',
              ];
              $product_close_button = [
                'name'        => 'close',
                'content'       => 'Close',
                'class'       => 'btn btn-danger',
                'type'        => 'button',
                'data-dismiss'=> 'modal',
              ];
              echo form_button($add_product_submit);
              echo form_button($product_close_button);
              echo form_close();
            ?>
          </div>
        </div>
      </div>
    </div>
    <!-- product list start     -->
    <div class="panel panel-default">
      <div class="panel-heading">
        Products
        <button class="btn btn-info pull-right" style="margin-top: -7px;" data-toggle="modal" data-target="#addProduct">Add Product</button>
      </div>
      <div class="panel-body">
        
        <table id="table_id" class="display">
          <thead>
              <tr>
                  <th>Serial No.</th>
                  <th>Name</th>
                  <th>Service Name</th>
                  <th>Image</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Modify</th>
              </tr>
          </thead>
          <tbody>
            <?php  
            foreach($parent_prod as $key => $product ){
            ?>
              <tr>
                  <td><?php echo ($key+1); ?></td>
                  <td><?php echo $product['name'];?></td>
                  <td><?php echo $product['service_name'];?></td>
                  <td>
                    <img src="<?php echo base_url(); ?>assets/uploads/products/<?php echo $product['image'];?>" alt="Image not found" class="img-thumbnail" style="height: 60px; width:60px;">
                  </td>
                  <td><?php echo $product['date'];?></td>
                  <td><?php echo $product['status'];?></td>
                  <td>
                    <?php echo anchor('products/edit/'.$product['prod_id'], '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('products/delete/'.$product['prod_id'], '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', array('onclick' => 'return confirm("Are you sure?")') ); ?>
                  </td>
              </tr>
            <?php } ?>
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper