<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    
    <div class="panel panel-default">
      <div class="panel-heading">
        Edit Product
      </div>
      <div class="panel-body">
        
        <form method="post" action="<?php echo site_url('products/update'); ?>">
          <div class="form-group">
            <!-- <label>Id</label> -->
            <input type="text" name="pid" class="form-control" value="<?php echo $product->prod_id; ?>">
          </div>

          <div class="form-group">
            <label>Name</label>
            <input type="text" name="pname" class="form-control" value="<?php echo $product->name; ?>">
          </div>

          <div class="form-group">
            <label>Service Type</label>
            <select class="form-control" name="stype">
              <?php foreach($services as $skey => $sval ){ ?>
              <option value="<?php echo $sval['service_id']; ?>"><?php echo $sval['name']; ?></option>
              <?php } ?>
            </select>
          </div>

          <div class="form-group">
            <input type="submit" name="update_prod" value="Update">
          </div>
        </form>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper