<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    
    <div class="panel panel-default">
      <div class="panel-heading">
        Edit Category
      </div>
      <div class="panel-body">
        
        <form method="post" action="<?php echo site_url('categories/update'); ?>">
          <div class="form-group">
            <!-- <label>Id</label> -->
            <input type="hidden" name="sid" class="form-control" value="<?php echo $category->service_id; ?>">
          </div>

          <div class="form-group">
            <label>Name</label>
            <input type="text" name="sname" class="form-control" value="<?php echo $category->name; ?>">
          </div>

          <div class="form-group">
            <input type="submit" name="update_service" value="Update">
          </div>
        </form>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper