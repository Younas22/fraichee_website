<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    <!-- Add category Modal -->
    <div class="modal fade" id="addCategory" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Category Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php echo form_open('categories/add_category', ['style' => '' ]); ?>
            <div class="form-group">
              <?php echo form_label('Category Name', 'category_name' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php
                $name = [
                  'type'     => 'text', 
                  'name'     => 'category_name',
                  'id'       => 'category_name',
                  'placeholder' => 'Enter Category Name Here..',
                  'value'    => '',
                  'class'    => 'form-control'
                ];
                echo form_input($name);
              ?>
              <!-- </div> -->
            </div>

            <div class="form-group">
              <?php  
                echo form_label('Service For' ,'', [ 'class' => 'col-form-label' ]);
                  $options = [
                    'laundary'    => 'laundary',
                    'subscribe'   => 'subscribe',
                    'frontend'    => 'frontend',
                  ];
                  
                echo form_dropdown('panel_name', $options,'',['class'=>'form-control']);
              ?>
            </div>
            
          </div>

          <div class="modal-footer">
            <?php 
              $add_child_product_submit    = [
                'name'        => 'add_category',
                'content'     => 'Add Category',
                'class'       => 'btn btn-success',
                'type'        => 'submit',
              ];
              $child_product_close_button = [
                'name'        => 'close',
                'content'     => 'Close',
                'class'       => 'btn btn-danger',
                'type'        => 'button',
                'data-dismiss'=> 'modal',
              ];
              echo form_button($add_child_product_submit);
              echo form_button($child_product_close_button);
              echo form_close();
            ?>
          </div>
        </div>
      </div>
    </div>
    <!-- product list start     -->
    <div class="panel panel-default">
      <div class="panel-heading">
        Categories
        <button class="btn btn-info pull-right" style="margin-top: -7px;" data-toggle="modal" data-target="#addCategory">Add Category</button>
      </div>
      <div class="panel-body">
        
        <table id="table_id" class="display">
          <thead>
              <tr>
                  <th>Serial No.</th>
                  <th>Name</th>
                  <th>Panel</th>
                  <th>Modify</th>
              </tr>
          </thead>
          <tbody>
          	<?php 
          		foreach( $cat_detail as $key => $cat ): 
          			$sid    = $cat['service_id'];
                $name   = $cat['name'];
          			$panel  = $cat['panel'];
          	?>
          		<tr>
                  <td><?php echo ($key+1); ?></td>
                  <td><?php echo $name; ?></td>
                  <td><?php echo $panel; ?></td>
                  <td>
                    <?php echo anchor('categories/edit/'.$sid, '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('categories/drop/'.$sid, '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', '');?>
                  </td>
              </tr>
          	<?php endforeach; ?>
              <!-- <tr>
                  <td>Row 1 Data 1</td>
                  <td>Row 1 Data 2</td>
                  <td>
                    <?php echo anchor('categories', '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('categories', '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', '');?>
                  </td>
                  <td></td>
              </tr> -->
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper