<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    <!-- Add Product Modal -->
    <div class="modal fade" id="addChildProduct" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Child Product Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php echo form_open_multipart('products/addchildproduct', ['style' => '' ]); ?>

            <div class="form-group-row">
              <?php echo form_label('Parent Product', 'parent_prod_id' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php 
                echo form_dropdown('parent_prod', $pprod_options , [] , [ 'class' => 'form-control']); ?>
              <!-- </div> -->
            </div>

            <div class="form-group-row">
              <?php echo form_label('Child Product Name', 'child_prod_name' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php
                $prod_input = [
                  'type'     => 'text', 
                  'name'     => 'child_prod_name',
                  'id'       => 'child_prod_name',
                  'placeholder' => 'Enter Child Product Name Here..',
                  'value'    => '',
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
              <!-- </div> -->
            </div>

            <div class="form-group-row">
              <?php echo form_label('Price', 'cp_price' , [ 'class' => 'col-form-label' ]); ?>
                <?php
                $prod_input = [
                  'type'     => 'text', 
                  'name'     => 'cp_price',
                  'placeholder' => 'Enter Price Here..',
                  'min'      => 1,
                  'value'    => 1,
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
            </div>

            <div class="form-group-row">
              <?php echo form_label('Desc', 'cp_desc' , [ 'class' => 'col-form-label' ]); ?>
              <!-- <div class="col-sm-10"> -->
                <?php
                $prod_input = [
                  'type'     => 'text', 
                  'name'     => 'cp_desc',
                  'placeholder' => 'Enter Description Here..',
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
              <!-- </div> -->
            </div>

            <div class="form-group-row">
              <?php echo form_label('Child Product Image', 'cp_image' , [ 'class' => 'col-form-label' ]); ?>
                <?php
                $prod_input = [
                  'type'     => 'file', 
                  'name'     => 'cp_image',
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
            </div>
            
          </div>

          <div class="modal-footer">
            <?php 
              $add_child_product_submit    = [
                'name'        => 'add_child_prod',
                'content'       => 'Add Child Product',
                'class'       => 'btn btn-success',
                'type'        => 'submit',
              ];
              $child_product_close_button = [
                'name'        => 'close',
                'content'       => 'Close',
                'class'       => 'btn btn-danger',
                'type'        => 'button',
                'data-dismiss'=> 'modal',
              ];
              echo form_button($add_child_product_submit);
              echo form_button($child_product_close_button);
              echo form_close();
            ?>
          </div>
        </div>
      </div>
    </div>
    <!-- product list start     -->
    <div class="panel panel-default">
      <div class="panel-heading">
        Child Products
        <button class="btn btn-info pull-right" style="margin-top: -7px;" data-toggle="modal" data-target="#addChildProduct">Add Child Product</button>
      </div>
      <div class="panel-body">
        
        <table id="table_id" class="display">
          <thead>
              <tr>
                  <th>Serial No.</th>
                  <th>Parent Product</th>
                  <th>Child Product</th>
                  <th>Image</th>
                  <th>Desc.</th>
                  <th>Price</th>
                  <th>Status</th>
                  <th>Modify</th>
              </tr> 
          </thead>
          <tbody>
            <?php 
            foreach($child_prod as $key => $cprod ): 
            ?>
              <tr>
                  <td><?php echo ($key + 1); ?></td>
                  <td><?php echo $cprod['product_name']; ?></td>
                  <td><?php echo $cprod['cp_name']; ?></td>
                  <td>
                    <img src="<?php echo base_url(); ?>assets/uploads/products/<?php echo $cprod['cp_image']; ?>" class="img img-thumbnail" style="height: 50px; width:60px;">
                  </td>
                  <td><?php echo $cprod['cp_desc']; ?></td>
                  <td><?php echo $cprod['cp_price']; ?></td>
                  <td><?php echo $cprod['status']; ?></td>
                  <td>
                    <?php echo anchor('products/childedit/'.$cprod['cp_id'], '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('products/childdel/'.$cprod['cp_id'], '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', ''); ?>
                  </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper