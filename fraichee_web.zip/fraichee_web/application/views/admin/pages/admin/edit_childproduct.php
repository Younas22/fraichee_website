<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="panel panel-default">
      <div class="panel-heading">
        <?php echo ucfirst($breadcrumb); ?>
      </div>
      <div class="panel-body">
        
        <form method="post" action="<?php echo site_url('products/cprod_update'); ?>">
          <div class="form-group">
            <input type="hidden" name="cpid" class="form-control" value="<?php echo $child_prod->cp_id; ?>">
          </div>

          <div class="form-group">
            <label>Choose Product:</label>
            <select class="form-control" name="pid">
              <?php foreach($product as $pkey => $pval ){ ?>
                <option value="<?php echo $pval['prod_id']; ?>"><?php echo $pval['name']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="cp_name" class="form-control" value="<?php echo $child_prod->cp_name; ?>">
          </div>

          <div class="form-group">
            <label>Price</label>
            <input type="text" min="1" name="cp_price" value="<?php echo $child_prod->cp_price; ?>" class="form-control">
          </div>

          <div class="form-group">
            <label>Description</label>
            <input type="text" name="cp_desc" value="<?php echo $child_prod->cp_desc; ?>" class="form-control">
          </div>

          <div class="form-group">
            <input type="submit" name="update_childprod" value="Update">
          </div>
        </form>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper