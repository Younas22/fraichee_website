<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    
    <!-- product list start     -->
    <div class="panel panel-default">
      <div class="panel-heading">
        Categories
      </div>
      <div class="panel-body">
        
        <table id="table_id" class="display">
          <thead>
              <tr>
                  <th>Serial No.</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Password</th>
                  <th>Contact</th>
                  <th>Image</th>
                  <th>Address</th>
                  <th>Status</th>
                  <th>Modify</th>
                  
              </tr>
          </thead>
          <tbody>
          	<?php 
          		foreach( $users_list as $key => $user ): 
                $user_id = $user['user_id'];
                if ($user['status'] == 1) {
                   $user_status = 'Verified';
                }else{
                  $user_status = 'Un Verified';
                }
          	?>
          		<tr>
                  <td><?php echo ($key+1); ?></td>
                  <td><?php echo $user['name']; ?></td>
                  <td><?php echo $user['email']; ?></td>
                  <td><?php echo $user['password']; ?></td>
                  <td><?php echo $user['contact']; ?></td>
                  <td><?php echo $user['image']; ?></td>
                  <td><?php echo $user['address']; ?></td>
                  <td width="10%"><?=$user_status?></td>

                  <td style="float: rigdht;">
                    <!-- <?php echo anchor('admin/users/edit/'.$user_id, '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?> -->
                    <?php echo anchor('admin/users/drop/'.$user_id, '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', '');?>
                  </td>
              </tr>
          	<?php endforeach; ?>
              <!-- <tr>
                  <td>Row 1 Data 1</td>
                  <td>Row 1 Data 2</td>
                  <td>
                    <?php echo anchor('categories', '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('categories', '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', '');?>
                  </td>
                  <td></td>
              </tr> -->
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper