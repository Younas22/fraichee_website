<!--Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php 
            echo ucfirst($breadcrumb); ?>
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class=" panel panel-primary" id="collapseExample">
            <div class="panel-heading">Add Coupon</div>
            <div class="panel-body" style="padding:20px;">
              <form method="post" action="<?php echo site_url('admin/update-coupen-code'); ?>" enctype="multipart/form-data">
                <div class="form-group">
                  <label>Coupon code: </label>
                  <input type="text" name="coupon_code" class="form-control" placeholder="Add Coupen code" value="<?=$coupon->coupon_code?>" />

                  <br><label>Coupon value: </label>
                  <input type="text" name="coupon_val" class="form-control" placeholder=" Coupen value" value="<?=$coupon->val?>"/>
                </div>

                <div class="form-group">
                  <button type="submit" class="btn btn-info">Save</button>
                </div>
              </form>
            </div>
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper