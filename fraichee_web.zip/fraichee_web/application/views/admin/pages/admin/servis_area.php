<!--Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php 
            echo ucfirst($breadcrumb); ?>
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class=" panel panel-primary" id="collapseExample">
            <div class="panel-heading">Service Location</div>
            <div class="panel-body" style="padding:20px;">
              <form method="post" action="<?php echo site_url('add-address'); ?>" enctype="multipart/form-data">
                <div class="form-group">
                  <label>Address: </label>
                  <input type="text" name="address" id="address" class="form-control" placeholder="Find Your Address" />
                  <div id="addressList" class="text-dark bg-light p-3"></div>
                </div>

                <div class="form-group">
                  <button type="submit" class="btn btn-info">Save</button>
                </div>
              </form>
            </div>
          </div>
        </section><!-- /.content -->
        <center><strong class="">Address</strong></center><hr>
        <h4 class="text-center"><?=get_service_address()->address?></h4>
      </div><!-- /.content-wrapper