<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php echo ucfirst($breadcrumb); ?>
          </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
        
          <!-- Main row -->
          <div class="row">
            
            <section class="col-md-12">


              <!-- form wizard start here -->
              <!--   <div class="stepwizard">
                    <div class="stepwizard-row setup-panel">
                        <div class="stepwizard-step col-xs-3"> 
                            <a href="#step-1" type="button" class="btn btn-success btn-circle">1</a>
                            <p><small>Subscription Plan</small></p>
                        </div>
                        <div class="stepwizard-step col-xs-3"> 
                            <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                            <p><small>Week Days</small></p>
                        </div>
                        <div class="stepwizard-step col-xs-3"> 
                            <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                            <p><small>Choose Products</small></p>
                        </div>
                    </div>
                </div>
                
                <style type="text/css">
                    body{
                      margin:0px;
                    }
                  .select2{
                    width: 400px !important;
                  }
                </style>
                <form role="form" method="POST" action="">
                    <div class="panel panel-primary setup-content" id="step-1">
                        <div class="panel-heading">
                             <h3 class="panel-title">Subscription Plan</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">

                                <div class="card text-white bg-primary  col-md-4 text-center" style="margin-right:0px;">
                                  <div class="card-body">
                                    <h4 class="card-title">Home Linen</h4>
                                    <ul class="list-group text-primary">
                                      <li class="list-group-item">Cras justo odio</li>
                                      <li class="list-group-item">Dapibus ac facilisis in</li>
                                      <li class="list-group-item">Morbi leo risus</li>
                                      <li class="list-group-item">Porta ac consectetur ac</li>
                                      <li class="list-group-item">
                                        <input type="radio" name="subscription_plan" class="sub_plan" value="home_linen">
                                      </li>
                                    </ul>
                                  </div>
                                </div>

                                <div class="card text-white bg-info col-md-4 text-center" style="margin-right: 0px;">
                                  <div class="card-body">
                                    <h4 class="card-title">Home Premium</h4>
                                    <ul class="list-group text-primary">
                                      <li class="list-group-item">Cras justo odio</li>
                                      <li class="list-group-item">Dapibus ac facilisis in</li>
                                      <li class="list-group-item">Morbi leo risus</li>
                                      <li class="list-group-item">Porta ac consectetur ac</li>
                                      <li class="list-group-item">
                                        <input type="radio" name="subscription_plan" class="sub_plan" value="home_premium">
                                      </li>
                                    </ul>
                                  </div>
                                </div>

                                <div class="card bg-primary col-md-4 text-center" style="margin-right: 0px;">
                                  <div class="card-body">
                                    <h4 class="card-title">Commercial</h4>

                                    <ul class="list-group text-primary">
                                      <li class="list-group-item">Cras justo odio</li>
                                      <li class="list-group-item">Dapibus ac facilisis in</li>
                                      <li class="list-group-item">Morbi leo risus</li>
                                      <li class="list-group-item">Porta ac consectetur ac</li>
                                      <li class="list-group-item">
                                        <input type="radio" name="subscription_plan" class="sub_plan" value="commercial">
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                            </div>

                            <button class="btn btn-primary nextBtn pull-right" type="button" style="margin-top:20px;">Next</button>
                        </div>
                    </div>
                    
                    <div class="panel panel-primary setup-content" id="step-2">
                        <div class="panel-heading">
                             <h3 class="panel-title">Week Days</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label class="control-label">Week Days</label>
                                <select class="form-control select2" multiple="multiple" name="perweek_delivery[]"></select>
                            </div>
                            <button class="btn btn-primary nextBtn pull-right" type="button">Next</button>
                        </div>
                    </div>
                    
                    <div class="panel panel-primary setup-content" id="step-3">
                        <div class="panel-heading">
                             <h3 class="panel-title">Products</h3>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <label class="control-label">Parent Product</label>
                                <select name="parent_product" class="form-control" data-baseurl = "<?php echo base_url(); ?>">
                                  <?php 
                                    foreach($parent_products as $pkey => $pval ){ ?>
                                      <option value="<?php echo $pval['prod_id']; ?>"><?php echo $pval['name'];?></option>
                                  <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Child Products</label>
                                <select name="child_product" class="form-control"></select>
                            </div>
                            <button class="btn btn-primary nextBtn pull-right" type="button" style="margin-top:20px;">Submit</button>
                        </div>
                    </div>
                    
                </form> -->
              <!-- form wizard ends here -->


              <!-- panel form -->
              <div class="panel panel-primary text-white">
                <div class="panel-heading">
                  <h3 style="margin:0px;">Order</h3>
                </div>
                <div class="panel-body">
                  <form method="post" action="<?php echo site_url('subscriber/addOrder'); ?>">
                    <div class="form-group">
                      <label class="form-label">Category</label>
                      <select name="category" class="form-control">
                        <?php 
                        foreach($categories as $key => $category ){
                        ?>
                          <option value="<?php echo $category['cat_id']; ?>"><?php echo $category['cat_name'];?></option>
                        <?php } ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label class="form-label">Week Days</label>
                      <?php $days = [
                        'monday'    => 'monday',
                        'tuesday'   => 'tuesday',
                        'wednesday' => 'wednesday',
                        'thursday'  => 'thursday',
                        'friday'    => 'friday',
                        'saturday'  => 'saturday',
                        'sunday'    => 'sunday'
                      ]; ?>
                      <select class="form-control selectpicker" multiple="multiple" name="perweek_delivery[]">
                        <?php  
                        foreach( $days as $key => $day ){
                          echo '<option value="'.$key.'">'.$day.'</option>';
                        }
                        ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label class="control-label">Parent Product</label>
                      <select name="parent_product" class="form-control">
                        <?php 
                          foreach($parent_products as $pkey => $pval ){ ?>
                            <option value="<?php echo $pval['prod_id']; ?>"><?php echo $pval['name'];?></option>
                        <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label class="control-label">Child Products</label>
                      <select name="child_product[]" class="form-control selectpicker" multiple data-live-search="true">
                      </select>
                    </div>

                    <div class="form-group">
                      <input type="submit" class="btn btn-success" name="add_order" value="Place Order">
                    </div>
                  </form>
                  

                </div>
              </div>
              <!-- panel form ends here -->

              
            </section>
            
          </div><!-- /.row (main row) -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

      <script type="text/javascript">
        // jQuery('select').selectpicker();
      </script>


      