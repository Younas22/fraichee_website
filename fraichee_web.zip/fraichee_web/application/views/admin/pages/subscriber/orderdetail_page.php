<?php  
defined('BASEPATH') or die('You can not directly access this page.');
?>
<!--Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo ucfirst($breadcrumb); ?>
    </h1>
    <!-- <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol> -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    <!-- Add category Modal -->
    <!-- <div class="modal fade" id="addCategory" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Category Form</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <div class="modal-body">
            <?php echo form_open('categories/add_category', ['style' => '' ]); ?>
            <div class="form-group-row">
              <?php echo form_label('Category Name', 'category_name' , [ 'class' => 'col-form-label' ]); ?>
                <?php
                $prod_input = [
                  'type'     => 'text', 
                  'name'     => 'category_name',
                  'id'       => 'category_name',
                  'placeholder' => 'Enter Category Name Here..',
                  'value'    => '',
                  'class'    => 'form-control'
                ];
                echo form_input($prod_input);
                ?>
            </div>
            
          </div>

          <div class="modal-footer">
            <?php 
              $add_child_product_submit    = [
                'name'        => 'add_category',
                'content'     => 'Add Category',
                'class'       => 'btn btn-success',
                'type'        => 'submit',
              ];
              $child_product_close_button = [
                'name'        => 'close',
                'content'     => 'Close',
                'class'       => 'btn btn-danger',
                'type'        => 'button',
                'data-dismiss'=> 'modal',
              ];
              echo form_button($add_child_product_submit);
              echo form_button($child_product_close_button);
              echo form_close();
            ?>
          </div>
        </div>
      </div>
    </div> -->
    <!-- product list start     -->
    <div class="panel panel-default">
      <div class="panel-heading">
        Orders
        <!-- <button class="btn btn-info pull-right" style="margin-top: -7px;" data-toggle="modal" data-target="#addCategory">Add Category</button> -->
      </div>
      <div class="panel-body">
        
        <table class="display orderTable">
          <thead>
              <tr>
                  <th>Serial No.</th>
                  <th>User Name</th>
                  <th>User Role</th>
                  <th>Category</th>
                  <th>Delivery Days</th>
                  <th>Product</th>
                  <th>Child Product</th>
                  <th>Status</th>
                  <th>Modify</th>
              </tr>
          </thead>
          <tbody>
          	<?php 
          		foreach( $order_details as $key => $order ): 
                $user_id        = $order['user_id'];
                $user_role      = $order['user_role'];
                $cat_id         = $order['cat_id'];
                $parent_prod_id = $order['parent_prod_id'];
                $child_prod_id  = $order['child_prod_id'];
                $delivery_days  = $order['delivery_days'];
          			$status         = $order['status'];
          	?>
          		<tr>
                  <td><?php echo ($key+1); ?></td>
                  <td><?php echo userName($user_id); ?></td>
                  <td><?php echo $user_role; ?></td>
                  <td><?php echo catName($cat_id); ?></td>
                  <td><?php echo daysToString($delivery_days); ?></td>
                  <td><?php echo prodName($parent_prod_id); ?></td>
                  <td><?php echo childProdToString($child_prod_id); ?></td>
                  <td><?php echo $status; ?></td>
                  <td>
                    <?php echo anchor('categories/edit/$cat_id', '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('categories/drop/$cat_id', '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', '');?>
                  </td>
              </tr>
          	<?php endforeach; ?>
              <!-- <tr>
                  <td>Row 1 Data 1</td>
                  <td>Row 1 Data 2</td>
                  <td>
                    <?php echo anchor('categories', '<i class="fa fa-pencil-square-o" style="font-size:20px;"></i> ', ''); ?>
                    <?php echo anchor('categories', '<i class="fa fa-trash-o" style="font-size:20px; color:red;"></i> ', '');?>
                  </td>
                  <td></td>
              </tr> -->
          </tbody>
      </table>

      </div>
    </div>
    <!-- product list ends here -->

  </section><!-- /.content -->
</div><!-- /.content-wrapper