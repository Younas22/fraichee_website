<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
</style>


<!-- ======= Footer ======= -->
  <footer id="footer" class="footerd">
    <div class="container">
      <div class="row d-flex align-items-center">
        <div class="col-lg-12 text-lg-center text-center">
          <div class="copyright">
            &copy; Copyright <strong><a href="<?=base_url()?>" class="text-light">Fraichee</a></strong>. All Rights Reserved
          </div>
          <div class="credits d-none">
            Designed by <a href="https://fiverr.com/deftmasters">Bakhtawar Shah</a>
          </div>
        </div>
        
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url() ?>assets/frontend/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets/frontend/vendor/waypoints/jquery.waypoints.min.js"></script>
      <script src="<?php echo base_url() ?>assets/frontend/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
  <!-- bootstrap select -->
  <script type="text/javascript" src="<?php echo base_url() ?>assets/bootstrap/js/bootstrap-select.js"></script> 

  <script src="<?php echo base_url() ?>assets/frontend/vendor/php-email-form/validate.js"></script>

  <script src="<?php echo base_url() ?>assets/frontend/vendor/counterup/counterup.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/venobox/venobox.min.js"></script>
  <script src="<?php echo base_url() ?>assets/frontend/vendor/aos/aos.js"></script>
  <!-- Template Main JS File -->
  <script src="<?php echo base_url() ?>assets/frontend/js/main.js"></script>

  <?php 
  if( $panel == 'customer' || $panel == 'laundary' || $panel == 'subscribe' ){ ?>
    <script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.datatables.min.js" type="text/javascript"></script>
  <?php }
  ?>


  <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
    <script type="text/javascript">
        //set your publishable key
        Stripe.setPublishableKey('pk_test_KIhUx4DZXHOnK6tUOxtdEMTD00phOqJ9gN');
        
        //callback to handle the response from stripe
        function stripeResponseHandler(status, response) {
            if (response.error) {
                //enable the submit button
                $('#payBtn').removeAttr("disabled");
                //display the errors on the form
                // $('#payment-errors').attr('hidden', 'false');
                $('#payment-errors').addClass('alert alert-danger');
                $("#payment-errors").html(response.error.message);
            } else {
                var form$ = $("#paymentFrm");
                //get token id
                var token = response['id'];
                //insert the token into the form
                form$.append("<input type='hidden' name='stripeToken' value='" + token + "' />");
                //submit form to the server
                form$.get(0).submit();
            }
        }
        $(document).ready(function() {
            //on form submit
            $("#paymentFrm").submit(function(event) {
                //disable the submit button to prevent repeated clicks
                $('#payBtn').attr("disabled", "disabled");
                
                //create single-use token to charge the user
                Stripe.createToken({
                    number: $('#card_num').val(),
                    cvc: $('#card-cvc').val(),
                    exp_month: $('#card-expiry-month').val(),
                    exp_year: $('#card-expiry-year').val()
                }, stripeResponseHandler);
                
                //submit from callback
                return false;
            });
        });
    </script>
</body>

</html>