<!-- ======= Header ======= -->
  <!-- <header id="header" class="fixed-top d-flex align-items-center"> -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container-fluid d-flex align-items-center">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="<?php echo base_url(); ?>"><span>Fraichee</span></a></h1>
      </div>
      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li>
            <?php $cart = '';
            if( $panel == 'laundary'){ 
              $cart = 'laundary_cartDetails';
              ?>
              <!-- Button trigger modal -->
              <!-- <button type="button" class="btn btn-default text-white mr-2 <?php echo $cart; ?>" data-toggle="modal" data-target="#<?php echo $cart; ?>" style="font-size:20px;">
                <i class="fa fa-shopping-cart" ></i> Cart
              </button> -->

              <a href="<?php echo site_url('customer/laundary_cart'); ?>" class="btn btn-default mr-2 <?php echo $cart; ?>"  style="font-size:20px; position: relative;">
                <i class="fa fa-shopping-cart" ></i> Cart<span class="badge"><?php echo $total_carts; ?></span>
              </a>

            <?php } 
            elseif( $panel == 'subscribe' ){ 
              $cart = 'subscribe_cartDetails';
              ?>
              
              <a href="<?php echo site_url('customer/subscribe_cart'); ?>" class="btn btn-default  mr-2 <?php echo $cart; ?>"  style="font-size:20px;">
                <i class="fa fa-shopping-cart" ></i> Cart<span class="badge"><?php echo $total_carts; ?></span>
              </a>
            <?php } ?>
          </li> 

          <li class="get-started">
            <div class="btn-group">
              <button class="btn btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="outline:none !important; box-shadow: none; position:relative; top:9px;">
                Hi, <?= ucfirst(user_address()->name); ?>
              </button>
              <div class="dropdown-menu customerControlls">
                <ul class="list-group" style="width: 210px;">
                  <li class="list-group-item border-0" style="border:none;">
                    <a href="<?php echo site_url('customer/laundary/profile'); ?>" class="ml-0 pl-1">Profile</a>
                  </li>
                  <li class="list-group-item border-0">
                    <a href="<?php echo site_url('customer/laundary/order_history'); ?>" class="ml-0 pl-1">Order History</a>
                  </li>

                  <li class="list-group-item border-0">
                    <a href="<?php echo site_url('customer/logout'); ?>" class="ml-0 pl-1">Logout</a>
                  </li>
                </ul>
              </div>
            </div>
          </li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header-->

  <!-- Cart Modal -->
  <div class="modal fade" id="<?php echo $cart; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header bg-info text-white">
          <h5 class="modal-title" id="exampleModalLabel">Cart Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" style="max-height: 250px; overflow-y: auto;">
          
            <table class="table table-hover">
              <tbody class="cartmodalbody">
              
              </tbody>
            </table>

        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
          <?php if($panel == 'laundary'){ ?>
            <button type="button" class="btn btn-success laundary_cartcheckout">Check Out</button>
          <?php }else{ ?>
            <button type="button" class="btn btn-success subscribe_cartcheckout">Check Out</button>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>


  <!-- cartBox -->
  <!-- <div class="container-fluid">
    <div class="row">
      
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="cartBox p-4 bg-light rounded" style="margin-top: 100px;">
          <form method="POST" action="">
          <div class="form-row align-items-center">
            <div class="col-auto">
              <label>1</label>
            </div>
            <div class="col-auto">
              <label>Image</label>
            </div>
            <div class="col-auto">
              <input class="form-control" type="number" min="1" placeholder="Quantity">
            </div>
            <div class="col-auto">
              <select multiple="multiple" class="form-control" name="days[]">
              <?php $days = array('monday' => 'monday', 'tuesday'=>'tuesday'); 
              foreach($days as $key => $day ){ ?> 
                <option value="<?php echo $key; ?>"><?php echo $day; ?></option>
              <?php }
              ?>
              </select>
            </div>
            <div class="col-auto">
              <button type="submit" class="btn btn-primary mb-2" name="submit">Remove</button>
            </div>
          </div>
        </form>
        </div>      
      </div>
      <div class="col-md-3"></div>
    </div>
  </div> -->
  


  <!-- cartBox ends here  -->