<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Fraichee | <?php echo $title; ?> </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url() ?>assets/frontend/img/favicon.png" rel="icon">
  <link href="<?php echo base_url() ?>assets/frontend/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url() ?>assets/frontend/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/frontend/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/frontend/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/frontend/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/frontend/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/frontend/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/frontend/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url() ?>assets/frontend/css/style.css" rel="stylesheet">
  <?php if( $panel == 'laundary' OR $panel == 'subscribe' OR $panel == 'customer'){ ?>
  <link href="<?php echo base_url() ?>assets/frontend/css/customer.css" rel="stylesheet">
    <!-- data table css -->
  <link href="<?php echo base_url(); ?>assets/plugins/datatables/jquery.datatables.min.css" rel="stylesheet" type="text/css" />
  <?php }?>

 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />   -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  


 
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

  <style type="text/css">
    .service_type_section{
      margin-top:20px;
    }
    .service_cat_btn,.prod_btn{
      border-radius: 30px;
      background: #edf1f7;
      color: #000;
      border: #edf1f7;
      margin-right: 5px;
      margin-bottom: 5px;
    }
    .service_cat_btn:hover,.prod_btn:hover{
      background-color: #73c3e4 !important;
    }
    .service_cat_btn.active, .prod_btn.active{
      background-color: #73c3e4 !important;
    }
    .datepicker-days table tr th.prev, .datepicker-days table tr th.next {
        display: none;
    }
  </style>
  <!-- =======================================================
  * Template Name: Fraichee - v1.0
  * Template URL: https://fiverr.com/deftmasters
  * Author: Bakhtawar Shah
  ======================================================== -->

<!-- <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script> -->



  <script>
 $(document).ready(function(){
      $('#address').keyup(function(){  
        let url = "<?=base_url('location')?>";
           var query = $(this).val();  
           if(query != '')  
           {  
                $.ajax({  
                     url: url,  
                     method:"POST",  
                     data:{keyword:query},  
                     success:function(data)  
                     {  
                          $('#addressList').fadeIn();  
                          $('#addressList').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', 'li', function(){  
           $('#address').val($(this).text());  
           $('#addressList').fadeOut();  
      });




$('#postcode').click(function(){  
        let url = "<?=base_url('location')?>";
           var query = $('#get_postcode').val();  
           if(query != '')  
           {  
                $.ajax({  
                     url: url,  
                     method:"POST",  
                     data:{keyword:query},  
                     success:function(data)  
                     {  
                          // $('#addressList').fadeIn();  
                          $('#list_of_address').html(data);  
                     }  
                });  
           }  
      });  
      // $(document).on('click', 'li', function(){  
      //      $('#address').val($(this).text());  
      //      $('#addressList').fadeOut();  
      // }); 




 }); 
  </script>
</head>

<body>
