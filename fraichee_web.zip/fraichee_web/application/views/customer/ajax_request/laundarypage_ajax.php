<script>
	jQuery(document).ready( ()=>{


		// jQuery('.service_type_btn').on('click', function(){
		// 	var sid = jQuery(this).data('serviceid');
		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('customer_ajax/service_type'); ?>',
		// 		type:'POST',
		// 		data:{sid:sid},

		// 		success:function(response){
		// 			var serviceobj = JSON.parse(response);
		// 			jQuery('.product_category_section').html(serviceobj);
		// 		}
		// 	});
		// });

		// jQuery(document).on('click','.product_category_btn',function(){
		// 	var pc_id = jQuery(this).data('prodcatid');
		// 	console.log('product category id is => '+pc_id);
		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('customer_ajax/product_category'); ?>',
		// 		type: 'POST',
		// 		data:{pc_id:pc_id},

		// 		success:function(response){
		// 			var pcatobj = JSON.parse(response);
		// 			jQuery('.cartproducts_wrapper').html(pcatobj);	
		// 		}
		// 	});
		// });

		var currentTime = new Date();
		var maxDate     =  new Date(currentTime.getFullYear(), currentTime.getMonth() +1, +0); // one day before next month
		jQuery('.date').datepicker({
		 	multidate: true,
			format: 'dd-mm-yyyy',
			startDate: new Date(),
			endDate: new Date(currentTime.getFullYear(), currentTime.getMonth() +1, +0),
		});
		
		jQuery(document).on('click', '.addCartBtn', function(e){
			e.preventDefault();
			console.log(this);
			cp_id = jQuery(this).data('cartprodid');
			console.log('child product id => '+cp_id);
			jQuery.ajax({ 
				url:'<?php echo site_url('customer_ajax/addProdIntoCart'); ?>',
				type:'POST',
				data:{cp_id : cp_id },

				success:function(response){
					console.log('response => '+response);
					if( response == 'false' ){
						alert('already exists');
					}else{
						alert('product added into laundary cart.');
						location.reload();

					}
				}
			});
		});


			$('.cartqty').click(function(){
			let userid = jQuery(this).data('userid');
			let cartid = jQuery(this).data('cartid');
			let panel  = jQuery(this).data('panel');
			let qty    = jQuery(this).val();
			// alert(qty);
			console.log('its cart qty update => ' + qty);

			jQuery.ajax({
				url:'<?php echo site_url('customer_ajax/updateLaundaryQty'); ?>',
				type: 'post',
				data:{userid:userid, cartid:cartid, panel:panel, qty:qty},

				success:function(response){
					// alert(response);
					if(response == '	 true'){
						location.reload();
					}
				}
			});
			});


		// jQuery('.laundary_cartDetails').on('click', function(){
		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('customer_ajax/cartdetaillist'); ?>',
		// 		success:function(response){
		// 			cartobj = JSON.parse(response);
		// 			// console.log(response);
		// 			jQuery('.cartmodalbody').html(cartobj);
		// 		}
		// 	});
		// });

		// jQuery('.removeCart').each(function(){
		// 	jQuery(this).on('click',function(){
		// 		console.log('hello');
		// 	});
		// });

		// jQuery(document).on('click', '.removeCart', function(){
		// 	console.log('hello world');
		// 	var cartid = jQuery(this).data('removecartid');
		// 	console.log('id => '+cartid);

		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('customer_ajax/removecart'); ?>',
		// 		type:'POST',
		// 		data:{ cartid:cartid },

		// 		success:function(response){
		// 			cartobj = JSON.parse(response);
		// 			jQuery('.cartmodalbody').html(cartobj);
		// 		}
		// 	});
		// });

		// jQuery(document).on('click', '.laundary_cartcheckout', function(){
		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('customer_ajax/checkout'); ?>',
		// 		success:function(response){
		// 			window.location.reload();
		// 		}
		// 	});
		// });

		jQuery(document).ready( function () {
		    jQuery('#table_id').DataTable();
		} );

		// var form  = jQuery(".require-validation");
		// console.log(form);
		// jQuery('form.require-validation').bind('submit', function(e) {
		// 	if (!form.data('cc-on-file')) {
		//       e.preventDefault();
		//       Stripe.setPublishableKey(form.data('stripe-publishable-key'));
		//       Stripe.createToken({
		//         number: jQuery('.card-number').val(),
		//         cvc: jQuery('.card-cvc').val(),
		//         exp_month: jQuery('.card-expiry-month').val(),
		//         exp_year: jQuery('.card-expiry-year').val()
		//       }, stripeResponseHandler);
		//     }
		//     console.log(Stripe);
		// });
		
		// function stripeResponseHandler(status, response) {
	 //        if (response.error) {
	 //            $('.error')
	 //                .removeClass('hide')
	 //                .find('.alert')
	 //                .text(response.error.message);
	 //        } else {
	 //            var token = response['id'];
	 //            $form.find('input[type=text]').empty();
	 //            $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
	 //            $form.get(0).submit();
	 //        }
	 //    }


	 $(function () {
		var $stripeForm = $(".form-validation");
		console.log($stripeForm);
		$('form.form-validation').bind('submit', function (e) {
			var $stripeForm = $(".form-validation"),
				inputSelector = ['input[type=email]', 'input[type=password]',
					'input[type=text]', 'input[type=file]',
					'textarea'
				].join(', '),
				$inputs = $stripeForm.find('.required').find(inputSelector),
				$errorMessage = $stripeForm.find('div.error'),
				valid = true;
			$errorMessage.addClass('hide');

			$('.has-error').removeClass('has-error');
			$inputs.each(function (i, el) {
				var $input = $(el);
				if ($input.val() === '') {
					$input.parent().addClass('has-error');
					$errorMessage.removeClass('hide');
					e.preventDefault();
				}
			});

			if (!$stripeForm.data('cc-on-file')) {
				e.preventDefault();
				Stripe.setPublishableKey($stripeForm.data('stripe-publishable-key'));
				Stripe.createToken({
					number: $('.card-number').val(),
					cvc: $('.card-cvc').val(),
					exp_month: $('.card-expiry-month').val(),
					exp_year: $('.card-expiry-year').val()
				}, stripeResponseHandler);
			}

		});

		function stripeResponseHandler(status, res) {
			if (res.error) {
				$('.error')
					.removeClass('hide')
					.find('.alert')
					.text(res.error.message);
			} else {
				var token = res['id'];
				$stripeForm.find('input[type=text]').empty();
				$stripeForm.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
				$stripeForm.get(0).submit();
			}
		}


/*////////////////coupon_code///////////*/
$('#apply').click(function () {
		let coupon_code = $('#coupon_code').val();
		jQuery.ajax({
			url:'<?php echo site_url('coupon_code'); ?>',
			type: 'post',
			data:{coupon_code:coupon_code},
				success:function(res){
				if (res == 	 0) {
					alert('Coupon Code is wrong, try again');
				}else{
					alert('Coupon Code applyed');
					location.reload();
				}}
		});

});
/*////////////////////end////////////////*/


	});

});


</script>