<script type="text/javascript">
	jQuery(document).ready(function(){
		var currentTime = new Date();
		var maxDate     =  new Date(currentTime.getFullYear(), currentTime.getMonth() +1, +0); // one day before next month
		jQuery('.date').datepicker({
		 	multidate: true,
			format: 'dd-mm-yyyy',
			startDate: new Date(),
			endDate: new Date(currentTime.getFullYear(), currentTime.getMonth() +1, +0),
		});
		
		// console.log('hi this is subscriber');
		// jQuery('.service_type_btn').on('click', function(){
		// 	var sid = jQuery(this).data('serviceid');
		// 	console.log('service id => '+sid);
		// 	jQuery.ajax({
		// 		url:'<?php //echo site_url('subscribe_ajax/service_type'); ?>',
		// 		type:'POST',
		// 		data:{sid:sid},

		// 		success:function(response){
		// 			var serviceobj = JSON.parse(response);
		// 			jQuery('.product_category_section').html(serviceobj);
		// 		}
		// 	});
		// });

		// jQuery(document).on('click','.product_category_btn',function(){
		// 	var pc_id = jQuery(this).data('prodcatid');
		// 	console.log('product category id is => '+pc_id);
		// 	jQuery.ajax({
		// 		url:'<?php //echo site_url('subscribe_ajax/product_category'); ?>',
		// 		type: 'POST',
		// 		data:{pc_id:pc_id},

		// 		success:function(response){
		// 			var pcatobj = JSON.parse(response);
		// 			jQuery('.cartproducts_wrapper').html(pcatobj);	
		// 		}
		// 	});
		// });

		jQuery(document).on('click', '.addCartBtn', function(e){
			e.preventDefault();
			cp_id = jQuery(this).data('cartprodid');
			jQuery.ajax({
				url:'<?php echo site_url('subscribe_ajax/addProdIntoCart'); ?>',
				type:'POST',
				data:{cp_id : cp_id },

				success:function(response){
					console.log(response);
					if(response == 'false'){
						alert('already exists');
					}
					else{
						alert('product added into subscribe cart');
					}
				}
			});
		});


		// jQuery('.subscribe_cartDetails').on('click', function(){
		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('subscribe_ajax/cartdetaillist'); ?>',
		// 		success:function(response){
		// 			cartobj = JSON.parse(response);
		// 			console.log(response);
		// 			jQuery('.cartmodalbody').html(cartobj);
		// 		}
		// 	});
		// });

		// jQuery(document).on('click', '.subscribe_cartcheckout', function(){
		// 	days = jQuery(this).parents().find('.delivery_days').val();

		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('subscribe_ajax/checkout'); ?>',
		// 		method:'post',
		// 		data:{days:days},
				
		// 		success:function(response){
		// 			window.location.reload();
		// 		}
		// 	});
		// });

		// jQuery(document).on("keyup", '.cartqty' , function(){
		// 	userid = jQuery(this).data('userid');
		// 	cartid = jQuery(this).data('cartid');
		// 	panel  = jQuery(this).data('panel');
		// 	qty    = jQuery(this).val();
		// 	console.log('its cart qty update => ' + qty);

		// 	jQuery.ajax({
		// 		url:'<?php echo site_url('customer_ajax/updateLaundaryQty'); ?>',
		// 		type: 'post',
		// 		data:{userid:userid, cartid:cartid, panel:panel, qty:qty},

		// 		success:function(response){
		// 			if(response == 'true' ){
		// 				location.reload();
		// 			}
					
		// 		}

		// 	});

		// });

		jQuery('.cartqty').bind('input change',function(){
			userid = jQuery(this).data('userid');
			cartid = jQuery(this).data('cartid');
			panel  = jQuery(this).data('panel');
			qty    = jQuery(this).val();
			console.log('its cart qty update => ' + qty);
		  
			if( !(qty == '') && (qty > 0) ){
				console.log('value => '+qty);
				jQuery.ajax({
					url:'<?php echo site_url('subscribe_ajax/updateSubscribeQty'); ?>',
					method:'post',
					data:{qty:qty, cartid:cartid, panel:panel, userid:userid},
					
					success:function(response){
						if(response == '	 true'){
							location.reload();
						}
					}
				});
			}
		});

$('#delivery_day1').click(function(){

	let total = "<?=number_format((float)$this->session->userdata('final_total_count'), 2, '.', '') ?>";
	let coupon_code = "<?=coupon_code()?>";
	let o_otal = 1.99+total*4;
	let c_total = o_otal*coupon_code/100;
	let final_total = o_otal-c_total;

	let vat = final_total*20/100;
	let delivery_cost = Number(final_total).toFixed(2)-total;

       $('#1st_day').remove();
       $('#2nd_day').remove();
       $('#3rd_day').remove();
       $('#4th_day').remove();
       $('#total_price2').remove();
       $('#btnDelete').remove();
	$('#select1').append(`<td colspan="3" id="1st_day"><select class="form-control" name="1st_day">
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
    <option value="Thursday">Thursday</option>
    <option value="Friday">Friday</option>
    <option value="Saturday">Saturday</option>
    <option value="Sunday">Sunday</option>
	</select></td><td id="btnDelete"><button class="btnDelete btn btn-danger">Delete</button></td>`);

	$('#final_total_count').append('<td colspan="8" id="total_price1"><div style="float:right;"><h4>VAT Amount: £ '+Number(vat).toFixed(2)+'</h4><h4>Total amount per month: £ '+Number(final_total).toFixed(2)+' </h4></div><input type="hidden" class="form-control" name="delivery_cost" value="'+delivery_cost+'"></td>');

});


$("#tbUser").on('click','.btnDelete',function(){
       $('#1st_day').remove();
       $('#2nd_day').remove();
       $('#3rd_day').remove();
       $('#4th_day').remove();
       $('#btnDelete').remove();
     });



$('#delivery_day2').click(function(){
	let total = "<?=number_format((float)$this->session->userdata('final_total_count'), 2, '.', '') ?>";
	let coupon_code = "<?=coupon_code()?>";
	let o_otal = 1.99+total*8;
	let c_total = o_otal*coupon_code/100;
	let final_total = o_otal-c_total; 
	
	let vat = final_total*20/100;

	let delivery_cost = Number(final_total).toFixed(2)-total;

       $('#1st_day').remove();
       $('#2nd_day').remove();
       $('#3rd_day').remove();
       $('#4th_day').remove();
       $('#total_price1').remove();
       $('#btnDelete').remove();
	$('#select1').append(`<td colspan="2" id="1st_day"><select class="form-control" name="1st_day">
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
    <option value="Thursday">Thursday</option>
    <option value="Friday">Friday</option>
    <option value="Saturday">Saturday</option>
    <option value="Sunday">Sunday</option></select></td>`);
	$('#select1').append(`<td colspan="2" id="2nd_day"><select class="form-control" name="2nd_day">
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
    <option value="Thursday">Thursday</option>
    <option value="Friday">Friday</option>
    <option value="Saturday">Saturday</option>
    <option value="Sunday">Sunday</option></select></td><td id="btnDelete"><button class="btnDelete btn btn-danger">Delete</button></td>`);

    	$('#final_total_count').append('<td colspan="8" id="total_price2"><div style="float:right;"><h4>VAT Amount: £ '+Number(vat).toFixed(2)+'</h4><h4>Total amount per month: £ '+Number(final_total).toFixed(2)+' </h4></div><input type="hidden" class="form-control" name="delivery_cost" value="'+delivery_cost+'"></td>');
});





/*////////////////coupon_code///////////*/
$('#apply').click(function () {
		let coupon_code = $('#coupon_code').val();
		jQuery.ajax({
			url:'<?php echo site_url('coupon_code'); ?>',
			type: 'post',
			data:{coupon_code:coupon_code},
				success:function(res){
				if (res == 	 0) {
					alert('Coupon Code is wrong, try again');
				}else{
					alert('Coupon Code applyed');
					location.reload();
				}}
		});

});
/*////////////////////end////////////////*/


});

	jQuery(document).ready( function () {
	    jQuery('#table_id').DataTable();
	});
</script>