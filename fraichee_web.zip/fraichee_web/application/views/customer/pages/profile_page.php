<div class="container-fluid"  style="margin-top: 120px;">
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
      
      <div class="text-center mb-2"><h3>Profile Setting</h3>
        <hr>
        <a href="<?=base_url('subscription-details/').$this->session->userdata('customer_id');?>" class="btn btn-primary">Subscription Details</a>
      </div>

      <?php if ($user_profile->address != get_service_address()->address) { ?>
      <div class="alert alert-danger text-center d-none" role="alert"> <?=$user_profile->address?><br>
        <strong>You are</strong> <a href="#" class="alert-link">Out of Ordering Area, do you want to change your address?</a>
      </div>
      <?php } ?>

      <form action="<?=base_url('update_user_profile')?>" method="post">
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Name</label>
            <input type="name" name="name" class="form-control" id="inputEmail4" placeholder="Email" value="<?=$user_profile->name?>" disabled>
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Email</label>
            <input type="email" name="email" class="form-control" id="inputEmail4" placeholder="Email" value="<?=$user_profile->email?>" disabled>
          </div>
          <!-- <div class="form-group col-md-6">
            <label for="inputPassword4">Password</label>
            <input type="password" class="form-control" id="inputPassword4" placeholder="Password">
          </div> -->
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputPassword4">Phone number</label>
            <input type="text" name="contact" class="form-control" id="inputPassword4" placeholder="Phone number" value="<?=$user_profile->contact?>">
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Password</label>
            <input type="text" name="password" class="form-control" id="inputPassword4" placeholder="Password" value="<?=$user_profile->password?>">
          </div>
          <div class="form-group col-md-6 d-none">
            <label for="inputPassword4">Confirm Password</label>
            <input type="text" class="form-control" id="inputPassword4" placeholder="Password">
          </div>
        </div>
        <div class="form-group">
          <label for="inputAddress">Address</label>
          <input type="text" class="form-control" name="address" id="inputAddress" placeholder="1234 Main St" value="<?=$user_profile->address?>" style="padding: 50px;">
        </div>
        
        <!-- <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputCity">City</label>
            <input type="text" class="form-control" id="inputCity">
          </div>
          <div class="form-group col-md-4">
            <label for="inputState">State</label>
            <select id="inputState" class="form-control">
              <option selected>Choose...</option>
              <option>...</option>
            </select>
          </div>
          <div class="form-group col-md-2">
            <label for="inputZip">Zip</label>
            <input type="text" class="form-control" id="inputZip">
          </div>
        </div> -->
        <!-- <div class="form-group">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="gridCheck">
            <label class="form-check-label" for="gridCheck">
              Check me out
            </label>
          </div>
        </div> -->
        <button type="submit" class="btn btn-success" style="margin-bottom: 10px;">Save</button>
      </form>

    </div>
    <div class="col-md-3"></div>
  </div>
</div>