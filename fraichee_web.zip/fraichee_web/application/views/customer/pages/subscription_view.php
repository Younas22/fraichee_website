<div class="container-fluid">
    <div style="margin-top:120px;margin-bottom: 40px;">
        <div class="card card-primary">
            <div class="card-header card-header-border-bottom">
                        <h2>Subscription Details <span class="text-danger">(Amount: £<?=$subscription_row->total_amount?>)</span><span class="text-dark"> <?= str_replace("_"," ", $subscription_row->delivery_options) ?> a Week</span></h2>
                    </div>
					<div class="card-body">
						<!-- Nav tabs -->
						<div class="default-tab">
							<div class="tab-content">
								<div class="tab-pane fade show active" id="home" role="tabpanel">
									<div class="pt-4">
										<div class="row">
											<div class="col-lg-12 pt-3">
		
												<p class="text-dark">
		<?php
                        $cartdata = json_decode($subscription_row->cart_details);
                            $new_cart = [];
                            foreach($cartdata as $cdk => $cdval ){
                                $new_cart[$cdk] = [
                                    'prod_id' => $cdval->prod_id,
                                    'cp_id'   => $cdval->cp_id,
                                    'cart_qty'=> $cdval->cart_qty,
                                    'price'   => $cdval->price,
                                    'delivery_days' => $cdval->date
                                ];
                            }

                                foreach($new_cart as $nkey => $nval):
                                    $prod_id  = $nval['prod_id'];
                                    $cp_id    = $nval['cp_id'];
                                    $cart_qty = $nval['cart_qty'];
                                    $per_price= $nval['price'];
                                    $ddays    = $nval['delivery_days'];

            $prod_img = getprodimage($prod_id,$cp_id);
            echo '<h4 class="text-center text-dark">#'.$subscription_row->order_id.', '. $prod_img->name.'</h4>';
            echo '<center><img src="'.base_url().'assets/uploads/products/'.$prod_img->image.'" alt="Image not found." style="height:250px; width:250px;"/></center>';
                                endforeach; ?>
												</p><br><hr>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-6">
												<h6 class="text-dark">Subscription Date</h6>
												<p><?=date('Y-m-d', strtotime($subscription_row->delivery_days))?></p>
											</div>
											<div class="col-lg-6">
												<h6 class="text-dark">Subscription Day's</h6>
												<p><?php echo $subscription_row->first_day
												.', '.$subscription_row->second_day 
												.', '.$subscription_row->therd_day 
												.', '.$subscription_row->fourth_day ?>
													
												</p>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-6">
												<h6 class="text-dark">Note Box</h6>
												<p><?=$subscription_row->note_box?></p>
											</div>
											<div class="col-lg-6">
												<h6 class="text-dark">Other Address</h6>
												<p><?=$subscription_row->other_address?></p>
											</div>
										</div>
										<hr>
										<div class="row">
											<div class="col-lg-6">
												<h6 class="text-dark">Client Name</h6>
												<p>amjid</p>
											</div>
											<div class="col-lg-6">
												<h6 class="text-dark">Skill Category</h6>
												<p>xyz</p>
											</div>
										</div>
									</div>
								</div><hr>
							<center><a href="
								<?php 
									$uid  = $this->session->userdata('customer_id');
									echo base_url('subscription-details/').$uid;
								?>" class="btn btn-danger">back</a>
							</center>
								
							</div>
						</div>
					</div>



				</div>
			</div>
		</div>
