<html>
  <head>
    <meta charset="utf-8">
    <title>Account Verification</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
    <style>
    
    /*--thank you pop starts here--*/
    .thank-you-pop{
    width:100%;
    padding:20px;
    text-align:center;
    }
    .thank-you-pop img{
    width:76px;
    height:auto;
    margin:0 auto;
    display:block;
    margin-bottom:25px;
    }
    .thank-you-pop h1{
    font-size: 42px;
    margin-bottom: 25px;
    color:#5C5C5C;
    }
    .thank-you-pop p{
    font-size: 20px;
    margin-bottom: 27px;
    color:#5C5C5C;
    }
    .thank-you-pop h3.cupon-pop{
    font-size: 25px;
    margin-bottom: 40px;
    color:#222;
    display:inline-block;
    text-align:center;
    padding:10px 20px;
    border:2px dashed #222;
    clear:both;
    font-weight:normal;
    }
    .thank-you-pop h3.cupon-pop span{
    color:#03A9F4;
    }
    .thank-you-pop a{
    display: inline-block;
    margin: 0 auto;
    padding: 9px 20px;
    color: #fff;
    text-transform: uppercase;
    font-size: 14px;
    border-radius: 17px;
    }
    .thank-you-pop a i{
    margin-right:5px;
    color:#fff;
    }
    #ignismyModal .modal-header{
    border:0px;
    }
    /*--thank you pop ends here--*/
    </style>
  </head>
  <body class="bg-secondary">
    <!--Model Popup starts-->
    <div class="container text-center mt-5">
      <div class="row">
        <div class="col-md-4 offset-md-4">
          <div  id="ignismyModal" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-body">
                  <div class="thank-you-pop">
                    <img src="<?=base_url('assets/frontend/img/user-account.png')?>" alt="">
                    <h1>Thanks!</h1>
                  <p>We have sent an email with instructions on how to set up your account. Check your inbox and get started with Fraichee</p>

                  <a href="<?=base_url()?>" class="btn btn-primary" style="width:70%; padding: 15px;">OK</a>                    
                  </div>
                  
                </div>
                
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--Model Popup ends-->
  </body>
</html>
<!------ Include the above in your HEAD tag ---------->