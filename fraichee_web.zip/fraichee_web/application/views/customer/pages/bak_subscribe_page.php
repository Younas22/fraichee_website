<main id="main">



    <!-- ======= Service Type Section ======= -->
    <div class="container-fluid" style="margin-top: 80px;">
      <h4>Choose</h4>
      <nav class="nav nav-pills" role="tablist">
        <a class="btn btn-info btn-lg" data-toggle="tab" href="#top" role="tab" aria-controls="" aria-selected="true">Top</a>
        <a class="btn btn-info btn-lg" data-toggle="tab" href="#bottoms" role="tab" aria-controls="" aria-selected="true">Bottom</a>
      </nav>

      <div class="tab-content">
        <div class="tab-pane fade show active" id="top" role="tabpanel" aria-labelledby="home-tab">
          <nav class="nav nav-pills" id="top" role="tablist">
            <a class="btn btn-info btn-lg" data-toggle="tab" href="#ctop1" role="tab" aria-controls="" aria-selected="true">CTop1</a>
            <a class="btn btn-info btn-lg" data-toggle="tab" href="#ctop2" role="tab" aria-controls="" aria-selected="true">CTop2</a>
          </nav>            
        </div>
        <div class="tab-pane fade" id="bottoms" role="tabpanel" aria-labelledby="profile-tab">
          <p>world</p>
        </div>
      </div>

      <div class="tab-content" role="tablist">
        <div class="tab-pane fade show active" id="ctop1" role="tabpanel" aria-labelledby="">
          
          <div class="col-md-3 CartProducts">
            <div class="addCartProducts">
              <div class="card border-0">
                <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
                
                <div class="card-body px-0 CartProductsBody">
                  <div class="card-title d-flex flex-row">
                    <div style="flex:1;">Card Title</div>
                    <div class="prodPrice">$20</div>
                  </div>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
                </div>
              </div>
            </div>
          </div>

        </div>

        <div class="tab-pane fade show" id="ctop2" role="tabpanel" aria-labelledby="">
          <div class="col-md-3 CartProducts">
            <div class="addCartProducts">
              <div class="card border-0">
                <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
                
                <div class="card-body px-0 CartProductsBody">
                  <div class="card-title d-flex flex-row">
                    <div style="flex:1;">Card Title</div>
                    <div class="prodPrice">$20</div>
                  </div>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- </div> -->
    </div>


    <div class="container-fluid prodCatSection">
      <div class="row">
        <!-- <div class="col-md-3 p-0"  style="margin-top:71px;">
          <ul class="list-group">
            <li class="list-group-item prodCat">
              <div class="d-flex"> 
                <div class="one-forth"> 
                    <img src="https://i.pinimg.com/originals/b1/bd/e7/b1bde73ee72d01118d743df48f826f71.png" class="img img-thumbnail border-0" alt="Image not found" style="height:40px; width:40px;">
                </div>
                <div class="one-half pl-3" style="position: relative;top: 7px;">
                  <h4>Wash</h4>
                </div>
              </div>
            </li>
            <li class="list-group-item prodCat">
              <div class="d-flex"> 
                <div class="one-forth"> 
                    <img src="https://i.pinimg.com/originals/b1/bd/e7/b1bde73ee72d01118d743df48f826f71.png" class="img img-thumbnail border-0" alt="Image not found" style="height:40px; width:40px;">
                </div>
                <div class="one-half pl-3" style="position: relative;top: 7px;">
                  <h4>Wash</h4>
                </div>
              </div>
            </li>
            <li class="list-group-item prodCat">
              <div class="d-flex"> 
                <div class="one-forth"> 
                    <img src="https://i.pinimg.com/originals/b1/bd/e7/b1bde73ee72d01118d743df48f826f71.png" class="img img-thumbnail border-0" alt="Image not found" style="height:40px; width:40px;">
                </div>
                <div class="one-half pl-3" style="position: relative;top: 7px;">
                  <h4>Wash</h4>
                </div>
              </div>
            </li>
          </ul>

        </div> -->

        <div class="col-md-12">
          <div class="service_type_section">
            <h4>Choose</h4>
            <?php foreach($services_type as $service ){ ?> 
              <button class="btn btn-info btn-lg service_type_btn" data-serviceid="<?php echo $service['service_id']; ?>"><?php echo $service['name']; ?></button>
            <?php } ?>
            <!-- <button class="btn btn-info btn-lg service_type_btn">Premium Linen</button> -->
          </div>
          <div class="product_category_section"></div>
          <!-- <div class="product_category_section">
            <h4>Linen Type</h4>
            <button class="btn btn-info btn-lg service_type_btn">Home Linen</button>
            <button class="btn btn-info btn-lg service_type_btn">Premium Linen</button>
          </div> -->
        </div>


      </div>

      <div class="row cartproducts_wrapper">
        <!-- <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div> -->
        
        <!-- <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-3 CartProducts">
          <div class="addCartProducts">
            <div class="card border-0">
              <img class="card-img-top" src="https://s3.eu-west-2.amazonaws.com/oxwash-dev.uploads/products/5fb2735d029f080004db6e8b/photo/blob-1605530461499" alt="Card image cap">
              <div class="card-body px-0 CartProductsBody">
                <div class="card-title d-flex flex-row">
                  <div style="flex:1;">Card Title</div>
                  <div class="prodPrice">$20</div>
                </div>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary addCartBtn">Add To Cart</a>
              </div>
            </div>
          </div>
        </div> -->
      </div>
    </div>
    <!-- service type section ends here -->


</main><!-- End #main -->