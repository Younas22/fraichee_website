<main id="main">
	<div class="row" style="margin:50px;">
		<div class="col-md-1"></div>
		<div class="col-md-10">
			<div class="col-lg-12 mt-5"><h1 class="text-center" style="font-size:3vw">Subscribe Cart Details</h1></div>
			<form method="post" action="<?php echo site_url('customer/placeorder'); ?>"  class="require-validation" data-cc-on-file="false"data-stripe-publishable-key="<?php echo $this->config->item('stripe_key') ?>" id="paymentFrm">

				<div class="card" style="margin-bottom: 20px;">
					<div class="card-header bg-primary text-white">
						Cart List
					</div>
					<div class="table-responsive">
					<table class="table" id="tbUser">
						<thead>
							<tr style="font-size: 12px;">
								<th>Sr.No</th>
								<th>Title</th>
								<th>Price</th>
								<th>Qty</th>
								<th>Each Total</th>
								<th>Delivery date</th> 
								<th>Action</th>
								<!-- <th>Delivery date</th> -->
							</tr>
						</thead>
						<tbody>
							<input type="hidden" name="uid" value="<?php echo $this->session->userdata('customer_id'); ?>">
							<input type="hidden" name="panel_type" value="subscribe">
							<?php
							$total = 0;
							foreach($cartdetails as $key => $cart ):
								// $total   = $total + $cart['total_price'];
								// $cart_id = $cart['cart_id'];
								$each_total = $cart['price']*$cart['cart_qty'];
								$total   = $total + ($cart['price']*$cart['cart_qty']);
								$cart_id = $cart['cart_id'];
							?>
							<tr>
								<th><?php echo ($key+1); ?></th>
								<th style="font-size:1.5vw;" width="30%"><?php echo strtoupper(getChildProdName($cart['cp_id'])); ?></th>
								<th  width="10%">£ <?php echo $cart['price']; ?></th>
								<th>
									<input type="number" name="cartqty" value="<?php echo $cart['cart_qty']; ?>" min="1" class="form-control cartqty" data-cartid="<?php echo $cart['cart_id'];  ?>" data-panel="subscribe" data-userid="<?php echo $this->session->userdata('customer_id'); ?>" style="width:50px;">
								</th>
								<th>£ <?php echo $cart['total_price']; ?></th>
								<th>
									<input type="date" class="form-control" name="delivery_dates" placeholder="dd-mm-yyyy" required>
								</th>
								<th width="15%">
									<a href="<?php echo site_url('customer/remove-cart/').$cart_id;?>/subscribe" class="btn btn-danger ">Remove Cart</a>
								</th>
								<!-- 									<th>
										<input type="date" class="form-control" name="delivery_dates" placeholder="dd-mm-yyyy" required>
								</th> -->
							</tr>
							<?php endforeach; ?>
							<tr>
								<td colspan="8">
									<h4 style="text-align: center;">delivery day's</h4>
									<div class="text-center">
										<label class="radio-inline">
											<input type="radio" name="delivery_options" id="delivery_day1" value="one_day" checked=""> 1 delivery  a week
										</label>
										<label class="radio-inline">
											<input type="radio" name="delivery_options" id="delivery_day2" value="two_days"> 2 deliveries a week
										</label>
									</div>
								</td>
								<tr><td colspan="8">
<?php 
/*////////////////coupon_code///////////*/
if (check_first_user() == 0) {
	echo '
	<div class="'.hide_class().'" style="display: grid;
  place-items: center;">
		<p>Enter Coupon Code and get 20% off the total order price <b style="color:red">Coupon Code is: '.coupon_code_text().'</b></p>
	<fieldset class="form-group form-inline">
   <input type="text" class="form-control" name="coupon_code"  id="coupon_code" placeholder="Enter Coupon Code">
   <button id="apply" class="btn btn-primary">Apply</button>
</fieldset></div>';
}
/*////////////////end///////////*/
?>
								</td></tr>
							</tr>
							<div id="twotime">
							<tr id="select1"> </tr>
						</div>
						<!-- <hr> -->
						<tr id="final_total_count">

<?php $data = ['final_total_count' => $total]; $this->session->set_userdata($data); ?>
							
						</tr>
						<!-- <tr>
								<td colspan="6">
										<button type="submit" class="btn btn-success" style="float:right;">Confirm Order</button>
								<a href="<?php echo site_url('customer/subscribe'); ?>" class="btn btn-info mx-3" style="float:right;">Back To Shop</a>
							</td>
						</tr> -->
						<!-- </form> -->


						<tr>
							<td colspan="8">
								<h4 style="text-align: center;">Optional</h4>
							</td>
						</tr>
						<tr>
							<td align='center' width="100px">Note Box:</td>
							<td colspan="3"><textarea class="form-control" name="note_box"></textarea></td>
							<td align='center'>Other Address:</td>
							<td colspan="2"><input style="width:70% !important" type="text" name="other_address" class="form-control"><h5>Profile Address: <b class="text-danger"><?=user_address()->address?></b></h5></td>
						</tr>
					</tbody>
				</table>
			</div>
				<div class="row">
					<div class="col-md-12">
						<div class="card">
					<div class="card-header bg-primary text-white">
						Payment
					</div>
					<div id="payment-errors" class=" text-center mt-2"></div>
					<div class="card-body">
						<div class="form-group">
							<label>Card Holder Name</label>
							<span id="card-holder-name-info"
							class="info"></span><br>
							<input type="text" id="name" name="name" class="form-control" required>
						</div> 
						<!-- <div class="form-group">
							<label>Email</label>
							<input type="text" id="email" name="email" class="form-control">
						</div> -->
						<div class="form-group">
							<label>Card Number</label>
							<input type="text" id="card_num" name="card-number" class="form-control" required>
						</div>
						<div class="row">
							<div class="col-md-4">
								<label>Expiry Month</label>
								<select name="month" id="card-expiry-month" class="form-control col-sm" required>
					                <option value="01">01</option>
					                <option value="02">02</option>
					                <option value="03">03</option>
					                <option value="04">04</option>
					                <option value="05">05</option>
					                <option value="06">06</option>
					                <option value="07">07</option>
					                <option value="08">08</option>
					                <option value="09">09</option>
					                <option value="10">10</option>
					                <option value="11">11</option>
					                <option value="12">12</option>
								</select>
							</div>
							<div class="col-md-4">
							<label>Expiry Year</label>
							<select name="year" id="card-expiry-year" class="form-control col-sm	" required>
									<option value="18">2018</option>
									<option value="19">2019</option>
									<option value="20">2020</option>
									<option value="21">2021</option>
									<option value="22">2022</option>
									<option value="23">2023</option>
									<option value="24">2024</option>
									<option value="25">2025</option>
									<option value="26">2026</option>
									<option value="27">2027</option>
									<option value="28">2028</option>
									<option value="29">2029</option>
									<option value="30">2030</option>
								</select>
							</div>
							<div class="col-md-4">
								<label>CVC</label>
								<input type="text" name="cvc" id="card-cvc" class="form-control" placeholder="CVC" required>
							</div>
						</div>
					</div>
					<div class="card-footer">
						<button type="submit" id="payBtn" class="btn btn-success" style="float:right;">Confirm Order</button>
						
						<a href="<?php echo site_url('customer/subscribbe'); ?>" class="btn btn-info mx-3" style="float:right;">Back To Shop</a>
					</div>
				</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>

</main>