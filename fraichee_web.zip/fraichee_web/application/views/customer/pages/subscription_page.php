<main id="main">
  <section class="pricing py-5">
    <div class="container">
      <div class="row">
        <!-- Free Tier -->
        <div class="col-md-2"></div>
        <div class="col-lg-4">
          <div class="card mb-5 mb-lg-0">
            <div class="card-body">
              <h5 class="card-title text-muted text-uppercase text-center d-none">Free</h5>
              <h6 class="card-price text-center">Laundary</h6>Your laundry will be picked cleaned and returned in 24 hours 

              <hr>
              <ul class="fa-ul">
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Order a pickup</li>
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Driver picksup</li>
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Driver drops off clean laundary</li>
              </ul>
              <a href="<?php echo site_url('customer/laundary'); ?>" class="btn btn-block btn-primary text-uppercase">Go</a>
            </div>
          </div>
        </div>
        <!-- Plus Tier -->
        <div class="col-lg-4">
          <div class="card mb-5 mb-lg-0">
            <div class="card-body">
              <h5 class="card-title text-muted text-uppercase text-center d-none">Free</h5>
              <h6 class="card-price text-center">Linen subscription</h6>Have fresh Linen delivered  a weekly basis 

              <hr>
              <ul class="fa-ul">
                
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Choose what Linen you require from a variety listed on our website</li>
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Choose how often</li>
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Choose when to deliver </li>
                <li><span class="fa-li"><i class="fas fa-check"></i></span>Driver will drop off fresh Linen and pick up the used one</li>
                </ul>
              <a href="<?php echo site_url('customer/subscribe'); ?>" class="btn btn-block btn-primary text-uppercase">Go</a>
            </div>
          </div>
        </div>
        <div class="col-md-2"></div>
      </div>
    </div>
  </section>

</main><!-- End #main -->