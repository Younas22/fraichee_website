

<div class="container-fluid">
    <div style="margin-top:120px;margin-bottom: 40px;">
        <div class="card card-primary">
            <div class="card-header card-header-border-bottom">
                        <h2>Subscription</h2>
                    </div>

                    <?php if (!empty($this->session->flashdata('msg'))) { ?>
                        <div class="alert alert-success p-2">
                            <?= $this->session->flashdata('msg'); ?>
                        </div>
                    <?php } ?>
                    
                    <div class="card-body">
                    <?php //echo "<pre>"; print_r($get_contract); exit(); ?>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Sr</th>
                                <th>Order No</th>
                                <th>Title</th>
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Subscription</th>
                                <th>Action</th>

                            </tr>
                            </thead>
                            <tbody>

                        <?php  $count = 1; foreach($subscription_details as $key){ 
                            $cartdata = json_decode($key->cart_details);


                            $new_cart = [];
                            foreach($cartdata as $cdk => $cdval ){
                                $new_cart[$cdk] = [
                                    'prod_id' => $cdval->prod_id,
                                    'cp_id'   => $cdval->cp_id,
                                    'cart_qty'=> $cdval->cart_qty,
                                    'price'   => $cdval->price,
                                    'delivery_days' => $cdval->date
                                ];
                            }
                        ?>
                        <tr>
                            <td><?php echo  $count; ?></td>
                            <td><?php echo $key->order_id; ?></td>
                            <td style="text-align:center;">
                                <?php  
                                foreach($new_cart as $nkey => $nval):
                                    $prod_id  = $nval['prod_id'];
                                    $cp_id    = $nval['cp_id'];
                                    $cart_qty = $nval['cart_qty'];
                                    $per_price= $nval['price'];
                                    $ddays    = $nval['delivery_days'];

            $prod_img = getprodimage($prod_id,$cp_id);
            echo  $prod_img->name;
                                endforeach;
                                ?>
                            </td>
                            <td>$ <?php echo $per_price; ?></td>
                            <td>$ <?php echo $cart_qty; ?></td>
                            <td>$ <?php echo $key->total_amount; ?></td>
                            <td><?php echo $ddays; ?></td>
                            <td><?php echo $key->status; ?></td>


                            


                            
                                <?php if ($key->status == 'cancelled') {?>
                            <td><a class="text-secondary" href="#" title="Un Subscription" style="font-size: x-large;" onclick="return confirm('this subscription was cancelled')"><i class="icofont-tick-boxed"></i></a></td>
                                <?php } ?>

                                <?php if ($key->status == 'pending') {?>
                            <td><a class="text-primary" href="#" title="Subscription" style="font-size: x-large;" onclick="return confirm('Are you sure, you want to cancel it?')"><i class="icofont-tick-boxed"></i></a></td>
                                <?php } ?>


                            <td style="">
                            <a class="text-info" href="<?php echo base_url('subscription-edit/'.$key->order_id); ?>" title="Edit" style="font-size: x-large;"><i class="icofont-edit"></i></a>
                            
                            <a class="text-danger" href="<?php echo base_url('subscription-remove/'.$key->order_id); ?>" title="Delete" style="font-size: x-large;" onclick="return confirm('Are you sure, you want to delete it?')"><i class="icofont-ui-delete"></i></i></a>

                            <a class="text-success" href="<?php echo base_url('subscription-view/'.$key->order_id); ?>" title="View" style="font-size: x-large;"><i class="icofont-eye-alt"></i></a>

                        </td>
                            </tr>
                        <?php $count++;  } ?>
<!--                             <td>
                            <a class="text-primary" href="<?php echo base_url('subscription-cancel/1'); ?>" title="Subscription" style="font-size: x-large;"><i class="icofont-tick-boxed"></i></a>
                            </td>

                            <td style="width: 15%;">
                            <a class="text-info" href="<?php echo base_url('subscription-edit/1'); ?>" title="Edit" style="font-size: x-large;"><i class="icofont-edit"></i></a>
                            
                            <a class="text-danger" href="<?php echo base_url('subscription-remove/1'); ?>" title="Delete" style="font-size: x-large;"><i class="icofont-ui-delete"></i></i></a>

                            <a class="text-success" href="<?php echo base_url('subscription-view/1'); ?>" title="View" style="font-size: x-large;"><i class="icofont-eye-alt"></i></a>

                        </td> -->
                            </tbody>
                        </table>

                    <center><div class="mt-5">
                    <a href="<?= base_url('customer') ?>" target="_blank" class="btn btn-success">New Subscription</a>
                    </div></center>
                    </div>

        </div>
                
    </div>
</div>