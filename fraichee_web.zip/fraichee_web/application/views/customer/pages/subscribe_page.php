<main id="main">

    <!-- ======= Service Type Section ======= -->
    <div class="container-fluid" style="margin-top: 80px;">
      <h4>Choose</h4>
      <nav class="nav nav-pills" role="tablist">
        <?php 
        $service_count  = 0;
        foreach($services_type as $slk => $slv ){ 
          $service_status = '';
          if( $service_count == $slk ){
            $service_status = 'active';
          }
        ?>
          <a class="btn btn-info btn-lg service_cat_btn <?php echo $service_status; ?>" data-toggle="tab" href="#service<?php echo $slk; ?>" role="tab" aria-controls="" aria-selected="true"><?php echo $slv['name']; ?></a>
        <?php 
        } 
        ?>
      </nav>

      <div class="tab-content">
        <?php  
        $services_count = 0;
        foreach($services_type as $slk => $slv ){ 
          $service_status = '';
          if( $service_count == $slk ){
            $service_status = 'active';
          }
          $service_id = $slv['service_id'];
        ?>
          <div class="tab-pane fade show <?php echo $service_status; ?>" id="service<?php echo $slk; ?>" role="tabpanel" aria-labelledby="home-tab">
            <h4>Products</h4>
            <nav class="nav nav-pills" role="tablist">
              <?php  
              $products   = getProducts($service_id);
              $prod_count = 0;
              foreach($products as $pkey => $pval ){
                $prod_status   = '';
                if($pkey == $prod_count ){
                  $prod_status = 'active';
                }
                else{
                  $prod_status = '';
                }
                $prod_id  = $pval['prod_id'];
                $prod_name= $pval['name']; 
              ?>
              <a class="btn btn-info btn-lg prod_btn <?php echo $prod_status; ?>" data-toggle="tab" href="#ctop<?php echo $prod_id; ?>" role="tab" aria-controls="" aria-selected="true"><?php echo $prod_name; ?></a>
              <?php 
              }
              ?>
            </nav>            

            <div class="tab-content" role="tablist">
              <?php  
              $products   = getProducts($service_id);
              $prod_count = 0;
              foreach($products as $pkey => $pval ){
                $prod_status   = '';
                if($pkey == $prod_count ){
                  $prod_status = 'active';
                }
                else{
                  $prod_status = '';
                }
                $prod_id  = $pval['prod_id'];
                $prod_name= $pval['name']; 
              ?>
              <div class="tab-pane fade show <?php echo $prod_status; ?>" id="ctop<?php echo $prod_id; ?>" role="tabpanel" aria-labelledby="">
                <div class="row">
                <?php  
                $cproducts  = getChildProducts($prod_id);
                foreach($cproducts as $cpk => $cpv ){
                  $cp_id    = $cpv['cp_id'];
                  $cp_title = $cpv['cp_name'];
                  $cp_price = $cpv['cp_price'];
                  $cp_desc  = $cpv['cp_desc'];
                  $cp_image = $cpv['cp_image'];
                ?>
                <div class="col-md-3 CartProducts">
                  <div class="addCartProducts">
                    <div class="card border-0">
                      <img class="card-img-top" src="<?php echo base_url(); ?>assets/uploads/products/<?php echo $cp_image; ?>" alt="Card image cap">
                      
                      <div class="card-body px-0 CartProductsBody">
                        <div class="card-title d-flex flex-row">
                          <div style="flex:1;"><?php echo $cp_title; ?></div>
                          <div class="prodPrice">£ <?php echo $cp_price; ?></div>
                        </div>
                        <p class="card-text"><?php echo $cp_desc; ?></p>
                        <a href="#" class="btn btn-primary addCartBtn" data-cartprodid="<?php echo $cp_id; ?>">Add To Cart</a>
                      </div>
                    </div>
                  </div>
                </div>
                <?php } ?>
                </div> <!-- row ends here  -->
              </div>
              <?php } ?>

            </div>

          </div>
        <?php }
        ?>
      </div>      
    </div> <!-- container fluid ends here  -->
    <!-- service type section ends here -->
</main><!-- End #main -->