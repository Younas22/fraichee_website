

<div class="container-fluid">
    <div style="margin-top:120px;margin-bottom: 40px;">
        <div class="card card-primary">
            <div class="card-header">Orders</div>
            <div class="card-body">
                <table id="table_id" class="display table_id" border="1">
                    <thead>
                        <tr>
                            <th>Serial No.</th>
                            <th>Order Number</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th>Cart Details</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php  $count = 1; foreach($order_details as $key){ 
                            $cartdata = json_decode($key->cart_details);


                            $new_cart = [];
                            foreach($cartdata as $cdk => $cdval ){
                                $new_cart[$cdk] = [
                                    'prod_id' => $cdval->prod_id,
                                    'cp_id'   => $cdval->cp_id,
                                    'cart_qty'=> $cdval->cart_qty,
                                    'price'   => $cdval->price,
                                    'delivery_days' => $cdval->delivery_days
                                ];
                            }
                        // dd($new_cart);
                        ?>
                        <tr>
                            <td><?php echo  $count; ?></td>
                            <td><?php echo $key->order_id; ?></td>
                            <td><?php echo $key->contact; ?></td>
                            <td><?php echo $key->address; ?></td>
                            <td style="text-align:center;">
                                <?php  
                                foreach($new_cart as $nkey => $nval):
                                    $prod_id  = $nval['prod_id'];
                                    $cp_id    = $nval['cp_id'];
                                    $cart_qty = $nval['cart_qty'];
                                    $per_price= $nval['price'];
                                    $ddays    = $nval['delivery_days'];
            $getprodname = getprodname($cp_id);
            $prod_img = getprodimage($prod_id,$cp_id);
            echo '<h5>Product name : '.$getprodname->cp_name.'</h5>';
            echo '<img src="'.base_url().'assets/uploads/products/'.$prod_img->image.'" alt="Image not found." style="height:50px; width:100px;"/>';
            echo '<h4 style="text-align:center;">$ '.$per_price.' * '.$cart_qty.'</h4>';
            echo '<h5>Delivery Days : '.$ddays.'</h5>';
                                endforeach;
                                ?>
                            </td>
                            <td>$ <?php echo $key->total_amount; ?></td>
                            <td><?php echo $key->date; ?></td>
                            <td><?php echo $key->status; ?></td>
                            </tr>
                        <?php $count++;  } ?>
                    </tbody>
                </table>        
            </div>
        </div>
                
    </div>
</div>