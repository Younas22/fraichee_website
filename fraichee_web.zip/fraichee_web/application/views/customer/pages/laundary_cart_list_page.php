<main id="main"> 

	<div class="row" style="margin-top: 50px;">

		<div class="col-md-1"></div>
		<div class="col-md-10">
			<div class="col-lg-12 mt-5"><h1 class="text-center">Cart Details</h1></div>
			<form method="post" action="<?php echo site_url('customer/placeorder'); ?>" class="require-validation" data-cc-on-file="false"data-stripe-publishable-key="<?php echo $this->config->item('stripe_key') ?>" id="paymentFrm">
				<div class="card" style="margin-bottom: 20px;">
					<div class="card-header bg-primary text-white">
						Cart List
					</div>
					<!-- <div class="card-body"> -->
						<table class="table">
							<thead>
								<tr>
									<th colspan="1">Sr.No</th>
									<th>Title</th>
									<th>Price</th>
									<th>Qty</th>
									<th>Total</th>
<!-- 									<th>Pick up date</th>
									<th>Delivery date</th> -->
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<!-- <form method="post" action="<?php echo site_url('customer/placeorder'); ?>"> -->
<input type="hidden" name="uid" value="<?php echo $this->session->userdata('customer_id'); ?>">
<input type="hidden" name="panel_type" value="<?php echo $panel; ?>">
								<?php
								$total = 0;
								foreach($cartdetails as $key => $cart ):
									$each_total = $cart['price']*$cart['cart_qty'];
									$total   = $total + ($cart['price']*$cart['cart_qty']);  
									$cart_id = $cart['cart_id'];
								?>
								<tr>
									<th colspan="1"><?php echo ($key+1); ?></th>
									<th><?php echo strtoupper(getChildProdName($cart['cp_id'])); ?></th>
									<th>£ <?php echo $cart['price']; ?></th>
									<th>
										<input type="number" name="cartqty" value="<?php echo $cart['cart_qty']; ?>" min="1" class="form-control cartqty" data-panel="laundary" data-cartid="<?php echo $cart['cart_id'];  ?>" data-userid="<?php echo $this->session->userdata('customer_id'); ?>">
									</th>
									<th width="">£ <?php echo $each_total; ?></th>
									<!-- <th>
										<input type="date" class="form-control" name="pickup_dates" placeholder="dd-mm-yyyy" required>
									</th>
									<th>
										<input type="date" class="form-control" name="delivery_dates" placeholder="dd-mm-yyyy" required>
									</th> -->
							<th>
								<a href="<?php echo site_url('customer/remove-cart/').$cart_id; ?>/laundary" class="btn btn-danger btn-sm">Remove</a>
							</th>
						</tr>
							<?php endforeach; ?>
							<tr>
								<td colspan="8"> 
<?php 
/*////////////////coupon_code///////////*/
if (check_first_user() == 0) {
	echo '
	<div class="'.hide_class().'">
		<p>Enter Coupon Code and get 20% off the total order price <b style="color:red">Coupon Code is: '.coupon_code_text().'</b></p>
	<fieldset class="form-group form-inline" style="float:left;">
   <input type="text" class="form-control" name="coupon_code" id="coupon_code" placeholder="Enter Coupon Code">
   <button id="apply" class="btn btn-primary">Apply</button>
</fieldset></div>';
}
/*////////////////end///////////*/
?>
									
<h4 style="float:right;"> 
<?php

$total = number_format((float)$total, 2, '.', '');

$totalwith_coupon = $total*coupon_code()/100;
$totalwith_coupon = number_format((float)$totalwith_coupon, 2, '.', '');


// $echo = $total + 3.99 - $totalwith_coupon;
// echo $echo;
// echo "<br>";

if ($total < 30) {
echo "Total Amount with 3.99 delivery cost: £"; echo $total + 3.99 - $totalwith_coupon;
echo '<input type="hidden" class="form-control" name="delivery_cost" value="3.99">';
echo '<input type="hidden" class="form-control" name="totalwith_coupon" value="'.$totalwith_coupon.'">';
}else{
echo "Total Amount : £ ".round($total - $totalwith_coupon, 2);
echo '<input type="hidden" class="form-control" name="delivery_cost" value="0.00">';
echo '<input type="hidden" class="form-control" name="totalwith_coupon" value="'.$totalwith_coupon.'">';
}
?>

								</h4>
								</td>
							</tr>
							</tbody>
						</table>




<!-- Pick Up And Delivery Date -->

<h4 class="text-center mb-4">Pick Up And Delivery Date</h4>
<div class="row">
	
	<div class="col-lg-2"></div>
		<div class="col-lg-4">
	<fieldset class="form-group">
		<label for="exampleInputEmail1">Pick Up Date</label>
   <input type="date" class="form-control" name="pickup_dates" placeholder="dd-mm-yyyy" required>
	</fieldset>
	</div>


	<div class="col-lg-4">
	<fieldset class="form-group">
		<label for="exampleInputEmail1">Delivery Date</label>
<input type="date" class="form-control" name="delivery_dates" placeholder="dd-mm-yyyy" required>
	</fieldset>
	</div>
	<div class="col-lg-2"></div>
</div>




<!-- Pick Up And Delivery Date -->

<h4 class="text-center mb-4">Optional</h4>
<div class="row">
	
	<div class="col-lg-2"></div>
		<div class="col-lg-4">
	<fieldset class="form-group">
		<label for="exampleInputEmail1">Note Box</label>
		<textarea class="form-control" name="note_box"></textarea>
	</fieldset>
	</div>


	<div class="col-lg-4">
	<fieldset class="form-group">
		<label for="exampleInputEmail1">Confirm Address</label>
		<input type="text" name="other_address" class="form-control">
		<h5>Profile Address: <b class="text-danger"><?=user_address()->address?></b></h5>
	</fieldset>
	</div>
	<div class="col-lg-2"></div>
</div>




					<!-- </div> -->
				</div>	

				<div class="card">
					<div class="card-header bg-primary text-white">
						Payment
					</div>
					<div id="payment-errors" class=" text-center mt-2"></div>
					<div class="card-body">
					    <div class="form-group">
					        <label>Card Holder Name</label> 
					        <span id="card-holder-name-info"
					            class="info"></span><br> 
					        <input type="text" name="name" class="form-control" required>
					    </div>
					    <!-- <div class="form-group">
					        <label>Email</label>
					        <input type="text" id="email" name="email" class="form-control">
					    </div> -->
					    <div class="form-group">
					        <label>Card Number</label> 
					        <input type="text" id="card_num" name="card-number" class="form-control" required>
					    </div>
					    <div class="row">
						    <div class="col">
					    	    <label>Expiry Month</label>
						        <select name="month" id="card-expiry-month" class="form-control col-sm" required>
					                <option value="01">01</option>
					                <option value="02">02</option>
					                <option value="03">03</option>
					                <option value="04">04</option>
					                <option value="05">05</option>
					                <option value="06">06</option>
					                <option value="07">07</option>
					                <option value="08">08</option>
					                <option value="09">09</option>
					                <option value="10">10</option>
					                <option value="11">11</option>
					                <option value="12">12</option>
					            </select> 
						    </div>
						    <div class="col">
						       <label>Expiry Year</label>
						       <select name="year" id="card-expiry-year" class="form-control col-sm	" required>
					                <option value="18">2018</option>
					                <option value="19">2019</option>
					                <option value="20">2020</option>
					                <option value="21">2021</option>
					                <option value="22">2022</option>
					                <option value="23">2023</option>
					                <option value="24">2024</option>
					                <option value="25">2025</option>
					                <option value="26">2026</option>
					                <option value="27">2027</option>
					                <option value="28">2028</option>
					                <option value="29">2029</option>
					                <option value="30">2030</option>
					            </select>
						    </div>
						    <div class="col">
						    	<label>CVC</label>
						    	<input type="text" id="card-cvc" name="cvc" class="form-control" placeholder="CVC" required>
						    </div>
						</div>
					</div>
					<div class="card-footer">
						<button type="submit" id="payBtn" class="btn btn-success" style="float:right;">Confirm Order</button>
						<a href="<?php echo site_url('customer/laundary'); ?>" class="btn btn-info mx-3" style="float:right;">Back To Shop</a>

					</div>
				</div>	
			</form>
		</div>
		<div class="col-md-1"></div>
	</div>
	

</main>