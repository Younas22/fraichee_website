<?php  
$this->load->view('customer/includes/head');
if( $page_name == 'login_page' ){
	$this->load->view('customer/pages/'.$page_name);
}
else if( $page_name == 'signup_page' ){
	$this->load->view('customer/pages/'.$page_name);
}
else{
	$this->load->view('customer/includes/header'); 
	$this->load->view('customer/pages/'.$page_name); 
	$this->load->view('customer/includes/footer');
}
if($panel == 'laundary'){
	$this->load->view('customer/ajax_request/laundarypage_ajax.php');  
}
else if($panel == 'subscribe' ){
	$this->load->view('customer/ajax_request/subscribepage_ajax.php');  	
}
?>