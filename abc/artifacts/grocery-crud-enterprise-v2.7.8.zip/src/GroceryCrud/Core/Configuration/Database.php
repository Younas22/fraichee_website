<?php
namespace GroceryCrud\Core\Configuration;

class Database
{

}